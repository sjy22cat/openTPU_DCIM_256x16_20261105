`timescale 1ns/1ps
module tb_dma_wide;
  import otpu_pkg::*;
  logic clk=0,rst=1,start=0;always #5 clk=~clk;
  cmd_t cmd;
  logic rdy,done,err,held,req,we,gnt,rv,idle,tg;
  logic [31:0] addr;
  logic [63:0] mask,tr,tw;
  logic [2047:0] wd,rd;
  logic [63:0][31:0] tra,twa,twd,trd;
  logic [31:0] dram[4096],tmem[262144];
  logic [2:0] vp=0;
  logic [2047:0] dp[3];
  int cycle=0,wpend=0,polls=0,held_count=0;
  otpu_dma_wide #(.DEPTH(8)) dut(.clk,.rst,.start,.cmd,.rdy,.done,.err,
    .ww_held(held),.b_req(req),.b_we(we),.b_gnt(gnt),.b_rvalid(rv),.wr_idle(idle),
    .b_wmask(mask),.b_wdata(wd),.b_addr(addr),.b_rdata(rd),
    .t_ren(tr),.t_wen(tw),.t_raddr(tra),.t_waddr(twa),.t_wdata(twd),.t_rdata(trd),.t_gnt(tg));
  assign gnt=cycle%7!=0 && cycle%7!=1;
  assign tg=cycle%29>=9; // long hold while read responses keep arriving
  assign idle=wpend==0,rv=vp[2],rd=dp[2];
  always @(posedge clk) begin
    cycle<=cycle+1;
    vp[0]<=!rst && req && !we && gnt;
    for(int i=1;i<3;i++) begin vp[i]<=vp[i-1];dp[i]<=dp[i-1];end
    if(wpend>0) wpend<=wpend-1;
    if(!rst) begin
      if(req && gnt) begin
        if(we) begin
          for(int l=0;l<64;l++) if(mask[l]) dram[addr+l]<=wd[32*l+:32];
          wpend<=7;
        end else begin
          for(int l=0;l<64;l++) dp[0][32*l+:32]<=dram[addr+l];
          if(cmd.op==OP_WAITW) polls<=polls+1;
        end
      end
      if(tg) for(int l=0;l<64;l++) begin
        if(tr[l]) trd[l]<=tmem[tra[l]];
        if(tw[l]) tmem[twa[l]]<=twd[l];
      end
      if(held) held_count<=held_count+1;
    end
    if(cycle>20000) $fatal(1,"DMA timeout op=%h reserved=%0d available=%0d fence=%b err=%b polls=%0d",cmd.op,dut.reserved,dut.available,dut.fence,err,polls);
  end
  task automatic launch(input logic [7:0] op,input int ext,tm,n,cmp=0,wm=-1,iv=0,to=0);
    @(negedge clk);cmd='0;cmd.op=op;cmd.w1=ext*4;cmd.w2=tm;cmd.w3=n;cmd.flags=8'(cmp);cmd.w4=wm;cmd.w5=iv;cmd.w6=to;start=1;
    @(negedge clk);start=0;
  endtask
  task automatic finish_cmd;
    wait(done);@(negedge clk);
    if(err) $fatal(1,"unexpected DMA error");
  endtask
  initial begin
    for(int i=0;i<4096;i++) dram[i]=32'h12340000+i;
    for(int i=0;i<262144;i++) tmem[i]=32'hdeadbeef;
    repeat(8) @(negedge clk);rst=0;
    // First/last native masks, depth wrap, both logical TMEM pools.
    launch(OP_LD,13,131060,901);finish_cmd();
    for(int i=0;i<901;i++) if(tmem[131060+i]!==dram[13+i]) $fatal(1,"LD %0d",i);
    if(tmem[131059]!==32'hdeadbeef || tmem[131961]!==32'hdeadbeef) $fatal(1,"LD guard");
    launch(OP_ST,1401,131060,901);finish_cmd();
    for(int i=0;i<901;i++) if(dram[1401+i]!==dram[13+i]) $fatal(1,"ST %0d",i);
    if(dram[1400]!==32'h12340578 || dram[2302]!==32'h123408fe) $fatal(1,"ST mask guard");
    // Failed polls, host update, exact one-word write with a masked comparison.
    dram[37]=0;launch(OP_WAITW,37,150000,5,0,255,5,500);
    wait(polls>=3);@(negedge clk);dram[37]=32'h12340005;finish_cmd();
    if(tmem[150000]!==32'h12340005 || held_count!=1) $fatal(1,"WAITW delivery");
    launch(OP_WAITW,38,150001,0,1,-1,0,500);finish_cmd();
    launch(OP_WAITW,39,150002,32'h12340020,2,-1,0,500);finish_cmd();
    // Timeout during a polling interval must terminate polling without a write.
    launch(OP_WAITW,40,150003,0,0,-1,1000,30);
    wait(err);repeat(10) @(negedge clk);
    if(tmem[150003]!==32'hdeadbeef || req) $fatal(1,"WAITW timeout side effect");
    $display("DCIM256_TEST_PASS DMA masks, wrap, pools, response stalls and WAITW");$finish;
  end
endmodule
