`timescale 1ns/1ps
module tb_tmem_wide;
  localparam int WORDS=4096;
  logic clk=0,rst=1,dump=0;always #5 clk=~clk;
  logic [1:0][63:0] r_req=0,w_en=0;
  logic [1:0][63:0][31:0] r_addr=0,r_data,w_addr=0,w_data=0;
  logic [1:0] r_take,r_ready,w_take,w_ready;
  assign r_take=r_ready,w_take=w_ready;
  otpu_tmem_wide #(.WORDS(WORDS),.NRP(2),.NWP(2)) dut(.clk,.rst,.dump,
    .r_req,.r_addr,.r_take,.r_ready,.r_data,.w_en,.w_take,.w_ready,.w_addr,.w_data);
  task automatic write_pair(input int base0,base1,step);
    int count;
    @(negedge clk);
    for(int l=0;l<64;l++) begin
      w_addr[0][l]=base0+l*step;w_data[0][l]=32'(base0+l*step)^32'h13572468;
      w_addr[1][l]=base1+l*step;w_data[1][l]=32'(base1+l*step)^32'h13572468;
    end
    w_en='1;count=0;
    while(|w_en) begin
      @(posedge clk);count++;
      if(count>256) $fatal(1,"write starvation");
      for(int p=0;p<2;p++) if(w_ready[p]) begin
        @(negedge clk);w_en[p]=0;
      end
    end
    repeat(3) @(negedge clk);
  endtask
  task automatic read_pair(input int base0,base1,step);
    int count;
    logic [1:0] taken;
    @(negedge clk);taken=0;
    for(int l=0;l<64;l++) begin r_addr[0][l]=base0+l*step;r_addr[1][l]=base1+l*step;end
    r_req='1;count=0;
    while(taken!=3) begin
      @(posedge clk);count++;
      if(count>256) $fatal(1,"read starvation");
      for(int p=0;p<2;p++) if(r_ready[p] && !taken[p]) begin
        taken[p]=1;
        #1;
        for(int l=0;l<64;l++)
          if(r_data[p][l] !== (r_addr[p][l]^32'h13572468))
            $fatal(1,"TMEM p%0d l%0d a%0d got%h",p,l,r_addr[p][l],r_data[p][l]);
        @(negedge clk);r_req[p]=0;
      end
    end
  endtask
  initial begin
    repeat(8) @(negedge clk);rst=0;
    write_pair(0,2048,1);read_pair(0,2048,1);
    // Same pool/banks with distinct addresses: fair arbitration and lane replay.
    write_pair(128,129,2);read_pair(128,129,2);
    // 32 different rows per bank across both pools; gather must retain early data.
    write_pair(0,32,64);read_pair(0,32,64);
    // A future conflicted request must not overwrite an older synchronous
    // response while the execution pipeline is frozen (MAX/MIN exposed this).
    @(negedge clk);r_req[0]=1;r_addr[0][0]=0;
    @(posedge clk);#1;
    if(r_data[0][0]!==32'h13572468) $fatal(1,"first response");
    @(negedge clk);
    for(int l=0;l<16;l++) begin r_req[0][l]=1;r_addr[0][l]=64*(l+1);end
    for(int i=0;i<15;i++) begin
      @(posedge clk);#1;
      if(r_data[0][0]!==32'h13572468) $fatal(1,"response changed before grant");
    end
    @(posedge clk);#1;
    for(int l=0;l<16;l++) if(r_data[0][l]!==((64*(l+1))^32'h13572468))
      $fatal(1,"gather final response");
    @(negedge clk);r_req=0;dump=1;
    @(negedge clk);dump=0;
    repeat(2) @(negedge clk);
    $display("DCIM256_TEST_PASS TMEM pools, conflicts, gathered reads and fair writes");$finish;
  end
  initial begin #100000;$fatal(1,"TMEM timeout");end
endmodule
