`timescale 1ns/1ps
module tb_mc2048;
  logic clk=0,mclk=0,rst=1;always #5 clk=~clk;always #2 mclk=~mclk;
  logic wx_req=0,wx_ready,wx_rvalid,b_req=0,b_ready,b_we=0,b_rvalid,b_rtag;
  logic [31:0] wx_addr=0,b_addr=0,a_addr=0,qw_addr=0;
  logic [2047:0] wx_rdata,b_rdata,b_wdata=0,qw_data=0;
  logic [63:0] b_wmask='1;
  logic a_req=0,a_ready,a_rvalid,qw_req=0,qw_ready,wr_idle,rd_idle;
  logic [255:0] a_rdata,qw_be='1;
  logic nv,nw,nready,nrv,nidle;
  logic [23:0] line;
  logic [2047:0] nd,nrd;
  logic [255:0] nbe;
  otpu_mc2048 #(.DEPTH(16)) dut(.clk,.rst,.mem_clk(mclk),.mem_rst(rst),
    .wx_req,.wx_low(1'b1),.wx_ready,.wx_addr,.wx_rvalid,.wx_rdata,.b_req,.b_ready,.b_we,.b_addr,.b_wdata,.b_wmask,
    .b_rvalid,.b_rtag,.b_rdata,.a_req,.a_ready,.a_addr,.a_rvalid,.a_rdata,
    .qw_req,.qw_ready,.qw_addr,.qw_data,.qw_be,.wr_idle,.rd_idle,
    .n_valid(nv),.n_write(nw),.n_ready(nready),.n_line(line),.n_wdata(nd),.n_byte_en(nbe),
    .n_rvalid(nrv),.n_rdata(nrd),.n_wr_idle(nidle));
  logic [3:0] vr=0;
  logic [2047:0] rr[4];
  int mc=0,writes=0,xgot=0,bgot=0,agot=0;
  int denied[4]='{0,0,0,0};
  logic held_native=0;
  logic [2328:0] held_packet;
  assign nready=mc%7!=0;assign nrv=vr[3];assign nrd=rr[3];assign nidle=mc%13==0;
  always @(posedge mclk) begin
    mc<=mc+1;vr[0]<=!rst && nv && nready && !nw;
    for(int i=1;i<4;i++) begin vr[i]<=vr[i-1];rr[i]<=rr[i-1];end
    for(int w=0;w<64;w++) rr[0][32*w+:32]<=32'(line*64+w);
    if(!rst && nv && nready && nw) begin
      writes<=writes+1;
      if(nbe!=='1) $fatal(1,"native mask");
    end
    if(!rst) begin
      if(held_native && (!nv || {nw,line,nd,nbe}!==held_packet))
        $fatal(1,"native command changed under backpressure");
      held_native<=nv && !nready;held_packet<={nw,line,nd,nbe};
      // Three low-water weight grants, then round-robin competing service:
      // a continuously eligible non-weight source waits at most 12 grants.
      if(nv && nready) for(int p=1;p<4;p++) begin
        if(!dut.eligible[p] || dut.service==p) denied[p]<=0;
        else begin
          denied[p]<=denied[p]+1;
          if(denied[p]>=12) $fatal(1,"MC source %0d starved",p);
        end
      end
    end
  end
  always @(posedge clk) if(!rst) begin
    if(wx_rvalid) begin
      if(wx_rdata[31:0]!==32'(xgot*64)) $fatal(1,"weight response %0d %h",xgot,wx_rdata[31:0]);
      xgot<=xgot+1;
    end
    if(b_rvalid) begin
      if(b_rdata[31:0]!==32'(4096+bgot*64)) $fatal(1,"DMA response");bgot<=bgot+1;
    end
    if(a_rvalid) begin
      if(a_rdata[31:0]!==32'(8192+agot*8)) $fatal(1,"scale response %0d %h",agot,a_rdata[31:0]);
      agot<=agot+1;
    end
  end
  initial begin
    repeat(10) @(negedge clk);rst=0;
    fork
      begin for(int n=0;n<100;n++) begin
        wx_req=1;wx_addr=n*64;do @(posedge clk);while(!wx_ready);@(negedge clk);
      end wx_req=0;end
      begin for(int n=0;n<100;n++) begin
        b_req=1;b_addr=4096+n*64;do @(posedge clk);while(!b_ready);@(negedge clk);
      end b_req=0;end
      begin for(int n=0;n<100;n++) begin
        a_req=1;a_addr=8192+n*8;do @(posedge clk);while(!a_ready);@(negedge clk);
      end a_req=0;end
      begin for(int n=0;n<100;n++) begin
        qw_req=1;qw_addr=16384+n*64;do @(posedge clk);while(!qw_ready);@(negedge clk);
      end qw_req=0;end
    join
    wait(xgot==100 && bgot==100 && agot==100);wait(wr_idle && rd_idle);
    if(writes!=100) $fatal(1,"write visibility");
    $display("DCIM256_TEST_PASS mc2048 asynchronous 400 transactions");$finish;
  end
  initial begin #200000;$fatal(1,"MC timeout");end
endmodule
