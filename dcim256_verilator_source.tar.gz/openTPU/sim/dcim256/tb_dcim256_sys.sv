`timescale 1ns/1ps
// Sequencer through asynchronous MC, with stalls and native byte-mask writes.
module tb_dcim256_sys;
  import otpu_pkg::*;
  import dcim256_tb_ref::*;
  localparam int N=256,ORS=260,PROGRAM='h300000,WEIGHT='h80000,OUTPUT='h280000,QDATA='h200003,QSCALE='h240000;
  logic clk=0,mem_clk=0;always #5 clk=~clk;always #2 mem_clk=~mem_clk;
  logic sys_rst=1,mem_rst=1,run_rst=1,ld_start=0,ld_busy,halted,error;
  logic [31:0] rinit[8],ld_n=0,icount;
  logic nv,nw,nready,nrv,nidle;
  logic [23:0] line;
  logic [2047:0] nd,nrd;
  logic [255:0] nbe;
  otpu_dcim256_sys dut(.clk,.mem_clk,.sys_rst,.mem_rst,.run_rst,.rinit,
    .ld_start,.ld_addr(32'(PROGRAM)),.ld_n,.ld_busy,.halted,.error,.icount,
    .n_valid(nv),.n_write(nw),.n_ready(nready),.n_line(line),.n_wdata(nd),
    .n_byte_en(nbe),.n_rvalid(nrv),.n_rdata(nrd),.n_wr_idle(nidle));
  logic [31:0] memory[1048576];
  logic [4:0] validpipe=0;
  logic [2047:0] readpipe[5];
  int mc=0,writewait=0,cycles=0,pops=0,widewrites=0,firstpop,lastpop,maxgap,lastn;
  assign nready=mc%11!=0 && mc%11!=1;
  assign nrv=validpipe[4],nrd=readpipe[4],nidle=writewait==0;
  always @(posedge mem_clk) begin
    mc<=mc+1;
    validpipe[0]<=!mem_rst && nv && nready && !nw;
    for(int i=1;i<5;i++) begin validpipe[i]<=validpipe[i-1];readpipe[i]<=readpipe[i-1];end
    if(writewait>0) writewait<=writewait-1;
    if(!mem_rst && nv && nready) begin
      if(nw) begin
        for(int b=0;b<256;b++) if(nbe[b]) memory[line*64+b/4][8*(b%4)+:8]<=nd[8*b+:8];
        writewait<=3;
      end else for(int w=0;w<64;w++) readpipe[0][32*w+:32]<=memory[line*64+w];
    end
  end
  always @(posedge clk) begin
    cycles<=cycles+1;
    if(!run_rst && dut.u_slice.mxu_pop) begin
      pops<=pops+1;
      if(pops==0) firstpop<=cycles;
      else if(cycles-lastpop>maxgap) maxgap<=cycles-lastpop;
      lastpop<=cycles;
    end
    if(!run_rst && (&dut.u_slice.mxu_wen)) begin
      widewrites<=widewrites+1;
    end
    if(cycles>100000) $fatal(1,"system timeout pc=%0d",icount);
    if(!run_rst && error) $fatal(1,"system sequencer error pc=%0d",icount);
  end
  function automatic int av(input int r,k);
    return ((k+r)%3==0)?0:(((k+r)%3==1)?127:-127);
  endfunction
  function automatic int wv(input int n,k);
    return ((n*17+k*13)%256)-128;
  endfunction
  task automatic putcmd(input int n,input cmd_t c);
    logic [255:0] bits;
    bits={c.w7,c.w6,c.w5,c.w4,c.w3,c.w2,c.w1,c.flags,16'd0,c.op};
    for(int k=0;k<8;k++) memory[PROGRAM/4+n*8+k]=bits[k*32+:32];
  endtask
  task automatic run_case(input int kb);
    cmd_t c;
    int pc,sum;
    logic [31:0] expected;
    sys_rst=1;mem_rst=1;run_rst=1;ld_start=0;
    repeat(16) @(negedge clk);
    pops=0;widewrites=0;maxgap=0;
    for(int r=0;r<16;r++) for(int k=0;k<kb*256;k++) begin
      memory[r*kb*256+k]=int_fp32(av(r,k));
    end
    for(int n=0;n<N;n++) for(int k=0;k<kb*256;k++)
      memory[WEIGHT/4+(n*kb*256+k)/4][8*(k%4)+:8]=8'(wv(n,k));
    for(int k=QDATA/4-1;k<QDATA/4+16*N/4+2;k++) memory[k]='ha5a5a5a5;
    pc=0;
    c='0;c.op=OP_LD;c.w1=0;c.w2=0;c.w3=16*kb*256;putcmd(pc++,c);
    c='0;c.op=OP_QACT;c.w1=0;c.w2={16'(kb),8'd0,8'd16};c.w3=kb*256;putcmd(pc++,c);
    c='0;c.op=OP_MM;c.flags=1;c.w1=WEIGHT;c.w3=65536;
    c.w4={8'd0,8'(kb),16'(N)};c.w5=kb*256;c.w6={8'd0,8'd16,16'(ORS)};putcmd(pc++,c);
    c='0;c.op=OP_VOP;c.w1=131072;c.w2=65536;c.w4={16'(N),16'd16};
    c.w5={16'(ORS),16'(ORS)};c.w6={6'd0,B_SCALAR,V_ADD,16'd0};c.w7=32'h3f800000;putcmd(pc++,c);
    for(int r=0;r<16;r++) begin
      c='0;c.op=OP_ST;c.w1=OUTPUT+r*N*4;c.w2=131072+r*ORS;c.w3=N;putcmd(pc++,c);
    end
    // Quantize known +/-127 activation rows, including unaligned masked writes.
    c='0;c.op=OP_QST;c.flags=1;c.w1=0;c.w2=QDATA;c.w3=QSCALE;
    c.w4={16'd1,16'd16};c.w5=kb*256;c.w6=N;c.w7=1;putcmd(pc++,c);
    c='0;c.op=OP_HALT;putcmd(pc++,c);ld_n=pc;
    sys_rst=0;mem_rst=0;repeat(6) @(negedge clk);ld_start=1;
    @(negedge clk);ld_start=0;wait(ld_busy);wait(!ld_busy);
    repeat(6) @(negedge clk);run_rst=0;wait(halted);repeat(12) @(negedge clk);
    for(int r=0;r<16;r++) for(int n=0;n<N;n++) begin
      sum=0;for(int k=0;k<kb*256;k++) sum+=av(r,k)*wv(n,k);
      expected=int_fp32(sum+1);
      if(memory[OUTPUT/4+r*N+n]!==expected)
        $fatal(1,"KB%0d r%0d n%0d got %h expected %h",kb,r,n,memory[OUTPUT/4+r*N+n],expected);
    end
    for(int r=0;r<16;r++) for(int k=0;k<N;k++)
      if(memory[(QDATA+r*N+k)/4][8*((QDATA+k)%4)+:8]!==8'(av(r,k)))
        $fatal(1,"QST KB%0d r%0d k%0d byte %h expected %h",kb,r,k,
          memory[(QDATA+r*N+k)/4][8*((QDATA+k)%4)+:8],8'(av(r,k)));
    if(memory[QDATA/4][23:0]!==24'ha5a5a5) $fatal(1,"QST first mask");
    for(int r=0;r<16;r++) if(memory[QSCALE/4+r]!==32'h3f800000) $fatal(1,"QST scale");
    if(pops!=N*kb || widewrites!=N) $fatal(1,"utilization pops=%0d write16=%0d",pops,widewrites);
    $display("system KB=%0d: checked 4096 FP32 + 4096 INT8; pops=%0d span=%0d maxgap=%0d",kb,pops,lastpop-firstpop+1,maxgap);
  endtask
  initial begin
    for(int k=0;k<8;k++) rinit[k]=0;
    run_case(1);run_case(2);run_case(10);run_case(16);
    $display("DCIM256_TEST_PASS complete system KB1/2/10/16 cycles=%0d",cycles);$finish;
  end
endmodule

