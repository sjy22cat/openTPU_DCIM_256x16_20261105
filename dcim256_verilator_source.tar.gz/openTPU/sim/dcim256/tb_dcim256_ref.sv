`timescale 1ns/1ps
// XSim-only oracle check: portable reference versus native shortreal conversion.
module tb_dcim256_ref;
  import dcim256_tb_ref::*;
  int checked=0;
  task automatic check(input int x);
    shortreal reference;
    reference=x;
    if(int_fp32(x)!==$shortrealtobits(reference))
      $fatal(1,"integer FP32 reference x=%0d got=%h expected=%h",x,int_fp32(x),$shortrealtobits(reference));
    checked++;
  endtask
  initial begin
    int seed,sum,kb;
    seed=25616;
    check(0);check(-2147483648);check(2147483647);
    for(int i=0;i<31;i++) for(int offset=-3;offset<=3;offset++) begin
      check(int'((32'd1<<i)+32'(offset)));
      check(-int'((32'd1<<i)+32'(offset)));
    end
    for(int i=0;i<20000;i++) begin seed=seed*1664525+1013904223;check(seed);end
    for(int r=0;r<3;r++) for(int k=0;k<137;k++) check(r*200+k+1);
    for(int i=0;i<4;i++) begin
      case(i) 0:kb=1;1:kb=2;2:kb=10;3:kb=16;endcase
      for(int r=0;r<16;r++) for(int n=0;n<256;n++) begin
        sum=0;
        for(int k=0;k<kb*256;k++)
          sum+=(((k+r)%3==0)?0:(((k+r)%3==1)?127:-127))*(((n*17+k*13)%256)-128);
        check(sum+1);
      end
    end
    $display("DCIM256_TEST_PASS portable FP32 reference checks=%0d",checked);$finish;
  end
endmodule
