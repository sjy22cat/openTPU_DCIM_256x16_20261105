`timescale 1ns/1ps
module tb_qst_collect;
  logic clk=0,rst=1,valid=0,ready,flush=0,idle,req,grant,commit=1;
  always #5 clk=~clk;
  logic [63:0] mask=0;
  logic [63:0][7:0] bytes_in;
  logic [31:0] base=0,stride=1,addr;
  logic [2047:0] data;
  logic [255:0] byte_en;
  otpu_qst_collect #(.LINES(64)) dut(.clk,.rst,.valid,.commit,.ready,.flush,.idle,
    .req,.grant,.mask,.bytes_in,.base,.stride,.addr,.data,.byte_en);
  logic [7:0] mem[2097152],expected[2097152];
  int cycle=0,writes=0;
  assign grant=cycle%5>1;
  always @(posedge clk) begin
    cycle<=cycle+1;
    if(req && grant) begin
      writes<=writes+1;
      for(int i=0;i<256;i++) if(byte_en[i]) mem[4*addr+i]<=data[8*i+:8];
    end
  end
  task automatic send(input int a,s,n,offset);
    @(negedge clk);valid=1;base=a;stride=s;
    for(int l=0;l<64;l++) begin mask[l]=l<n;bytes_in[l]=8'(offset+l);end
    do @(posedge clk);while(!ready || !commit);
    for(int l=0;l<n;l++) expected[a+l*s]=8'(offset+l);
    @(negedge clk);valid=0;
  endtask
  task automatic burst(input int a,s);
    wait(ready);@(negedge clk);
    for(int t=0;t<16;t++) begin
      valid=1;base=a+t;stride=s;mask='1;
      for(int l=0;l<64;l++) bytes_in[l]=8'(t+l);
      @(posedge clk);
      if(!ready) $fatal(1,"transpose throughput stride=%0d token=%0d",s,t);
      for(int l=0;l<64;l++) expected[a+t+l*s]=8'(t+l);
      @(negedge clk);
    end
    valid=0;
  endtask
  initial begin
    for(int i=0;i<2097152;i++) begin mem[i]=8'haa;expected[i]=8'haa;end
    repeat(5) @(negedge clk);rst=0;
    // Unaligned writes cross a 256-byte boundary, retaining untouched bytes.
    send(253,1,64,1);
    // Sixteen token columns of V transpose: same 64 external rows, different bytes.
    for(int t=0;t<16;t++) send(4096+t,256,64,t);
    @(negedge clk);flush=1;wait(idle);@(negedge clk);
    for(int i=0;i<64;i++) if(mem[253+i]!==8'(i+1)) $fatal(1,"unaligned QST");
    for(int l=0;l<64;l++) for(int t=0;t<16;t++)
      if(mem[4096+l*256+t]!==8'(t+l)) $fatal(1,"transpose QST l=%0d t=%0d",l,t);
    if(mem[252]!==8'haa || mem[317]!==8'haa) $fatal(1,"byte enable overwrite");
    // Same RAM bank and same cache index collisions replay accepted vectors.
    // This includes more than one external line hashing to a slot in one vector.
    flush=0;
    send(65539,64,64,11);
    send(65539,16384,8,21);
    send(200000,0,64,31);
    send(100001,7,63,41);
    @(negedge clk);commit=0;valid=1;base=220003;stride=1;mask='1;
    for(int l=0;l<64;l++) bytes_in[l]=8'(51+l);
    repeat(10) @(negedge clk);
    commit=1;
    do @(posedge clk);while(!ready);
    for(int l=0;l<64;l++) expected[220003+l]=8'(51+l);
    @(negedge clk);valid=0;flush=1;wait(idle);@(negedge clk);
    flush=0;burst(262144,4096);
    flush=1;wait(idle);@(negedge clk);
    flush=0;burst(524288,16384);
    flush=1;wait(idle);@(negedge clk);
    for(int i=0;i<2097152;i++) if(mem[i]!==expected[i])
      $fatal(1,"QST byte %0d got=%h expected=%h",i,mem[i],expected[i]);
    $display("DCIM256_TEST_PASS qst_collect transactions=%0d",writes);$finish;
  end
  initial begin #200000;$fatal(1,"QST timeout");end
endmodule
