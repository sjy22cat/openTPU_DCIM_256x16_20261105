`timescale 1ns/1ps
// Sequencer through asynchronous MC, with stalls and native byte-mask writes.
module tb_dcim256_vectors;
  import otpu_pkg::*;
  localparam int PROGRAM='h300000;
  logic clk=0,mem_clk=0;always #5 clk=~clk;always #2 mem_clk=~mem_clk;
  logic sys_rst=1,mem_rst=1,run_rst=1,ld_start=0,ld_busy,halted,error;
  logic [31:0] rinit[8],ld_n=0,icount;
  logic nv,nw,nready,nrv,nidle;
  logic [23:0] line;
  logic [2047:0] nd,nrd;
  logic [255:0] nbe;
  otpu_dcim256_sys dut(.clk,.mem_clk,.sys_rst,.mem_rst,.run_rst,.rinit,
    .ld_start,.ld_addr(32'(PROGRAM)),.ld_n,.ld_busy,.halted,.error,.icount,
    .n_valid(nv),.n_write(nw),.n_ready(nready),.n_line(line),.n_wdata(nd),
    .n_byte_en(nbe),.n_rvalid(nrv),.n_rdata(nrd),.n_wr_idle(nidle));
  logic [31:0] memory[1048576];
  logic [4:0] validpipe=0;
  logic [2047:0] readpipe[5];
  int mc=0,writewait=0,cycles=0,pops=0,widewrites=0,firstpop,lastpop,maxgap,lastn;
  int dots=0,rows=0,meta=0;
  assign nready=mc%11!=0 && mc%11!=1;
  assign nrv=validpipe[4],nrd=readpipe[4],nidle=writewait==0;
  always @(posedge mem_clk) begin
    mc<=mc+1;
    validpipe[0]<=!mem_rst && nv && nready && !nw;
    for(int i=1;i<5;i++) begin validpipe[i]<=validpipe[i-1];readpipe[i]<=readpipe[i-1];end
    if(writewait>0) writewait<=writewait-1;
    if(!mem_rst && nv && nready) begin
      if(nw) begin
        for(int b=0;b<256;b++) if(nbe[b]) memory[line*64+b/4][8*(b%4)+:8]<=nd[8*b+:8];
        writewait<=3;
      end else for(int w=0;w<64;w++) readpipe[0][32*w+:32]<=memory[line*64+w];
    end
  end
  always @(posedge clk) begin
    cycles<=cycles+1;
    if(!run_rst && dut.u_slice.mxu_pop) begin
      pops<=pops+1;

      if(pops==0) firstpop<=cycles;
      else if(cycles-lastpop>maxgap) maxgap<=cycles-lastpop;
      lastpop<=cycles;
    end
    if(!run_rst && (&dut.u_slice.mxu_wen)) begin
      widewrites<=widewrites+1;

    end
    if(cycles>100000) $fatal(1,"system timeout pc=%0d",icount);
    if(!run_rst && error) $fatal(1,"system sequencer error pc=%0d",icount);
  end
  initial begin
    logic [31:0] expected[1048576];
    int params[2];
    string vectors;
    if(!$value$plusargs("vectors=%s",vectors)) vectors="../../build/dcim256_vectors";
    for(int k=0;k<8;k++) rinit[k]=0;
    for(int k=0;k<1048576;k++) begin memory[k]=0;expected[k]=0;end
    $readmemh({vectors,"/input.hex"},memory);
    $readmemh({vectors,"/expected.hex"},expected);
    $readmemh({vectors,"/params.hex"},params);
    ld_n=params[0];
    repeat(16) @(negedge clk);sys_rst=0;mem_rst=0;
    repeat(6) @(negedge clk);ld_start=1;
    @(negedge clk);ld_start=0;wait(ld_busy);wait(!ld_busy);
    repeat(6) @(negedge clk);run_rst=0;wait(halted);repeat(12) @(negedge clk);
    for(int k=0;k<1048576;k++) if(memory[k]!==expected[k])
      $fatal(1,"ISA mismatch word=%h got=%h expected=%h",k,memory[k],expected[k]);
    $display("DCIM256_TEST_PASS ISA comparison instructions=%0d cycles=%0d",params[0],cycles);$finish;
  end
endmodule
