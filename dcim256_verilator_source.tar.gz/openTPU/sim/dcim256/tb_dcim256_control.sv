`timescale 1ns/1ps
// Sequencer through asynchronous MC, with stalls and native byte-mask writes.
module tb_dcim256_control;
  import otpu_pkg::*;
  import dcim256_tb_ref::*;
  localparam int N=256,ORS=260,PROGRAM='h300000,WEIGHT='h80000,OUTPUT='h280000,QDATA='h200003,QSCALE='h240000;
  logic clk=0,mem_clk=0;always #5 clk=~clk;always #2 mem_clk=~mem_clk;
  logic sys_rst=1,mem_rst=1,run_rst=1,ld_start=0,ld_busy,halted,error;
  logic [31:0] rinit[8],ld_n=0,icount;
  logic nv,nw,nready,nrv,nidle;
  logic [23:0] line;
  logic [2047:0] nd,nrd;
  logic [255:0] nbe;
  otpu_dcim256_sys dut(.clk,.mem_clk,.sys_rst,.mem_rst,.run_rst,.rinit,
    .ld_start,.ld_addr(32'(PROGRAM)),.ld_n,.ld_busy,.halted,.error,.icount,
    .n_valid(nv),.n_write(nw),.n_ready(nready),.n_line(line),.n_wdata(nd),
    .n_byte_en(nbe),.n_rvalid(nrv),.n_rdata(nrd),.n_wr_idle(nidle));
  logic [31:0] memory[1048576];
  logic [4:0] validpipe=0;
  logic [2047:0] readpipe[5];
  int mc=0,writewait=0,cycles=0,pops=0,widewrites=0,firstpop,lastpop,maxgap,lastn;
  assign nready=mc%11!=0 && mc%11!=1;
  assign nrv=validpipe[4],nrd=readpipe[4],nidle=writewait==0;
  always @(posedge mem_clk) begin
    mc<=mc+1;
    validpipe[0]<=!mem_rst && nv && nready && !nw;
    for(int i=1;i<5;i++) begin validpipe[i]<=validpipe[i-1];readpipe[i]<=readpipe[i-1];end
    if(writewait>0) writewait<=writewait-1;
    if(!mem_rst && nv && nready) begin
      if(nw) begin
        for(int b=0;b<256;b++) if(nbe[b]) memory[line*64+b/4][8*(b%4)+:8]<=nd[8*b+:8];
        writewait<=3;
      end else for(int w=0;w<64;w++) readpipe[0][32*w+:32]<=memory[line*64+w];
    end
  end
  always @(posedge clk) begin
    cycles<=cycles+1;
    if(!run_rst && dut.u_slice.mxu_pop) begin
      pops<=pops+1;
      if(pops==0) firstpop<=cycles;
      else if(cycles-lastpop>maxgap) maxgap<=cycles-lastpop;
      lastpop<=cycles;
    end
    if(!run_rst && (&dut.u_slice.mxu_wen)) begin
      widewrites<=widewrites+1;
    end
    if(cycles>100000) $fatal(1,"system timeout pc=%0d",icount);
    if(!run_rst && error) $fatal(1,"system sequencer error pc=%0d",icount);
  end
  task automatic putcmd(input int address,input cmd_t c,
    input int ra=0,rb=0,rc=0,rd=0);
    logic [255:0] bits;
    bits={c.w7,c.w6,c.w5,c.w4,c.w3,c.w2,c.w1,c.flags,4'(rd),4'(rc),4'(rb),4'(ra),c.op};
    for(int k=0;k<8;k++) memory[address/4+k]=bits[k*32+:32];
  endtask
  task automatic emit(input cmd_t c,input int ra=0,rb=0,rc=0,rd=0);
    putcmd(PROGRAM+ld_n*32,c,ra,rb,rc,rd);ld_n++;
  endtask
  initial begin
    cmd_t c;
    int f;
    int gather_writes,pc;
    for(int k=0;k<8;k++) rinit[k]=0;
    for(int k=0;k<1048576;k++) memory[k]=0;
    for(int r=0;r<3;r++) for(int k=0;k<137;k++) begin
      f=r*200+k+1;memory['h1000/4+r*137+k]=int_fp32(f);
    end
    memory['h2000/4]=13;
    c='0;c.op=OP_LD;c.w1='h1000;c.w2=600;c.w3=411;emit(c);
    c='0;c.op=OP_LD;c.w1='h2000;c.w2=5000;c.w3=1;emit(c);
    c='0;c.op=OP_GATHER;c.w1=600;c.w2=131075;c.w3={16'd130,16'd3};c.w4=137;c.w5=141;emit(c);
    c='0;c.op=OP_BAR;emit(c);
    c='0;c.op=OP_RLD;c.w1=131080;emit(c,0,0,0,1);
    c='0;c.op=OP_RLD;c.flags=3;c.w1=5000;c.w2=2;emit(c,0,0,0,2);
    c='0;c.op=OP_VOP;c.w1=200000;c.w2=600;c.w4={16'd5,16'd1};c.w6={6'd0,B_SCALAR,V_COPY,16'd0};emit(c,0,1);
    c='0;c.op=OP_VOP;c.w1=200064;c.w2=600;c.w4={16'd5,16'd1};c.w6={6'd0,B_SCALAR,V_COPY,16'd0};emit(c,0,2);
    c='0;c.op=OP_ST;c.w1='h3000;c.w2=200000;c.w3=5;emit(c);
    c='0;c.op=OP_ST;c.w1='h3100;c.w2=200064;c.w3=5;emit(c);
    for(int r=0;r<3;r++) begin
      c='0;c.op=OP_ST;c.w1='h4000+r*768+4;c.w2=131075+r*141;c.w3=130;emit(c);
    end
    // Chained program exercises loader restart without clearing coherent TMEM.
    c='0;c.op=OP_LI;c.w1='h320000;emit(c,0,0,0,3);
    c='0;c.op=OP_LI;c.w1=3;emit(c,0,0,0,4);
    c='0;c.op=OP_HALT;c.flags=1;emit(c,3,4);
    pc='h320000;
    c='0;c.op=OP_GATHER;c.w1=131075;c.w2=10000;c.w3={16'd130,16'd3};c.w4=141;c.w5=137;putcmd(pc,c);pc+=32;
    c='0;c.op=OP_ST;c.w1='h6000;c.w2=10000;c.w3=404;putcmd(pc,c);pc+=32;
    c='0;c.op=OP_HALT;putcmd(pc,c);
    repeat(16) @(negedge clk);sys_rst=0;mem_rst=0;
    repeat(6) @(negedge clk);ld_start=1;
    @(negedge clk);ld_start=0;wait(ld_busy);wait(!ld_busy);
    repeat(6) @(negedge clk);run_rst=0;wait(halted);repeat(12) @(negedge clk);
    for(int r=0;r<3;r++) for(int k=0;k<130;k++) begin
      f=r*200+k+1;
      if(memory[('h4000+r*768+4)/4+k]!==int_fp32(f))
        $fatal(1,"GATHER forward row=%0d col=%0d",r,k);
      if(memory['h6000/4+r*137+k]!==int_fp32(f))
        $fatal(1,"GATHER chain row=%0d col=%0d",r,k);
    end
    for(int k=0;k<5;k++) begin
      f=k+7;if(memory['h3000/4+k]!==int_fp32(f)) $fatal(1,"RLD numeric lane %0d",k);
      f=k+27;if(memory['h3100/4+k]!==int_fp32(f)) $fatal(1,"RLD raw multiply lane %0d",k);
    end
    if(icount!=ld_n+3) $fatal(1,"CHAIN instruction count got=%0d expected=%0d",icount,ld_n+3);
    $display("DCIM256_TEST_PASS control GATHER/BAR/RLD/CHAIN cycles=%0d",cycles);$finish;
  end
endmodule
