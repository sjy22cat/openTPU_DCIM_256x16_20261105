`timescale 1ns/1ps
// Actual sequencer, DMA, QACT, ACT RAM, DCIM, FP32 epilogue, grouped VPU and ST.
module tb_dcim256;
  import otpu_pkg::*;
  logic clk=0;always #5 clk=~clk;
  logic sys_rst=1,rst=1,ld_start=0,ld_busy,halted,error;
  logic [31:0] rinit[8],icount[1];
  otpu_top #(.D(256),.MCOLS(16),.ACT_ROWS(16),.ACT_BLOCKS(128),.LANES(64),
    .ULANES(16),.QLANES(64),.QUANT_NB(16),.MXU_IMPL(4),.MXU_E(16),
    .VPU_CL(16),.TMEM_WORDS(262144),.IMEM_WORDS(65536),.FIFO_DEPTH(1024),
    .RPB(512),.WPB(1),.WIN(16),.DRAM_WORDS(131072),.COLL_GATHER(0)) dut (
    .clk,.clk_f(clk),.sys_rst,.rst,.rinit,.ld_start,.ld_addr(32'h70000),.ld_n(32'd6),
    .ld_busy,.all_halted(halted),.any_error(error),.icount,.dump(1'b0));
  task automatic putcmd(input int n,input cmd_t c);
    logic [255:0] bits;
    bits={c.w7,c.w6,c.w5,c.w4,c.w3,c.w2,c.w1,c.flags,16'd0,c.op};
    for(int k=0;k<8;k++) dut.g_slice[0].g_dram.u_dram.mem['h1c000+n*8+k]=bits[k*32+:32];
  endtask
  int cycles=0,pops=0,widewrites=0;
  always @(posedge clk) begin
    cycles<=cycles+1;
    if(dut.g_slice[0].u_slice.mxu_pop) pops<=pops+1;
    if(&dut.g_slice[0].u_slice.mxu_wen) widewrites<=widewrites+1;
    if(cycles>10000) $fatal(1,"timeout pc=%0d",icount[0]);
    if(error) $fatal(1,"sequencer error");
  end
  initial begin
    cmd_t c;
    for(int k=0;k<8;k++) rinit[k]=0;
    repeat(12) @(negedge clk);
    for(int k=0;k<16*256;k++) dut.g_slice[0].g_dram.u_dram.mem[k]=32'h3f800000;
    for(int k=0;k<64*256/4;k++) dut.g_slice[0].g_dram.u_dram.mem['h8000+k]=32'h01010101;
    c='0;c.op=OP_LD;c.w1=0;c.w2=0;c.w3=4096;putcmd(0,c);
    c='0;c.op=OP_QACT;c.w1=0;c.w2={16'd1,8'd0,8'd16};c.w3=256;putcmd(1,c);
    c='0;c.op=OP_MM;c.flags=8'h01;c.w1='h20000;c.w3=8192;
    c.w4={8'd0,8'd1,16'd64};c.w5=256;c.w6={8'd0,8'd16,16'd68};putcmd(2,c);
    c='0;c.op=OP_VOP;c.w1=16384;c.w2=8192;c.w4={16'd64,16'd16};
    c.w5={16'd68,16'd68};c.w6={6'd0,B_SCALAR,V_ADD,16'd0};c.w7=32'h3f800000;putcmd(3,c);
    // Copy first output row through DMA; checks the full path to external memory.
    c='0;c.op=OP_ST;c.w1='h60000;c.w2=16384;c.w3=64;putcmd(4,c);
    c='0;c.op=OP_HALT;putcmd(5,c);
    sys_rst=0;repeat(4) @(negedge clk);ld_start=1;
    @(negedge clk);ld_start=0;
    wait(ld_busy);wait(!ld_busy);repeat(4) @(negedge clk);rst=0;
    wait(halted);repeat(10) @(negedge clk);
    for(int k=0;k<64;k++)
      if(dut.g_slice[0].g_dram.u_dram.mem['h18000+k]!==32'h43808000)
        $fatal(1,"value at %0d got %h expected 257",k,dut.g_slice[0].g_dram.u_dram.mem['h18000+k]);
    if(pops!=64 || widewrites!=64) $fatal(1,"utilization pops=%0d widewrites=%0d",pops,widewrites);
    $display("DCIM256_TEST_PASS cycles=%0d pops=%0d writes16=%0d",cycles,pops,widewrites);$finish;
  end
endmodule
