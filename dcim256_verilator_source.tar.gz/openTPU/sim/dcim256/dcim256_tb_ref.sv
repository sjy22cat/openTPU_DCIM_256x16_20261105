// Independent integer-to-IEEE754 reference for the directed testbenches.
// Avoid shortreal: Verilator may promote it to 64-bit real. Round nearest/even.
package dcim256_tb_ref;
  function automatic logic [31:0] int_fp32(input int value);
    logic negative;
    logic [31:0] magnitude, remainder, halfway;
    logic [24:0] significand;
    int leading, shift;
    negative=value<0;
    magnitude=negative ? -$unsigned(value) : $unsigned(value);
    if(magnitude==0) return 32'd0;
    leading=0;
    for(int i=0;i<32;i++) if(magnitude[i]) leading=i;
    if(leading<=23) significand=25'(magnitude << (23-leading));
    else begin
      shift=leading-23;
      significand=25'(magnitude >> shift);
      remainder=magnitude & ((32'd1 << shift)-1);
      halfway=32'd1 << (shift-1);
      if(remainder>halfway || (remainder==halfway && significand[0]))
        significand=significand+1'b1;
      if(significand[24]) begin significand=significand>>1;leading++;end
    end
    return {negative,8'(leading+127),significand[22:0]};
  endfunction
endpackage
