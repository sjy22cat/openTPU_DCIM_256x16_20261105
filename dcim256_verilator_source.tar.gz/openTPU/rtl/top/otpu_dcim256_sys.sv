// Device-independent system boundary. Attach a real 2048-bit native controller
// (active-high byte enables) and supply mem_clk with adequate sustained bandwidth.
// Both resets must be asserted together; run_rst drains through the existing loader.
module otpu_dcim256_sys
  import otpu_pkg::*;
(
  input logic clk,mem_clk,sys_rst,mem_rst,run_rst,
  input logic [31:0] rinit[8],
  input logic ld_start,
  input logic [31:0] ld_addr,ld_n,
  output logic ld_busy,halted,error,
  output logic [31:0] icount,
  output logic n_valid,n_write,
  input logic n_ready,
  output logic [23:0] n_line,
  output logic [2047:0] n_wdata,
  output logic [255:0] n_byte_en,
  input logic n_rvalid,
  input logic [2047:0] n_rdata,
  input logic n_wr_idle
);
  logic wx_req,wx_ready,wx_rvalid,qw_req,qw_ready;
  logic [31:0] wx_addr,qw_addr;
  logic [2047:0] wx_rdata,qw_data;
  logic [255:0] qw_be;
  logic [15:0] wx_level;
  logic wx_low;
  // Hysteresis leaves FIFO room for outstanding responses and complete KB rows.
  always_ff @(posedge clk)
    if(sys_rst) wx_low<=1;
    else if(wx_level<128) wx_low<=1;
    else if(wx_level>=384) wx_low<=0;
  logic b_req,b_ready,b_we,b_rvalid,b_rtag,b_tag,b_par;
  logic [31:0] b_addr,a_addr;
  logic [2047:0] b_wdata,b_rdata;
  logic [63:0] b_wmask;
  logic a_req,a_ready,a_rvalid,wr_idle,rd_idle;
  logic [255:0] a_rdata;
  logic coll_req,coll_gnt,coll_ack;
  logic [0:0][63:0] coll_ren;
  logic [63:0] coll_wen;
  logic [0:0][63:0][31:0] coll_raddr,coll_rdata;
  logic [63:0][31:0] coll_waddr,coll_wdata;
  cmd_t coll_cmd[1];
  otpu_slice #(.D(256),.MCOLS(16),.ACT_ROWS(16),.ACT_BLOCKS(128),.LANES(64),
    .ULANES(16),.QLANES(64),.QUANT_NB(16),.MXU_IMPL(4),.MXU_E(16),.VPU_CL(16),
    .FIFO_DEPTH(1024),.TMEM_WORDS(262144),.IMEM_WORDS(65536),.RPB(512),.WPB(1),
    .WIN(16),.HAS_DSTEP(0)) u_slice(
    .clk,.clk_f(clk),.sys_rst,.rst(run_rst),.rinit,.ld_start,.ld_addr,.ld_n,.ld_busy,
    .a_rdy(a_ready),.b_rdy(b_ready),.sw_rdy(1'b1),.wr_idle,.rd_idle,
    .a_req,.a_we(),.a_addr,.a_wdata(),.a_be(),.a_rvalid,.a_rdata,
    .sw_req(),.sw_addr(),.sw_wdata(),.sw_be(),
    .wx_req,.wx_level,.wx_addr,.wx_ready,.wx_rvalid,.wx_rdata,.qw_req,.qw_ready,.qw_addr,.qw_data,.qw_be,
    .b_req,.b_tag,.b_we,.b_wmask,.b_wdata,.b_addr,.b_par,.b_rvalid,.b_rtag,.b_rdata,
    .coll_req,.coll_cmd(coll_cmd[0]),.coll_ack,.coll_ren(coll_ren[0]),
    .coll_raddr(coll_raddr[0]),.coll_rdata(coll_rdata[0]),
    .coll_wen,.coll_waddr,.coll_wdata,.coll_gnt_local(coll_gnt),.coll_gnt(1'b1),
    .halted,.error,.wait_to(),.a_inval(),.icount,.pf(),.dump(1'b0));
  // A one-slice GATHER still copies between TMEM views. Acknowledge it only
  // after the collective's final accepted write, using the slice's grant.
  otpu_coll #(.S(1),.LANES(64)) u_coll(
    .clk,.rst(sys_rst||run_rst),.req({coll_req}),.cmds(coll_cmd),.gnt(coll_gnt),
    .ack(coll_ack),.r_en(coll_ren),.r_addr(coll_raddr),.r_data(coll_rdata),
    .w_en(coll_wen),.w_addr(coll_waddr),.w_data(coll_wdata));
  otpu_mc2048 u_mc(
    .clk,.rst(sys_rst),.mem_clk,.mem_rst,
    .wx_req,.wx_low,.wx_ready,.wx_addr,.wx_rvalid,.wx_rdata,
    .b_req,.b_ready,.b_we,.b_addr,.b_wdata,.b_wmask,.b_rvalid,.b_rtag,.b_rdata,
    .a_req,.a_ready,.a_addr,.a_rvalid,.a_rdata,
    .qw_req,.qw_ready,.qw_addr,.qw_data,.qw_be,.wr_idle,.rd_idle,
    .n_valid,.n_write,.n_ready,.n_line,.n_wdata,.n_byte_en,.n_rvalid,.n_rdata,.n_wr_idle);
endmodule
