// Two independent pools, 64 banks/pool, one coherent copy per read port.
// Conflicting lanes gather over cycles while their execution group holds.
// A final read and a group grant may coincide; synchronous data returns next edge.
module otpu_tmem_wide #(
  parameter int WORDS=262144, NRP=8, NWP=4, SID=0
)(
  input logic clk,rst,dump,
  input logic [NRP-1:0][63:0] r_req,
  input logic [NRP-1:0][63:0][31:0] r_addr,
  input logic [NRP-1:0] r_take,
  output logic [NRP-1:0] r_ready,
  output logic [NRP-1:0][63:0][31:0] r_data,
  input logic [NWP-1:0][63:0] w_en,
  input logic [NWP-1:0] w_take,
  output logic [NWP-1:0] w_ready,
  input logic [NWP-1:0][63:0][31:0] w_addr,w_data
);
  localparam int POOL=WORDS/2, ROWS=POOL/64, AW=$clog2(ROWS), PS=$clog2(POOL);
  initial if(WORDS<256 || (WORDS & (WORDS-1))!=0 || NWP<2 || (NWP & (NWP-1))!=0)
    $fatal(1,"wide TMEM requires power-of-two WORDS and write ports");
`ifndef SYNTHESIS
  logic [31:0] img[WORDS];
  logic dump_q=0;
  always @(posedge clk) dump_q<=dump;
`endif
  logic [NRP-1:0][63:0] collected, selected;
  logic [NRP-1:0][127:0] readbank;
  logic [NRP-1:0][127:0][AW-1:0] readrow;
  logic [NWP-1:0][63:0] we, written, chosen;
  logic [NWP-1:0][63:0][31:0] wa,wd;
  logic [$clog2(NWP)-1:0] priority_port;
  always_comb begin
    logic [127:0] occupied;
    int p,bank;
    occupied=0;chosen=0;w_ready='1;
    for(int k=0;k<NWP;k++) begin
      p=(int'(priority_port)+k)%NWP;
      for(int l=0;l<64;l++) if(w_en[p][l] && !written[p][l]) begin
        bank=int'(w_addr[p][l][5:0])+64*int'(w_addr[p][l][PS]);
        if(!occupied[bank]) begin occupied[bank]=1;chosen[p][l]=1;end
      end
      w_ready[p]=((written[p]|chosen[p])&w_en[p])==w_en[p];
    end
  end
  always_ff @(posedge clk) begin
    we<=rst?'0:chosen;wa<=w_addr;wd<=w_data;
    if(rst) begin priority_port<=0;written<=0;end
    else begin
      priority_port<=priority_port+1'b1;
      for(int p=0;p<NWP;p++)
        if(w_take[p]) written[p]<=0;
        else written[p]<=written[p]|chosen[p];
    end
  end
  always_comb begin
    int bank;
    readbank='0;readrow='0;selected='0;r_ready='1;
    for(int p=0;p<NRP;p++) begin
      for(int l=0;l<64;l++) if(r_req[p][l] && !collected[p][l]) begin
        bank=int'(r_addr[p][l][5:0])+64*int'(r_addr[p][l][PS]);
        if(!readbank[p][bank] || readrow[p][bank]==r_addr[p][l][6+:AW]) begin
          readbank[p][bank]=1;
          readrow[p][bank]=r_addr[p][l][6+:AW];selected[p][l]=1;
        end
      end
      r_ready[p]=((collected[p]|selected[p])&r_req[p])==r_req[p];
    end
  end
  always_ff @(posedge clk)
    for(int p=0;p<NRP;p++)
      if(rst || r_take[p]) collected[p]<='0;
      else collected[p]<=collected[p]|selected[p];
  // Decode each bank's write once, then broadcast to coherent read copies.
  // Keeping this outside g_copy avoids eight copies of the wide input mux.
  wire [127:0] bank_wen;
  wire [127:0][AW-1:0] bank_wrow;
  wire [127:0][31:0] bank_wval;
  for(genvar b=0;b<128;b++) begin:g_write_decode
    logic wen;
    logic [AW-1:0] wrow;
    logic [31:0] wval;
    always_comb begin
      wen=0;wrow=0;wval=0;
      for(int q=0;q<NWP;q++) for(int l=0;l<64;l++)
        if(we[q][l] && {wa[q][l][PS],wa[q][l][5:0]}==7'(b)) begin
          wen=1;wrow=wa[q][l][6+:AW];wval=wd[q][l];
        end
    end
    assign bank_wen[b]=wen,bank_wrow[b]=wrow,bank_wval[b]=wval;
  end
  for(genvar p=0;p<NRP;p++) begin:g_copy
    for(genvar b=0;b<128;b++) begin:g_bank
      (* ram_style="block" *) logic [31:0] mem[ROWS];
      logic [31:0] readval;
      always_ff @(posedge clk) begin
        if(bank_wen[b]) mem[bank_wrow[b]]<=bank_wval[b];
        if(readbank[p][b]) readval<=(bank_wen[b] && bank_wrow[b]==readrow[p][b])?
          bank_wval[b]:mem[readrow[p][b]];
      end
`ifndef SYNTHESIS
      initial for(int r=0;r<ROWS;r++) mem[r]=0;
      always @(posedge clk) if((p==0 && dump) || (p!=0 && dump_q)) begin
        for(int r=0;r<ROWS;r++) begin
          if(p==0) img[(b/64)*POOL+r*64+(b%64)]=mem[r];
          else if(mem[r]!==img[(b/64)*POOL+r*64+(b%64)])
            $fatal(1,"wide TMEM incoherent copy %0d bank %0d row %0d",p,b,r);
        end
      end
`endif
    end
    for(genvar l=0;l<64;l++) begin:g_return
      logic [6:0] bank;
      logic fresh;
      logic [31:0] held, early, response;
      logic [6:0] response_bank;
      logic accepted, final_read;
      wire [31:0] values[128];
      for(genvar b=0;b<128;b++) assign values[b]=g_bank[b].readval;
      always_ff @(posedge clk) begin
        fresh<=!rst && selected[p][l];
        if(selected[p][l]) bank<={r_addr[p][l][PS],r_addr[p][l][5:0]};
        if(fresh) held<=values[bank];
        // Gather future requests without changing the previous synchronous
        // response. A stalled execution group still needs that older response.
        accepted<=!rst && r_take[p];
        if(r_take[p]) begin
          final_read<=selected[p][l];
          response_bank<={r_addr[p][l][PS],r_addr[p][l][5:0]};
          early<=fresh?values[bank]:held;
        end
        if(accepted) response<=final_read?values[response_bank]:early;
      end
      assign r_data[p][l]=accepted?(final_read?values[response_bank]:early):response;
    end
  end
`ifndef SYNTHESIS
  always @(posedge clk) if(dump_q) begin
    string dir;
    if($value$plusargs("dir=%s",dir)) begin
      int fd;
      fd=$fopen($sformatf("%s/tmem_%0d.hex",dir,SID),"w");
      for(int i=0;i<WORDS;i++) $fwrite(fd,"%08x\n",img[i]);
      $fclose(fd);
    end
  end
  always @(posedge clk) if(!rst) begin
    for(int p=0;p<NWP;p++) for(int l=0;l<64;l++) if(chosen[p][l]) begin
      if(w_addr[p][l]>=WORDS) $fatal(1,"wide TMEM write address");
      for(int q=p;q<NWP;q++) for(int k=0;k<64;k++)
        if((q>p || k>l) && chosen[q][k] &&
           {w_addr[p][l][PS],w_addr[p][l][5:0]}=={w_addr[q][k][PS],w_addr[q][k][5:0]})
          $fatal(1,"wide TMEM ungranted write bank collision");
    end
  end
`endif
endmodule
