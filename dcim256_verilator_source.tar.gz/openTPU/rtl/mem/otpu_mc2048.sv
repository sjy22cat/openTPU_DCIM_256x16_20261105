// Linear 256-byte native controller adapter. Independent asynchronous request
// queues and response exits for weights, DMA and scales; QST has byte masks.
// Native reads return in command order, one response per native clock.
// Native write completion is reported by n_wr_idle after accepting a write.
module otpu_mc2048 #(parameter int DEPTH=64)(
  input logic clk,rst,mem_clk,mem_rst,
  input logic wx_req,wx_low,
  output logic wx_ready,
  input logic [31:0] wx_addr,
  output logic wx_rvalid,
  output logic [2047:0] wx_rdata,
  input logic b_req,b_we,
  output logic b_ready,
  input logic [31:0] b_addr,
  input logic [2047:0] b_wdata,
  input logic [63:0] b_wmask,
  output logic b_rvalid,b_rtag,
  output logic [2047:0] b_rdata,
  input logic a_req,
  output logic a_ready,
  input logic [31:0] a_addr,
  output logic a_rvalid,
  output logic [255:0] a_rdata,
  input logic qw_req,
  output logic qw_ready,
  input logic [31:0] qw_addr,
  input logic [2047:0] qw_data,
  input logic [255:0] qw_be,
  output logic wr_idle,rd_idle,
  output logic n_valid,n_write,
  input logic n_ready,
  output logic [23:0] n_line,
  output logic [2047:0] n_wdata,
  output logic [255:0] n_byte_en,
  input logic n_rvalid,
  input logic [2047:0] n_rdata,
  input logic n_wr_idle
);
  localparam int QW=32+1+2048+256, PW=$clog2(DEPTH);
  logic [3:0] iv,ir,ov,ot;
  logic [QW-1:0] id[4],od[4];
  logic [PW:0] qused[4];
  assign iv={qw_req,a_req,b_req,wx_req};
  assign {qw_ready,a_ready,b_ready,wx_ready}=ir;
  always_comb begin
    id[0]={wx_addr,1'b0,2048'd0,256'd0};
    id[1]={b_addr,b_we,b_wdata,256'd0};
    for(int i=0;i<256;i++) id[1][i]=b_wmask[i/4];
    id[2]={a_addr,1'b0,2048'd0,256'd0};
    id[3]={qw_addr,1'b1,qw_data,qw_be};
  end
  for(genvar p=0;p<4;p++) begin:g_request
    otpu_afifo #(.W(QW),.DEPTH(DEPTH)) u_fifo(
      .wclk(clk),.wrst(rst),.wvalid(iv[p]),.wready(ir[p]),.wdata(id[p]),
      .wslot('0),.wcommit(),.wused(qused[p]),.rclk(mem_clk),.rrst(mem_rst),
      .rvalid(ov[p]),.rready(ot[p]),.rdata(od[p]),.rused());
  end
  logic [2:0] rv,rr,sv;
  logic [2047:0] sd[3],rd[3];
  logic [PW:0] response_used[3],inflight[3];
  for(genvar p=0;p<3;p++) begin:g_response
    otpu_afifo #(.W(2048),.DEPTH(DEPTH)) u_fifo(
      .wclk(mem_clk),.wrst(mem_rst),.wvalid(sv[p]),.wready(rr[p]),.wdata(sd[p]),
      .wslot('0),.wcommit(),.wused(response_used[p]),.rclk(clk),.rrst(rst),
      .rvalid(rv[p]),.rready(1'b1),.rdata(rd[p]),.rused());
  end
  assign wx_rvalid=rv[0],wx_rdata=rd[0],b_rvalid=rv[1],b_rdata=rd[1],b_rtag=1;
  assign a_rvalid=rv[2],a_rdata=rd[2][255:0];
  logic [1:0] priority_source,chosen;
  logic found;
  logic [3:0] eligible;
  (* ASYNC_REG="TRUE" *) logic low_m1,low_m2;
  logic [1:0] weight_burst;
  always_ff @(posedge mem_clk)
    if(mem_rst) begin low_m1<=1;low_m2<=1;end
    else begin low_m1<=wx_low;low_m2<=low_m1;end
  logic [1:0] tags[DEPTH];
  logic [2:0] scaleoffset[DEPTH];
  logic [PW-1:0] th,tt;
  logic [PW:0] tn;
  wire take=n_valid && n_ready;
  wire readtake=take && !n_write;
  always_comb begin
    int p;
    found=0;chosen=0;eligible=0;
    for(int k=0;k<4;k++) begin
      p=(int'(priority_source)+k)%4;
      if(ov[p]) begin
        if(p==3 || od[p][2304]) eligible[p]=1;
        else if(tn<DEPTH && int'(inflight[p])+int'(response_used[p])<DEPTH) begin
          eligible[p]=1;
        end
      end
    end
    // At low water: at most three weight reads before one fair competing
    // service. At high water: plain round-robin. Activation producers cannot
    // starve behind an MM that is waiting for their results.
    if(low_m2 && eligible[0] && weight_burst<3) begin found=1;chosen=0;end
    for(int k=0;k<4;k++) begin
      p=(int'(priority_source)+k)%4;
      if(!found && eligible[p] &&
         (p!=0 || !low_m2 || !(|eligible[3:1]))) begin found=1;chosen=2'(p);end
    end
    // Freeze the selected command under native backpressure using the lock below.
  end
  logic locked;
  logic [1:0] lock_source;
  wire [1:0] service=locked?lock_source:chosen;
  wire [QW-1:0] packet=od[service];
  assign n_valid=!mem_rst && (locked || found);
  assign n_write=packet[2304];
  assign n_line=packet[QW-1:2305]>>6;
  assign n_wdata=packet[2303:256],n_byte_en=packet[255:0];
  always_comb begin
    ot=0;if(take) ot[service]=1;
    sv=0;for(int p=0;p<3;p++) sd[p]=n_rdata;
    if(n_rvalid) begin
      sv[tags[th]]=1;
      if(tags[th]==2) sd[2]=n_rdata>>(256*scaleoffset[th]);
    end
  end
  // Write acknowledgements cross back only after native completion, not acceptance.
  logic [31:0] writes_waiting;
  logic ack_valid,ack_ready,ack_core;
  assign ack_valid=writes_waiting!=0 && n_wr_idle && !(take && n_write);
  otpu_afifo #(.W(1),.DEPTH(DEPTH)) u_ack(
    .wclk(mem_clk),.wrst(mem_rst),.wvalid(ack_valid),.wready(ack_ready),.wdata(1'b1),
    .wslot('0),.wcommit(),.wused(),.rclk(clk),.rrst(rst),.rvalid(ack_core),
    .rready(1'b1),.rdata(),.rused());
  logic [31:0] pending_reads,pending_writes;
  always_ff @(posedge clk) begin
    if(rst) begin pending_reads<=0;pending_writes<=0;end
    else begin
      pending_reads<=pending_reads+32'(wx_req&&wx_ready)+32'(b_req&&b_ready&&!b_we)+
        32'(a_req&&a_ready)-32'(rv[0])-32'(rv[1])-32'(rv[2]);
      pending_writes<=pending_writes+32'(b_req&&b_ready&&b_we)+32'(qw_req&&qw_ready)-32'(ack_core);
    end
  end
  assign rd_idle=pending_reads==0,wr_idle=pending_writes==0;
  always_ff @(posedge mem_clk) begin
    if(mem_rst) begin
      priority_source<=0;locked<=0;th<=0;tt<=0;tn<=0;writes_waiting<=0;weight_burst<=0;
      for(int p=0;p<3;p++) inflight[p]<=0;
    end else begin
      if(n_valid && !n_ready) begin locked<=1;lock_source<=service;end
      if(take) begin
        locked<=0;
        // Forced weight service must not restart the competing-source cursor.
        if(service!=0 || !low_m2) priority_source<=service+1'b1;
        if(service!=0) weight_burst<=0;
        else if(weight_burst<3) weight_burst<=weight_burst+1'b1;
      end
      tn<=tn+(PW+1)'(readtake)-(PW+1)'(n_rvalid);
      if(readtake) begin
        tags[tt]<=service;scaleoffset[tt]<=packet[2305+3+:3];tt<=tt+1'b1;
      end
      if(n_rvalid) th<=th+1'b1;
      for(int p=0;p<3;p++) inflight[p]<=inflight[p]+(PW+1)'(readtake && service==p)-
        (PW+1)'(n_rvalid && tags[th]==p);
      writes_waiting<=writes_waiting+32'(take&&n_write)-32'(ack_valid&&ack_ready);
    end
  end
`ifndef SYNTHESIS
  always @(posedge mem_clk) if(!mem_rst) begin
    if(n_rvalid && tn==0) $fatal(1,"MC2048 unsolicited read response");
    for(int p=0;p<3;p++) if(sv[p]&&!rr[p]) $fatal(1,"MC2048 response credit overflow");
  end
`endif
endmodule
