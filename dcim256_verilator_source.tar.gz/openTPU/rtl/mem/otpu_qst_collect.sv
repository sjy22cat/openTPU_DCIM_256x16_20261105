// Banked INT8 write combining. Fold the line address in six-bit groups so
// power-of-two KV strides also spread over the 64 data RAMs. Each RAM accepts
// one byte/cycle; a full line drains through all RAMs with four bytes per RAM.
// Other strides/collisions replay from an accepted vector, never drop a byte.
module otpu_qst_collect #(parameter int LINES=256)(
  input logic clk,rst,
  input logic valid,commit,
  output logic ready,
  input logic [63:0] mask,
  input logic [63:0][7:0] bytes_in,
  input logic [31:0] base,stride,
  input logic flush,
  output logic idle,
  output logic req,
  input logic grant,
  output logic [31:0] addr,
  output logic [2047:0] data,
  output logic [255:0] byte_en
);
  localparam int IW=$clog2(LINES);
  initial if(LINES<64 || LINES>256 || (LINES & (LINES-1))!=0)
    $fatal(1,"QST LINES must be a power of two between 64 and 256");
  logic [LINES-1:0] used,touched,pressure;
  logic [LINES-1:0][23:0] tags;
  logic [LINES-1:0][255:0] enables;
  logic [63:0] pending,remaining;
  logic [63:0][31:0] address;
  logic [63:0][7:0] value;
  wire [63:0][IW-1:0] slot;
  logic [63:0] wen;
  logic [63:0][IW-1:0] wslot;
  logic [63:0][1:0] wbyte;
  logic [63:0][7:0] wvalue;
  logic [IW-1:0] head,victim,drain_slot;
  logic held,drain;
  logic [63:0][31:0] readval;
  function automatic logic [IW-1:0] slot_of(input logic [31:0] a);
    return IW'((a>>8)^(a>>14)^(a>>20)^(a>>26));
  endfunction
  for(genvar l=0;l<64;l++) assign slot[l]=slot_of(address[l]);
  always_comb begin
    int s,bank;
    logic blocked;
    touched=0;pressure=0;remaining=pending;
    wen=0;wslot=0;wbyte=0;wvalue=0;
    for(int l=0;l<64;l++) if(pending[l]) begin
      s=int'(slot[l]);bank=(s%64)^int'(address[l][5:0]);blocked=0;
      // Resolve new allocations with lane comparisons, not 64 successive
      // updates to a full LINES x 24-bit associative tag array.
      for(int k=0;k<l;k++) if(pending[k] && !remaining[k] && slot[k]==slot[l] &&
        address[k][31:8]!=address[l][31:8]) blocked=1;
      if(held && s==int'(head)) begin end
      else if(used[s] && tags[s]!=address[l][31:8]) pressure[s]=1;
      else if(!blocked && !wen[bank]) begin
        touched[s]=1;remaining[l]=0;
        wen[bank]=1;wslot[bank]=IW'(s);wbyte[bank]=address[l][7:6];wvalue[bank]=value[l];
      end
    end
    ready=!rst && remaining==0;
    // A draining line is protected until its entire native request is accepted.
    // Avoid selecting a line updated on this edge (RAM read-during-write).
    drain=0;drain_slot=0;
    if(!held || grant) for(int k=0;k<LINES;k++) begin
      s=(int'(victim)+k)%LINES;
      if(!drain && used[s] && !touched[s] && !(held && s==int'(head)) &&
         (flush || pressure[s] || (&enables[s]))) begin
        drain=1;drain_slot=IW'(s);
      end
    end
    req=held;addr={tags[head],8'd0}>>2;byte_en=enables[head];
    for(int i=0;i<256;i++) data[8*i+:8]=readval[head[5:0]^6'(i)][8*(i/64)+:8];
    idle=used==0 && pending==0 && !held;
  end
  always_ff @(posedge clk) begin
    if(rst) begin used<=0;pending<=0;held<=0;head<=0;victim<=0;end
    else begin
      if(held && grant) held<=0;
      used<=(used & ~(LINES'(held && grant)<<head))|touched;
      pending<=remaining;
      if(valid && ready && commit) begin
        pending<=mask;
        for(int l=0;l<64;l++) begin address[l]<=base+32'(l)*stride;value[l]<=bytes_in[l];end
      end
      if(drain) begin held<=1;head<=drain_slot;victim<=drain_slot+1'b1;end
    end
  end
  // Each bank contains four byte positions per line, with native byte enables.
  // Explicit byte slices infer a single-write, synchronous-read block RAM.
  for(genvar b=0;b<64;b++) begin:g_bank
    (* ram_style="block" *) logic [31:0] payload[LINES];
    always_ff @(posedge clk) begin
      if(!rst && wen[b]) payload[wslot[b]][8*wbyte[b]+:8]<=wvalue[b];
      if(!rst && drain) readval[b]<=payload[drain_slot];
    end
  end
  // Valid bits need a per-line clear on allocation. Decode writes per bank,
  // rather than building 64 dynamic 256-byte update muxes for every cache line.
  for(genvar s=0;s<LINES;s++) begin:g_enable
    wire [255:0] additions;
    logic [23:0] new_tag;
    always_comb begin
      new_tag=0;
      for(int l=0;l<64;l++) if(pending[l] && !remaining[l] && slot[l]==IW'(s))
        new_tag=new_tag|address[l][31:8];
    end
    for(genvar b=0;b<64;b++) begin:g_bank
      wire hit=wen[b] && wslot[b]==IW'(s);
      for(genvar k=0;k<4;k++)
        assign additions[64*k+((s%64)^b)]=hit && wbyte[b]==2'(k);
    end
    always_ff @(posedge clk) if(!rst) begin
      if(touched[s] && !used[s]) begin tags[s]<=new_tag;enables[s]<=additions;end
      else enables[s]<=enables[s]|additions;
    end
  end
endmodule
