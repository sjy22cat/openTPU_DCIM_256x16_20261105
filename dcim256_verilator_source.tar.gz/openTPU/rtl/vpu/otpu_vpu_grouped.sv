// One VOP dispatch/completion, four independent complete 16-lane row engines.
// All cores advance together. General TMEM routing keeps each segment's address.
module otpu_vpu_grouped
  import otpu_pkg::*;
#(parameter int SID=0)(
  input logic clk, rst, start,
  input cmd_t cmd,
  output logic rdy, done,
  input logic gnt,
  output logic ren,
  output logic [63:0] ta_en, tb_en, tw_en,
  output logic [63:0][31:0] ta_addr, tb_addr, tw_addr, tw_data,
  input logic [63:0][31:0] ta_data, tb_data,
  output logic pf_u,
  output logic [31:0] pf_frz
);
  cmd_t subcmd[4];
  localparam int DEPTH=32, PW=$clog2(DEPTH);
  logic [3:0] crdy, cdone, cren, cstart;
  logic [31:0] submitted[4], completed[4], goal[DEPTH][4];
  logic [PW-1:0] head,tail;
  logic [PW:0] count;
  logic retire;
  logic [31:0] frozen;
  assign rdy=(count<DEPTH-1) && (&crdy);
  always_comb begin
    retire=count!=0;
    for(int g=0;g<4;g++)
      if($signed(completed[g]-goal[head][g])<0) retire=0;
  end
  assign ren=gnt;
  always_comb begin
    int pergroup, first, nr;
    pergroup=(int'(cmd.w4[15:0])+3)/4;
    for (int g=0;g<4;g++) begin
      first=g*pergroup;
      nr=(first>=int'(cmd.w4[15:0])) ? 0 :
         ((int'(cmd.w4[15:0])-first<pergroup) ? int'(cmd.w4[15:0])-first : pergroup);
      subcmd[g]=cmd;
      subcmd[g].w4[15:0]=16'(nr);
      subcmd[g].w1=cmd.w1+32'(first)*32'(cmd.w5[15:0]);
      // OUTER's w2 is a shared column vector, not the row operand A.
      if (cmd.w6[23:16]!=V_OUTER)
        subcmd[g].w2=cmd.w2+32'(first)*32'(cmd.w5[31:16]);
      if (cmd.w6[25:24]==B_FULL || cmd.w6[25:24]==B_ROW)
        subcmd[g].w3=cmd.w3+32'(first)*32'(cmd.w6[15:0]);
      cstart[g]=start && nr!=0;
    end
  end
  // Each core preserves VOP completion order. Per-command cumulative goals
  // join unequal row groups without serializing independent instructions.
  always_ff @(posedge clk) begin
    done<=0; pf_u<=0;
    if (rst) begin
      head<=0;tail<=0;count<=0;frozen<=0;pf_frz<=0;
      for(int g=0;g<4;g++) begin submitted[g]<=0;completed[g]<=0;end
    end else begin
      count<=count+(PW+1)'(start)-(PW+1)'(retire);
      if(count!=0 && !gnt) frozen<=frozen+1;
      for(int g=0;g<4;g++) begin
        if(cdone[g]) completed[g]<=completed[g]+1;
        if(start) begin
          goal[tail][g]<=submitted[g]+32'(cstart[g]);
          submitted[g]<=submitted[g]+32'(cstart[g]);
        end
      end
      if(start) tail<=tail+1'b1;
      if(retire) begin
        head<=head+1'b1;done<=1;pf_u<=1;pf_frz<=frozen;frozen<=0;
      end
    end
  end
`ifndef SYNTHESIS
  always @(posedge clk) if(!rst && start && !rdy)
    $fatal(1,"grouped VPU command queue overflow");
`endif
  for (genvar g=0;g<4;g++) begin : g_core
    wire [31:0] unused_y[16];
    wire [31:0] zero_data[16];
    for (genvar l=0;l<16;l++) assign zero_data[l]='0;
    otpu_vpu #(.LANES(16),.CL(16),.SID(SID),.WBUF(0),.HAS_SE(0)) u_core (
      .clk,.rst,.start(cstart[g]),.cmd(subcmd[g]),.rdy(crdy[g]),.done(cdone[g]),
      .gnt,.ren(cren[g]),.rhold(1'b0),
      .ta_en(ta_en[g*16+:16]),.ta_addr(ta_addr[g*16+:16]),.ta_data(ta_data[g*16+:16]),
      .tb_en(tb_en[g*16+:16]),.tb_addr(tb_addr[g*16+:16]),.tb_data(tb_data[g*16+:16]),
      .ta_ben(),.ta_bad(),.tb_ben(),.tb_bad(),
      .tw_en(tw_en[g*16+:16]),.tw_addr(tw_addr[g*16+:16]),.tw_data(tw_data[g*16+:16]),
      .pf_u(),.pf_frz(),.ss_req(1'b0),.ss_gnt(),.ss_cfg('0),.ss_pe(1'b0),
      .ss_in_v(1'b0),.ss_in_d(zero_data),.ss_fk('0),.ss_fi('0),.ss_fd(zero_data),
      .ss_y_v(),.ss_y_d(unused_y),.ss_o_v(),.ss_o_d());
  end
endmodule
