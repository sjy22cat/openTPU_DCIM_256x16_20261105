// D256/SPC1 DMA. Read returns never depend on TMEM/output backpressure.
// One command, 128 reserved chunk slots; TMEM requests hold until accepted.
module otpu_dma_wide
  import otpu_pkg::*;
#(parameter int DEPTH=128)(
  input logic clk,rst,start,
  input cmd_t cmd,
  output logic rdy,done,err,ww_held,
  output logic b_req,b_we,
  input logic b_gnt,b_rvalid,wr_idle,
  output logic [63:0] b_wmask,
  output logic [2047:0] b_wdata,
  output logic [31:0] b_addr,
  input logic [2047:0] b_rdata,
  output logic [63:0] t_ren,t_wen,
  output logic [63:0][31:0] t_raddr,t_waddr,t_wdata,
  input logic [63:0][31:0] t_rdata,
  input logic t_gnt
);
  localparam int PW=$clog2(DEPTH);
  logic busy,store,waitword,fence;
  logic [31:0] first,last,issue,deliver,tbase,source;
  logic [31:0] waitref,waitmask,interval,timeout,ticks,delaycount;
  logic [1:0] compare;
  // LD and ST are mutually exclusive commands. Multiplex their returned data
  // into one physical write port so this asynchronous-read FIFO infers RAM.
  (* ram_style="distributed" *) logic [2047:0] data[DEPTH];
  logic [63:0] mask[DEPTH];
  logic [PW-1:0] wr,rd,ret;
  logic [PW:0] reserved,available;
  logic returning;
  logic [PW-1:0] returnslot;
  logic [63:0] returnmask;
  wire request=busy && !fence && issue<last && reserved<DEPTH && delaycount==0 && !err &&
    (!waitword || timeout==0 || ticks<timeout);
  wire ldissue=b_req && !b_we && b_gnt;
  wire outputtake=(|t_wen) && t_gnt;
  wire stissue=(|t_ren) && t_gnt;
  wire writeout=b_req && b_we && b_gnt;
  wire matchword=(compare==0) ? ((data[rd][32*(first%64)+:32]&waitmask)==waitref) :
    (compare==1) ? ((data[rd][32*(first%64)+:32]&waitmask)!=waitref) :
    ($signed((data[rd][32*(first%64)+:32]&waitmask)-waitref)>=0);
  always_ff @(posedge clk) if(!rst && (b_rvalid || returning))
    data[returning?returnslot:ret]<=returning?t_rdata:b_rdata;
  assign rdy=!busy;
  always_comb begin
    b_req=0; b_we=store; b_addr=issue; b_wdata=data[rd]; b_wmask=mask[rd];
    t_ren=0;t_wen=0;t_raddr=0;t_waddr=0;t_wdata=0;
    if (!store) begin
      b_req=request;
      if (busy && available!=0 && (!waitword || matchword))
        for(int l=0;l<64;l++) begin
          t_wen[l]=(deliver+l>=first && deliver+l<last);
          t_waddr[l]=tbase+deliver+l-first;
          t_wdata[l]=data[rd][32*l+:32];
        end
    end else begin
      b_req=busy && available!=0;
      b_addr=deliver;
      if(request) for(int l=0;l<64;l++) begin
        t_ren[l]=(issue+l>=first && issue+l<last);
        t_raddr[l]=tbase+issue+l-first;
      end
    end
  end
  always_ff @(posedge clk) begin
    done<=0;ww_held<=0;
    if(rst) begin busy<=0;err<=0;returning<=0;reserved<=0;available<=0;fence<=0;end
    else begin
      returning<=stissue;
      // Always receive an accepted read, even when this cycle's output is blocked.
      if(b_rvalid) ret<=ret+1'b1;
      if(returning) mask[returnslot]<=returnmask;
      if(start) begin
        busy<=cmd.w3!=0 || cmd.op==OP_WAITW;
        done<=cmd.w3==0 && cmd.op!=OP_WAITW;
        store<=cmd.op==OP_ST;waitword<=cmd.op==OP_WAITW;fence<=0;
        first<=cmd.w1>>2;last<=(cmd.w1>>2)+((cmd.op==OP_WAITW)?1:cmd.w3);
        issue<=(cmd.w1>>2)&32'hffffffc0;deliver<=(cmd.w1>>2)&32'hffffffc0;
        tbase<=cmd.w2;source<=cmd.w1>>2;
        wr<=0;rd<=0;ret<=0;reserved<=0;available<=0;
        waitref<=cmd.w3;waitmask<=cmd.w4;interval<=cmd.w5;timeout<=cmd.w6;
        compare<=cmd.flags[1:0];ticks<=0;delaycount<=0;
      end else if(busy) begin
        reserved<=reserved+(PW+1)'(ldissue||stissue)-(PW+1)'(outputtake||writeout);
        available<=available+(PW+1)'(b_rvalid||returning)-(PW+1)'(outputtake||writeout);
        if(ldissue||stissue) issue<=issue+64;
        if(stissue) begin returnslot<=wr;returnmask<=t_ren;wr<=wr+1'b1;end
        if(outputtake||writeout) begin
          rd<=rd+1'b1;deliver<=deliver+64;
          if(deliver+64>=last) fence<=1;
          if(waitword) ww_held<=1;
        end
        if(delaycount!=0) delaycount<=delaycount-1;
        if(waitword) begin
          if(ticks!=32'hffffffff) ticks<=ticks+1;
          // Stop between polls at the deadline. An already accepted read is
          // still allowed to return and satisfy the condition.
          if(timeout!=0 && ticks>=timeout && reserved==0) err<=1;
          if(available!=0 && !matchword) begin
            available<=0;reserved<=0;rd<=rd+1'b1;
            issue<=first&32'hffffffc0;delaycount<=interval;
            if(timeout!=0 && ticks>=timeout) err<=1;
          end
        end
        // Extra cycle lets the final TMEM write enter its visibility stage.
        if(fence && (!store || wr_idle)) begin busy<=0;fence<=0;done<=1;end
      end
    end
  end
endmodule
