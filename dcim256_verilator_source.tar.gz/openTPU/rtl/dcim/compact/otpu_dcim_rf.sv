// FPGA substitute for the original R2SO01GA_W64B128M1B1_L RF technology cell.
// Synchronous single-read/single-write, one clock, no hardware initialization.
module otpu_dcim_compact_rf #(parameter int W = 256)(
  input logic clk,
  input logic write_en, read_en,
  input logic [2:0] write_addr, read_addr,
  input logic [W-1:0] write_data,
  output logic [W-1:0] read_data
);
  (* ram_style = "distributed" *) logic [W-1:0] mem [8];
  always_ff @(posedge clk) begin
    if (write_en) mem[write_addr] <= write_data;
    if (read_en) read_data <= mem[read_addr];
  end
`ifndef SYNTHESIS
  initial if ($test$plusargs("dcim_rf_randomize"))
    for (int a = 0; a < 8; a++)
      for (int b = 0; b < W; b++) mem[a][b] = 1'($urandom);
`endif
endmodule
