// Compact adaptation of native PEX2: two complete nibble/vector16 PE datapaths,
// five synchronous RF banks, independent PE activations, four dot16s per PE.
// Core exec accepted at e -> result visible after e+5 (six inclusive edges).
// load and exec are independent; an address can be reused by any number of execs.
module otpu_dcim_compact_pex2 #(
  parameter logic [127:0] ELEM_MASK = {128{1'b1}}
)(
  input logic clk, rst,
  input logic load_valid,
  input logic [2:0] load_addr,
  input logic [1:0][63:0][7:0] weight,
  input logic exec_valid,
  input logic [2:0] exec_addr,
  input logic [1:0][63:0][7:0] activation,
  output wire result_valid,
  output wire [1:0][3:0][23:0] partial_sum
);
  wire [1:0][63:0][7:0] magnitude_in;
  wire [1:0][63:0] sign_in;
  wire [3:0][255:0] magnitude_read;
  wire [127:0] sign_read;
  logic [1:0][63:0][7:0] activation_read;
  logic [1:0][63:0][8:0] activation_corrected;
  logic [1:0][63:0][7:0] magnitude_active;
  logic [5:0] valid_pipe;

  for (genvar p = 0; p < 2; p++) begin : g_encode_pe
    for (genvar i = 0; i < 64; i++) begin : g_encode_element
      if (ELEM_MASK[p*64+i]) begin : g_active
        otpu_dcim_int8_encode u_encode (.weight(weight[p][i]),
          .magnitude(magnitude_in[p][i]), .sign(sign_in[p][i]));
      end else begin : g_unused
        assign magnitude_in[p][i] = '0;
        assign sign_in[p][i] = 1'b0;
      end
    end
  end
  for (genvar b = 0; b < 4; b++) begin : g_magnitude_bank
    wire [255:0] write_data = {magnitude_in[1][16*b +: 16],
                              magnitude_in[0][16*b +: 16]};
    otpu_dcim_compact_rf #(.W(256)) u_rf (
      .clk, .write_en(load_valid && !rst), .read_en(exec_valid && !rst),
      .write_addr(load_addr), .read_addr(exec_addr), .write_data,
      .read_data(magnitude_read[b]));
  end
  otpu_dcim_compact_rf #(.W(128)) u_sign_rf (
    .clk, .write_en(load_valid && !rst), .read_en(exec_valid && !rst),
    .write_addr(load_addr), .read_addr(exec_addr), .write_data(sign_in),
    .read_data(sign_read));

  always_ff @(posedge clk) begin
    if (rst) valid_pipe <= '0;
    else valid_pipe <= {valid_pipe[4:0], exec_valid};
    if (!rst && exec_valid) activation_read <= activation;
  end
  assign result_valid = valid_pipe[5];

  for (genvar p = 0; p < 2; p++) begin : g_pe
    for (genvar i = 0; i < 64; i++) begin : g_sign
      if (ELEM_MASK[p*64+i]) begin : g_active
        wire signed [8:0] corrected;
        otpu_dcim_int8_sign u_sign (.activation(activation_read[p][i]),
          .weight_sign(sign_read[p*64+i]), .corrected);
        always_ff @(posedge clk) begin
          activation_corrected[p][i] <= corrected;
          magnitude_active[p][i] <= magnitude_read[i/16][p*128+(i%16)*8 +: 8];
        end
      end else begin : g_unused
        assign activation_corrected[p][i] = '0;
        assign magnitude_active[p][i] = '0;
      end
    end
    otpu_dcim_compact_single_pe #(.ELEM_MASK(ELEM_MASK[p*64 +: 64])) u_single_pe (
      .clk, .activation(activation_corrected[p]), .magnitude(magnitude_active[p]),
      .partial_sum(partial_sum[p]));
`ifndef SYNTHESIS
    // At e+5, vector sums from e+4 are consumed by the INT8 reconstruction.
    // Gate by the transaction's valid, not arbitrary resetless datapath values.
    for (genvar b = 0; b < 4; b++) begin : g_range
      always @(posedge clk) if (!rst && valid_pipe[4]) begin
        if ($signed(u_single_pe.g_block[b].low_sum) < -16'sd30720 ||
            $signed(u_single_pe.g_block[b].low_sum) > 16'sd30720 ||
            $signed(u_single_pe.g_block[b].high_sum) < -16'sd30720 ||
            $signed(u_single_pe.g_block[b].high_sum) > 16'sd30720)
          $fatal(1, "DCIM nibble vector sum outside proven range: PE %0d block %0d", p, b);
      end
    end
`endif
  end

`ifndef SYNTHESIS
  // RAM contents are intentionally not reset. Valid reads must refer to a load
  // after reset; no assumption about the FPGA's initial RF bits is needed.
  bit [7:0] initialized;
  always @(posedge clk) begin
    if (rst) initialized <= '0;
    else begin
      if (load_valid) initialized[load_addr] <= 1'b1;
      if (exec_valid && !initialized[exec_addr])
        $fatal(1, "DCIM compact RF read before load: address %0d", exec_addr);
      if (load_valid && exec_valid && load_addr == exec_addr)
        $fatal(1, "DCIM compact RF simultaneous same-address read/write: %0d", exec_addr);
      if (load_valid)
        for (int p = 0; p < 2; p++)
          for (int i = 0; i < 64; i++)
            if (!ELEM_MASK[p*64+i] && weight[p][i] !== 8'd0)
              $fatal(1, "DCIM compact nonzero masked weight: PE %0d element %0d", p, i);
      // At e+2 the nibble multipliers consume the values registered at e+1.
      // The signed9 encoding carries +128; it never represents +/-256 here.
      if (valid_pipe[1])
        for (int p = 0; p < 2; p++)
          for (int i = 0; i < 64; i++) begin
            if ($signed(activation_corrected[p][i]) < -9'sd128 ||
                $signed(activation_corrected[p][i]) > 9'sd128)
              $fatal(1, "DCIM corrected activation outside INT8-derived range: PE %0d element %0d", p, i);
            if (magnitude_active[p][i] > 8'd128)
              $fatal(1, "DCIM weight magnitude outside INT8 range: PE %0d element %0d", p, i);
          end
    end
  end
`endif
endmodule
