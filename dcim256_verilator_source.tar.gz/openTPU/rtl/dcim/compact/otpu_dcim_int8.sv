// Exact signed INT8 front end derived from dcim_core/rtl/array_bak/
// rtl_pass_v1/{int8_dw_proc,neg_unit_saturated}.v. No saturation or FP4 mode.
module otpu_dcim_int8_encode (
  input  logic [7:0] weight,
  output wire [7:0] magnitude,
  output wire sign
);
  assign sign = weight[7];
  // Unsigned magnitude includes 128 for the two's-complement value -128.
  assign magnitude = weight[7] ? (~weight + 8'd1) : weight;
endmodule

module otpu_dcim_int8_sign (
  input  logic [7:0] activation,
  input  logic weight_sign,
  output wire signed [8:0] corrected
);
  wire signed [8:0] extended = $signed({activation[7], activation});
  assign corrected = weight_sign ? -extended : extended;
endmodule
