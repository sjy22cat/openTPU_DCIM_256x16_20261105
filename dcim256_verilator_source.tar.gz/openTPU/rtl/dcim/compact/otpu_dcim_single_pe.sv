// Derived from dcim_core/rtl/dcim_pe_top/rtl/single_pe.v and PEX2.v.
// A complete INT8 PE uses four low/high vector16 pairs = sixty-four products.
// Expose the four exact dot16s before PEX2's original cross-group dot64 reduction.
module otpu_dcim_compact_single_pe #(
  parameter logic [63:0] ELEM_MASK = 64'hffffffffffffffff
)(
  input logic clk,
  input logic [63:0][8:0] activation,
  input logic [63:0][7:0] magnitude,
  output logic [3:0][23:0] partial_sum
);
  for (genvar b = 0; b < 4; b++) begin : g_block
    wire [15:0][3:0] low, high;
    wire signed [15:0] low_sum, high_sum;
    wire signed [23:0] low_extended = {{8{low_sum[15]}}, low_sum};
    wire signed [23:0] high_extended = {{8{high_sum[15]}}, high_sum};
    for (genvar q = 0; q < 16; q++) begin : g_nibble
      assign low[q] = magnitude[16*b+q][3:0];
      assign high[q] = magnitude[16*b+q][7:4];
    end
    otpu_dcim_vector16 #(.ELEM_MASK(ELEM_MASK[16*b +: 16])) u_low (
      .clk, .activation(activation[16*b +: 16]), .nibble(low), .sum(low_sum));
    otpu_dcim_vector16 #(.ELEM_MASK(ELEM_MASK[16*b +: 16])) u_high (
      .clk, .activation(activation[16*b +: 16]), .nibble(high), .sum(high_sum));
    always_ff @(posedge clk)
      partial_sum[b] <= low_extended + (high_extended <<< 4);
  end
endmodule
