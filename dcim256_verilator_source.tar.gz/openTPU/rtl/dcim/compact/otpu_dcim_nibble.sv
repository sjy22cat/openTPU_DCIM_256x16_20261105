// Signed-only width-correct adaptation of dcim_core/rtl/dcim_pe_top/rtl/
// multiplier.v: magnitude multiply by one unsigned nibble, then restore sign.
// The signed9 input is a sign-corrected INT8, restricted to [-128,+128].
// It is not an arbitrary signed9 operand: |product| <= 128*15 = 1920.
module otpu_dcim_nibble (
  input  logic signed [8:0] activation,
  input  logic [3:0] nibble,
  output wire signed [11:0] product
);
  wire [8:0] a_magnitude = activation[8] ? (~activation + 9'd1) : activation;
  wire [11:0] unsigned_product = a_magnitude * nibble;
  assign product = activation[8] ? $signed(~unsigned_product + 12'd1)
                                 : $signed(unsigned_product);
endmodule
