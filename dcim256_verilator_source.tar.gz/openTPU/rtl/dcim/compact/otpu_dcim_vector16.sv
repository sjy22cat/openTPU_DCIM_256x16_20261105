// Derived from dcim_core/rtl/dcim_pe_top/rtl/vector16_mult_vector16.v.
// Keep sixteen nibble multipliers and the binary 16 -> 8 -> 4 -> 2 -> 1 tree.
// Register products, four-product partials and the final sixteen-product sum.
// Valid activations are [-128,+128], hence |sum| <= 16*128*15 = 30720.
module otpu_dcim_vector16 #(
  parameter logic [15:0] ELEM_MASK = 16'hffff
)(
  input logic clk,
  input logic [15:0][8:0] activation,
  input logic [15:0][3:0] nibble,
  output logic signed [15:0] sum
);
  wire signed [11:0] product [16];
  logic signed [15:0] product_q [16];
  wire signed [15:0] pair_sum [8];
  logic signed [15:0] four_q [4];
  wire signed [15:0] eight_sum [2];

  for (genvar i = 0; i < 16; i++) begin : g_product
    if (ELEM_MASK[i]) begin : g_active
      otpu_dcim_nibble u_nibble (.activation($signed(activation[i])),
                                .nibble(nibble[i]), .product(product[i]));
      always_ff @(posedge clk) product_q[i] <= {{4{product[i][11]}}, product[i]};
    end else begin : g_unused
      assign product[i] = '0;
      assign product_q[i] = '0;
    end
  end
  for (genvar i = 0; i < 8; i++) begin : g_pair
    assign pair_sum[i] = product_q[2*i] + product_q[2*i+1];
  end
  for (genvar i = 0; i < 4; i++) begin : g_four
    always_ff @(posedge clk) four_q[i] <= pair_sum[2*i] + pair_sum[2*i+1];
  end
  for (genvar i = 0; i < 2; i++) begin : g_eight
    assign eight_sum[i] = four_q[2*i] + four_q[2*i+1];
  end
  always_ff @(posedge clk) sum <= eight_sum[0] + eight_sum[1];
endmodule
