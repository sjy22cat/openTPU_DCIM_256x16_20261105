// Compact mapping of decoded signed INT8 MXU groups onto native DCIM PE
// nibble/vector16 structures. Each PEX2 has two independently supplied 64-item
// PEs; each PE returns four dot16 partials before any cross-group reduction.
// m4: four PEX2, eight PEs, 512 useful INT8 products.
module otpu_pe_array_bridge #(
  parameter int D=128, COLS=4
)(
  input logic clk, rst, valid,
  input logic [COLS-1:0][D*8-1:0] activation, weight,
  output logic [COLS-1:0][7:0][23:0] group_sum,
  output logic [COLS-1:0] group_valid
);
  localparam int GE=D/8;
  localparam int VPG=(GE+15)/16;
  logic [2:0] slot, exec_slot;
  logic exec_valid;

  // Write now, execute one edge later. The eight-slot ring never collides
  // with the preceding packet's read, including across bubbles and wraparound.
  always_ff @(posedge clk) begin
    if (rst) begin
      slot <= '0;
      exec_slot <= '0;
      exec_valid <= 1'b0;
    end else begin
      exec_valid <= valid;
      exec_slot <= slot;
      if (valid) slot <= slot + 3'd1;
    end
  end

  function automatic logic [127:0] lane_mask(input int p);
    logic [127:0] mask;
    mask='0;
    for (int b=0;b<2;b++)
      for (int v=0;v<4;v++)
        for (int q=0;q<16;q++)
          mask[b*64+v*16+q] = (16*((8*p+4*b+v)%VPG)+q < GE);
    return mask;
  endfunction

  for (genvar c=0;c<COLS;c++) begin : g_column
    wire [VPG-1:0][1:0][3:0][23:0] partial;
    wire [VPG-1:0] result_valid;
    for (genvar p=0;p<VPG;p++) begin : g_pex2
      wire [1:0][63:0][7:0] a_packet, w_packet;
      logic [1:0][63:0][7:0] a_exec;
      for (genvar b=0;b<2;b++) begin : g_pe_input
        for (genvar v=0;v<4;v++) begin : g_vector_input
          localparam int S=8*p+4*b+v;
          localparam int G=S/VPG;
          for (genvar q=0;q<16;q++) begin : g_lane
            localparam int R=16*(S%VPG)+q;
            if (R<GE) begin : g_active
              assign a_packet[b][16*v+q]=activation[c][8*(G*GE+R) +: 8];
              assign w_packet[b][16*v+q]=weight[c][8*(G*GE+R) +: 8];
            end else begin : g_unused
              assign a_packet[b][16*v+q]='0;
              assign w_packet[b][16*v+q]='0;
            end
          end
        end
      end
      always_ff @(posedge clk) if (valid && !rst) a_exec <= a_packet;
      otpu_dcim_compact_pex2 #(.ELEM_MASK(lane_mask(p))) u_pex2 (
        .clk, .rst,
        .load_valid(valid && !rst), .load_addr(slot), .weight(w_packet),
        .exec_valid(exec_valid && !rst), .exec_addr(exec_slot), .activation(a_exec),
        .result_valid(result_valid[p]), .partial_sum(partial[p])
      );
    end
    always_ff @(posedge clk) begin
      if (rst) group_valid[c] <= 1'b0;
      else group_valid[c] <= result_valid[0];
    end
    for (genvar g=0;g<8;g++) begin : g_group
      localparam int S0=g*VPG;
      wire signed [23:0] first=partial[S0/8][(S0%8)/4][S0%4];
      if (VPG==2) begin : g_two_vectors
        localparam int S1=S0+1;
        wire signed [23:0] second=partial[S1/8][(S1%8)/4][S1%4];
        always_ff @(posedge clk) group_sum[c][g] <= first + second;
      end else begin : g_one_vector
        always_ff @(posedge clk) group_sum[c][g] <= first;
      end
    end
`ifndef SYNTHESIS
    always @(negedge clk) if (!rst)
      for (int p=1;p<VPG;p++)
        if (result_valid[p] !== result_valid[0])
          $fatal(1,"DCIM PEX2 valid misalignment column=%0d pex2=%0d",c,p);
`endif
  end
  initial begin
    if (D<16 || D>256 || D%16 || COLS<1)
      $fatal(1,"Unsupported DCIM mapping D=%0d COLS=%0d",D,COLS);
`ifndef SYNTHESIS
    $display("DCIM_COMPACT_ARRAY D=%0d COLS=%0d PEX2=%0d PE=%0d II=1",D,COLS,COLS*VPG,2*COLS*VPG);
`endif
  end
endmodule
