// Shared timing contract, checked by sim/dcim/tb_dcim_bridge.sv.
package otpu_dcim_pkg;
  // Bridge input sampled at n, data/valid visible after NBA at n+7.
  // Core exec at e returns its dot16 partials at e+5.
  localparam int DCIM_PE_STAGES = 3;
  localparam int DCIM_CORE_LATENCY = 6;
  localparam int DCIM_GROUP_LATENCY = 8;
  function automatic int group_latency(input int column);
    return DCIM_GROUP_LATENCY;
  endfunction
endpackage
