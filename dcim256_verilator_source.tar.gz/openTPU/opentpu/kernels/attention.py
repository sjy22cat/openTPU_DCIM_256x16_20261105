"""Decode attention over the int8 KV cache (flash-style online softmax), GQA, head-parallel."""
import math

from .. import language as ol
from ..compiler import Tensor
from .lib import rmsnorm, rope


class Bucket:
    """A sequence length known only at run time (one program for every position of a bucket):
    `blocks` blocks of `block` tokens, the last one partly past the sequence. `z` is the
    address (bytes; run-time: it adds -4 * position) of a float row whose entry for token t0 + c
    of a block at t0 is +inf when the token is in the sequence and -inf past it: that block's
    scores are min(s, row), so the tokens past the sequence score -inf and weigh exactly +0 --
    the softmax, its sums and P.V come out bit for bit as with the partial block. With `add`
    (a prompt run's row: Additive) that block's scores are the mask tile plus q.K^T instead.
    The masked block ends at the cache's end: with a capacity that is not a multiple of the
    block it spans cap - t0 tokens (a multiple of D), so it reads nothing past the cache."""

    def __init__(self, blocks: int, z, add: "Additive | None" = None):
        self.blocks, self.z, self.add = blocks, z, add

    def row(self, t0: int, n: int) -> Tensor:
        return Tensor(self.z + 4 * t0, (n,), (1,))


class Additive:
    """A masked block's mask as a tile the scores are added to (docs/prefill.md 9): at `addr`
    (bytes; run-time: affine in the position) MCOLS rows of the block's `block` entries and
    one pad word (the score buffer's row stride), -0 where the token counts and -inf past it.
    The block's score buffer is loaded with it, then q.K^T is accumulated into it with the row
    maxima (MM ACC + RMAX): two instructions where min(s, row) takes four (MM, LD, VOP MIN,
    VOP RMAX), bit for bit the same (s + -0 = s, s + -inf = -inf = min(s, -inf)). A masked
    block of n < block tokens (Bucket: the cache's end) takes each row's first n entries,
    loaded row by row."""

    def __init__(self, addr, block: int):
        self.addr, self.block = addr, block

    def tile(self, rows: int, n: int) -> Tensor:
        return Tensor(self.addr, (rows, n), (self.block + 1, 1))


class Blocks:
    """Attention over an explicit list of cache blocks, in order: [(t0, n, mask)], tokens [t0,
    t0 + n) of the cache, mask None (all of them count) or a DRAM row of n floats, +inf where
    the token counts and -inf where not (the block's scores are min(s, row), as Bucket's last
    block), or an Additive tile. A sliding window over a KV ring (Gemma 4: the window's first
    block masked at its start, its last at its end)."""

    def __init__(self, items):
        self.items = [(t0, n, m) for t0, n, m in items]


class RowMasks:
    """The masked block of query rows packed from several tokens at compile-time positions
    (a tiled prefill run, opentpu/llm/tiled.py): `keep` [(r0, r1, k)], rows r0 .. r1 - 1 of the
    score buffer count the block's first k tokens. The buffer is filled with -0, then -inf
    past each row group's k, and q.K^T is accumulated into it with the row maxima (MM ACC +
    RMAX), as an Additive tile: s + -0 = s, s + -inf = -inf. A row group with k = 0 sees no
    token of the block: its scores are all -inf, so its online softmax state passes the block
    unchanged (m stays, p and the P.V terms are +0, alpha is exactly 1)."""

    def __init__(self, keep):
        self.keep = [(r0, r1, k) for r0, r1, k in keep]

    def fill(self, out, n: int) -> None:
        out.set(-0.0)
        for r0, r1, k in self.keep:
            if k < n:
                out[r0:r1, k:n].set(float("-inf"))


class RowTiles:
    """RowMasks at run-time positions (a tiled prompt run): `tiles` [(r0, r1, add)], rows r0 ..
    r1 - 1 of the score buffer take the Additive tile `add` (their own position's row of the
    image's mask table, as each row's Bucket of a prompt run takes it). Each row group's rows
    are loaded from its tile, then q.K^T is accumulated into the buffer with the row maxima:
    every row's scores bit for bit those of its own Additive block."""

    def __init__(self, tiles):
        self.tiles = [(r0, r1, a) for r0, r1, a in tiles]

    def fill(self, out, n: int) -> None:
        for r0, r1, a in self.tiles:
            ol.load(a.tile(r1 - r0, n), out=out[r0:r1, :])


class TileSeq:
    """Blocks of a packed query tile (tiled prefill): `full` whole blocks every row sees (the
    hardware loop's, as a length's), then `items` [(t0, n, mask)] as Blocks' (a mask: RowMasks,
    or None where every row sees the block whole)."""

    def __init__(self, full: int, items):
        self.full = full
        self.items = [(t0, n, m) for t0, n, m in items]


def _attend(qh, kv, h, seq_len: int, block: int, scale: float | None = None, raw: bool = False,
            depth: int = 3):
    """Flash attention of the G query rows `qh` [G, d] against KV head h (see _attend_heads);
    returns acc / l, or the unnormalized (acc, l) with `raw`."""
    (acc, l), = _attend_heads([qh], kv, [h], seq_len, block, scale, depth)
    if raw:
        return acc, l
    return acc / l[:, None]


class _Head:
    """Online-softmax state of one KV head's query group."""

    def __init__(self, qh, kv, h, scale, seq_len, block, depth):
        G, d = qh.shape
        if scale is None:
            self.qs = ol.quantize(qh)                # q stays stationary for every K block
        else:
            self.qs = ol.quantize(qh * ol.full([d], scale)[None, :])
        self.G = G
        self.K, self.VT, self.VS = kv.k(h), kv.vt(h), kv.vscale(h)
        self.m = ol.full([G], -1e30)
        self.l = ol.zeros([G])
        self.acc = ol.zeros([G, self.VT.shape[0]])   # V's head_dim (q and K may be padded)
        self.buf = {}                                # block index -> score buffer
        self.S = None                                # the hardware loop's score buffers
        self.rowmax = {}                             # masked block t0 -> its scores' row maxima
        self.masked = None                           # (t0, Bucket) of the masked block
        self.masks = {}                              # Blocks: t0 -> the block's mask row
        if isinstance(seq_len, Bucket):              # full blocks and a masked last one
            nfull = seq_len.blocks - 1
            last = min(block, kv.cap - nfull * block)    # it ends at the cache's end
            if last <= 0:
                raise ol.CompileError(f"bucket {seq_len.blocks} starts past the cache ({kv.cap})")
            self.blocks = [(i * block, block) for i in range(nfull)] + [(nfull * block, last)]
            self.masked = (nfull * block, seq_len)
        elif isinstance(seq_len, Blocks):            # the list, unrolled
            nfull = 0
            self.blocks = [(t0, n) for t0, n, _ in seq_len.items]
            self.masks = {t0: m for t0, _, m in seq_len.items if m is not None}
        elif isinstance(seq_len, TileSeq):           # whole blocks (looped), then the list
            nfull = seq_len.full
            self.blocks = [(i * block, block) for i in range(nfull)] + \
                [(t0, n) for t0, n, _ in seq_len.items]
            self.masks = {t0: m for t0, _, m in seq_len.items if m is not None}
        else:
            nfull, tail = divmod(seq_len, block)
            self.blocks = [(i * block, block) for i in range(nfull)] + \
                ([(nfull * block, tail)] if tail else [])
        self.groups = max(0, (nfull + 1 - depth) // depth)
        if self.VT.tiles is not None:            # V^T in tiles of tb tokens (KVDesc)
            tb = self.VT.tiles[0]
            if tb % block:
                raise ol.CompileError(f"attention block {block} must divide the V^T tile {tb}")
            if (depth * block) % tb:             # a loop step must be whole tiles
                self.groups = 0


def _scores(st, t0, n, out):
    """s = q.K^T for tokens [t0, t0+n) of head state `st` (_Head) into `out`; the MXU epilogue
    also writes the row maxima (a masked block: min with its mask row, then the row maxima of
    that; an Additive mask: the mask tile plus q.K^T, the maxima from the MXU epilogue too)."""
    row = None
    if isinstance(t0, int):
        row = st.masks.get(t0)
        if st.masked is not None and st.masked[0] == t0:
            bk = st.masked[1]
            row = bk.row(t0, n) if bk.add is None else bk.add
    if isinstance(row, Additive):                   # the mask tile, then q.K^T added
        ol.load(row.tile(st.G, n), out=out)
        ol.dot(st.qs, st.K[t0:t0 + n, :], acc=out, rowmax=True)
        return out
    if isinstance(row, (RowMasks, RowTiles)):       # built in place, then q.K^T added
        row.fill(out, n)
        ol.dot(st.qs, st.K[t0:t0 + n, :], acc=out, rowmax=True)
        return out
    if row is not None:
        ol.dot(st.qs, st.K[t0:t0 + n, :], out=out)
        s = ol.minimum(out, ol.load(row)[None, :])
        st.rowmax[t0] = ol.max(s, axis=1)
        return s
    ol.dot(st.qs, st.K[t0:t0 + n, :], out=out, rowmax=True)
    return out


def _finish(st, s, t0, n):
    """Online-softmax update and acc += P.V for the block whose scores are in `s`."""
    D = ol.block_size()
    G = st.G
    vs = ol.load(st.VS[t0:t0 + n])
    rm = st.rowmax.pop(t0) if isinstance(t0, int) and t0 in st.rowmax else s.rowmax
    m_new = ol.maximum(st.m, rm)
    p = ol.exp2(s - m_new[:, None])                           # fused EXP2SUB
    alpha = ol.exp2(st.m - m_new)
    npad = -(-n // D) * D
    if npad == n:
        pq = ol.quantize(p * vs[None, :])                     # V scales folded (QACT CSCALE)
    else:                                                     # tail block: pad P with zeros
        pp = ol.zeros([G, npad])
        pp[:, :n].set(p * vs[None, :])
        pq = ol.quantize(pp)
    vt = st.VT.padded_cols(0, st.VT.shape[0], t0, npad, n)             # zero-padded P
    ol.dot(pq, vt, acc=st.acc, acc_scale=alpha)                         # acc*alpha + P.V
    st.m.set(m_new)                                           # the next block needs m first
    st.l.set(st.l * alpha + ol.sum(p, axis=1))                # off the critical path


def _attend_heads(qhs, kv, hs, seq_len: int, block: int, scale: float | None = None,
                  depth: int = 3, ahead: int = 1, emit=None):
    """Flash attention (online softmax) of several KV heads' query groups, software-pipelined
    FA3-style: while the VPU and quantizer finish block b (softmax, P.V), the MXU is already
    streaming q.K^T of the next depth-1 blocks into other score buffers -- across head
    boundaries too, so the heads' dependency chains overlap. Within a head the hardware loop
    body covers `depth` blocks, so every score buffer has a fixed role.

    qhs: [G, d] query tiles, or functions that emit and return them (they are called
    `ahead` heads early, so the work producing a head's queries -- e.g. its slice of the Q
    projection -- is interleaved with the attention of the heads before it); hs: their KV
    heads. `kv` and `seq_len` (a length, a Bucket or Blocks) are one cache / length for all
    entries, or one per entry (several tokens or sequences chained through the same pipeline:
    batched decode, prefill). The softmax scale log2(e)/sqrt(d) is either already in the
    queries or given as `scale` (applied by the quantizer when q is loaded into ACT RAM, QACT
    CSCALE). Returns [(acc, l)] per head, unnormalized -- or, with `emit`, calls emit(i, acc,
    l) as soon as entry i is complete and releases its state (TMEM then holds only the entries
    in flight).
    """
    P = depth
    kvs = kv if isinstance(kv, (list, tuple)) else [kv] * len(hs)
    lens = seq_len if isinstance(seq_len, (list, tuple)) else [seq_len] * len(hs)
    heads: list = []

    def head(i):
        while len(heads) <= min(i, len(hs) - 1):
            j = len(heads)
            qh = qhs[j]() if callable(qhs[j]) else qhs[j]
            heads.append(_Head(qh, kvs[j], hs[j], scale, lens[j], block, P))
        return heads[min(i, len(hs) - 1)]

    def prime(st):
        """Put the head's first P-1 score blocks in flight."""
        blocks = st.blocks
        if st.groups:
            st.S = [ol.empty([st.G, block]) for _ in range(P)]
            for j in range(P - 1):
                _scores(st, j * block, block, st.S[j])
        else:
            for f in range(min(P - 1, len(blocks))):
                t0, n = blocks[f]
                st.buf[f] = _scores(st, t0, n, ol.empty([st.G, n]))

    head(ahead)
    prime(head(0))
    for i in range(len(hs)):
        st = head(i)
        head(i + ahead + 1)                                       # the next queries, early
        nxt = head(i + 1) if i + 1 < len(hs) else None
        blocks, groups = st.blocks, st.groups
        nb = 0
        if groups:
            S = st.S
            for g in ol.range(groups):
                t0 = g * (P * block)
                for p in range(P):
                    _scores(st, t0 + (p + P - 1) * block, block, S[(p + P - 1) % P])   # prefetch
                    _finish(st, S[p], t0 + p * block, block)
            nb = groups * P
            for j in range(P - 1):
                st.buf[nb + j] = S[j]
        primed = False
        for b in range(nb, len(blocks)):                          # the rest, unrolled
            for f in range(b, min(b + P, len(blocks))):           # keep P-1 blocks in flight
                if f not in st.buf:
                    t0, n = blocks[f]
                    st.buf[f] = _scores(st, t0, n, ol.empty([st.G, n]))
            if nxt is not None and not primed and b + P - 1 >= len(blocks):
                prime(nxt)                                        # ... continuing into the next head
                primed = True
            if b + 1 == len(blocks):
                st.qs = None                                      # its ACT RAM blocks are free
            t0, n = blocks[b]
            _finish(st, st.buf.pop(b), t0, n)
        if nxt is not None and not primed:
            prime(nxt)
        if emit is not None:
            emit(i, st.acc, st.l)
            heads[i] = None                                       # free its tiles
            del st
    if emit is not None:
        return None
    return [(st.acc, st.l) for st in heads]


@ol.jit
def attention_decode(q, kv, out, n_q_heads, n_kv_heads, seq_len, block):
    """out[h*G+g] = softmax(q K_h^T / sqrt(d)) V_h for the KV heads owned by this slice.

    q: Input [Hq, d]; kv: KVCache (heads round-robin over slices); out: Output [Hq, d].
    """
    G = n_q_heads // n_kv_heads
    scale = ol.LOG2E / math.sqrt(kv.d)
    for h in kv.owned_heads(n_kv_heads):
        acc, l = _attend(ol.load(q[h * G:(h + 1) * G, :]), kv, h, seq_len, block, scale, raw=True)
        inv = ol.recip(l)
        for g in ol.static_range(G):     # row by row: the DMA stores row g while the VPU scales g+1
            ol.store(out[h * G + g:h * G + g + 1, :], acc[g:g + 1, :] * inv[g:g + 1][:, None])


@ol.jit
def attention_layer(h, gamma, wq, wk, wv, wo, cos, sin, kv, out,
                    n_q_heads, n_kv_heads, pos, block, eps):
    """Full decode attention block for one token at position `pos`:

    xn = rmsnorm(h)*gamma; q,k,v projections; RoPE; append k,v to the cache; attention over
    pos+1 tokens; out = h + W_o o. Heads are split over slices: slice s owns KV heads s, s+S, ..
    and their query heads; wq/wk/wv hold the matching head rows per slice (see ref layout).
    h: Input [1, H]; wq: Weight [Hq_loc*d, H] per slice; wk, wv: Weight [Hkv_loc*d, H];
    wo: Weight [H, Hq*d] sharded by rows; cos, sin: Input [d/2]; out: Output [1, H].
    """
    S = ol.num_programs()
    d = kv.d
    G = n_q_heads // n_kv_heads
    x = ol.load(h)
    xs = ol.quantize(rmsnorm(x, ol.load(gamma), eps))
    q = ol.dot(xs, wq)                          # [1, Hkv_loc*G*d]
    k = ol.dot(xs, wk)                          # [1, Hkv_loc*d]
    v = ol.dot(xs, wv)
    c, s_ = ol.load(cos), ol.load(sin)
    scale = ol.LOG2E / math.sqrt(d)
    heads = list(kv.owned_heads(n_kv_heads))
    o_loc = ol.empty([G * len(heads), d])       # this slice's attention outputs, head-major
    for j, hh in enumerate(heads):
        kh = rope(k[:, j * d:(j + 1) * d], c, s_)
        ol.kv_append(kv, hh, pos, kh, v[:, j * d:(j + 1) * d])
        qh = ol.empty([G, d])
        for g in ol.static_range(G):
            r = (j * G + g) * d
            qh[g:g + 1, :].set(rope(q[:, r:r + d], c, s_) * scale)
        o_loc[j * G:(j + 1) * G, :].set(_attend(qh, kv, hh, pos + 1, block))
    # flatten [G*heads_loc, d] -> [1, G*heads_loc*d] view, gather across slices, output proj
    o_row = ol.empty([1, G * len(heads) * d])
    for i in ol.static_range(G * len(heads)):
        o_row[:, i * d:(i + 1) * d].set(o_loc[i:i + 1, :])
    o_all = ol.all_gather(o_row)                # [1, Hq*d], slice-major head order
    y = ol.all_gather(ol.dot(o_all, wo))        # [1, H]
    if ol.program_id() == 0:
        ol.store(out, x + y)
