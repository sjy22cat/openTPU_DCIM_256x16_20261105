"""Bit-exact functional simulator of the openTPU ISA (docs/isa.md).

It is the golden model for the RTL: after running the same program on the same DRAM images, the
TMEM and DRAM contents of every slice must be identical bit for bit.
"""
from __future__ import annotations

import os
from dataclasses import dataclass

import numpy as np

from . import fp32 as F
from . import isa as I
from . import quant as Q


@dataclass(frozen=True)
class Config:
    S: int = 1               # slices
    D: int = 32              # MXU depth == quantization block (int8 elements)
    MCOLS: int = 8           # MXU columns == max stationary rows
    ACT_BLOCKS: int = 64     # ACT RAM depth in blocks
    TMEM_WORDS: int = 1 << 16
    DRAM_BYTES: int = 1 << 20
    IMEM_WORDS: int = 1 << 16   # 8 words per instruction
    LANES: int = 8           # VPU lanes == TMEM banks (timing only; results do not depend on it)
    PAIR: bool = False       # MM PAIR / QACT DUP: 4-bit MMs of M <= MCOLS/2 rows at full rate
    DSTEP: bool = False      # the DMA runs DSTEP (Gated DeltaNet head steps on DRAM state)
    STREAM: bool = False     # the stream engine runs STREAM's hardware subset (docs/stream.md)
    ACT_ROWS: int = 0        # ACT RAM rows == max stationary rows of one MM (0: MCOLS); more
    #                          than MCOLS: the MXU replays each streamed chunk (docs/isa.md, MM)
    SEQ_WC: bool = False     # EXPERIMENTAL: the sequencer takes each program's wait entries
    #                          (WAITC, docs/isa.md "Wait counts"): the host writes them after
    #                          every program (opentpu.waits), the chain slots hold them. The
    #                          programs do not change; the ISA simulator ignores it

    @property
    def act_rows(self) -> int:
        return self.ACT_ROWS or self.MCOLS


def design_config(**kw) -> Config:
    """The Kintex-7 design point: 2 slices, 128-deep MXU (x 8 columns), 16 VPU lanes / TMEM
    banks, 64 ACT RAM blocks (K <= 8192). Override any field with keyword arguments."""
    base = dict(S=2, D=128, MCOLS=8, ACT_BLOCKS=64, LANES=16, DRAM_BYTES=1 << 24)
    base.update(kw)
    return Config(**base)


def board_config(**kw) -> Config:
    """The configuration of the target the environment selects (opentpu.target.current():
    OTPU_TARGET, default the YPCB-00338 card, targets/ypcb-00338.toml: one slice, 128-deep MXU
    x 4 columns, 8 VPU lanes / TMEM banks, 64K-word TMEM, 128 ACT RAM blocks (K <= 16384),
    4K-instruction IMEM, 4 GiB DRAM). The sizes come from the target. OTPU_MCOLS in the
    environment selects the MXU column count (default the target's: 4, as make -C
    boards/ypcb-00338 bit builds; 2: bit MCOLS=2), OTPU_LANES the VPU lanes / TMEM banks (default
    the target's 8; bit LANES=16; timing only, the programs do not change), OTPU_ACT_ROWS the ACT
    RAM rows (default MCOLS; more: the MXU replays each weight chunk for MCOLS rows at a time).
    The optional features stay off unless the environment turns them on, as before targets (the
    target states the hardware's truth: opentpu.target.config): OTPU_PAIR=1 column reuse (MM
    PAIR / QACT DUP), OTPU_DSTEP=1 the DMA's DSTEP, OTPU_STREAM=1 the stream engine,
    OTPU_SEQ_WC=1 the sequencer's wait entries (SEQ_WC, EXPERIMENTAL). They configure the
    simulators and the board model; on the card, opentpu.host.board.device_config takes them
    from the bitstream."""
    from .target import current
    a, env = current().arch, os.environ
    base = dict(S=a["S"], D=a["D"], MCOLS=int(env.get("OTPU_MCOLS", a["MCOLS"])),
                ACT_BLOCKS=a["ACT_BLOCKS"], LANES=int(env.get("OTPU_LANES", a["LANES"])),
                ACT_ROWS=int(env.get("OTPU_ACT_ROWS", a["ACT_ROWS"])),
                TMEM_WORDS=a["TMEM_WORDS"], IMEM_WORDS=a["IMEM_WORDS"],
                DRAM_BYTES=a["DRAM_BYTES"],
                PAIR=bool(int(env.get("OTPU_PAIR", 0))),
                DSTEP=bool(int(env.get("OTPU_DSTEP", 0))),
                STREAM=bool(int(env.get("OTPU_STREAM", 0))),
                SEQ_WC=bool(int(env.get("OTPU_SEQ_WC", 0))))
    base.update(kw)
    return Config(**base)


class SimError(RuntimeError):
    pass


class Slice:
    def __init__(self, cfg: Config, sid: int, program: list[I.Instr], dram: np.ndarray | None):
        self.cfg, self.sid = cfg, sid
        self.prog = program
        self.dram = np.zeros(cfg.DRAM_BYTES, dtype=np.uint8)
        if dram is not None:
            self.dram[: len(dram)] = dram
        self.tmem = np.zeros(cfg.TMEM_WORDS, dtype=np.uint32)
        self.act = np.zeros((cfg.act_rows, cfg.ACT_BLOCKS * cfg.D), dtype=np.int8)
        # the scale record of each (row, block): the row's Sa and the sub-blocks' offsets da
        self.ascale = np.zeros((cfg.act_rows, cfg.ACT_BLOCKS), dtype=np.float32)
        self.adoff = np.zeros((cfg.act_rows, cfg.ACT_BLOCKS, Q.NSUB), dtype=np.uint8)
        self.R = [0] * 16
        self.pc = 0
        self.stack: list[list[int]] = []
        self.halted = False
        self.chain: tuple | None = None       # HALT CHAIN: (DRAM byte address, instructions)
        self.waiting: I.Instr | None = None   # blocked on a collective
        self.polling: I.Instr | None = None   # a WAITW whose condition does not hold yet
        self.stalls = 0                       # WAITWs that had to wait (for the host)
        self.icount = 0

    # ---------------------------------------------------------------- memory helpers
    @property
    def m32(self) -> np.ndarray:
        return self.dram.view(np.uint32)

    def reg(self, r: int) -> int:
        return 0 if r == 0 else self.R[r]

    def _widx(self, byte_addr: np.ndarray | int) -> np.ndarray:
        a = np.asarray(byte_addr, dtype=np.int64)
        if np.any(a % 4) or np.any(a < 0) or np.any(a + 4 > self.cfg.DRAM_BYTES):
            raise SimError(f"slice {self.sid}: bad DRAM word address")
        return a // 4

    def _tidx(self, idx: np.ndarray) -> np.ndarray:
        if np.any(idx < 0) or np.any(idx >= self.cfg.TMEM_WORDS):
            raise SimError(f"slice {self.sid}: TMEM index out of range")
        return idx

    def tget(self, idx) -> np.ndarray:
        return self.tmem[self._tidx(np.asarray(idx, dtype=np.int64))].view(np.float32)

    def tput(self, idx, vals) -> None:
        self.tmem[self._tidx(np.asarray(idx, dtype=np.int64))] = F.f32(vals).view(np.uint32)

    # ---------------------------------------------------------------- execution
    def step(self) -> None:
        """Execute one instruction (or mark the slice as waiting on a collective)."""
        if self.pc >= len(self.prog):
            raise SimError(f"slice {self.sid}: pc {self.pc} past end of program")
        ins = self.prog[self.pc]
        op = ins.op
        self.icount += 1
        if op == I.HALT:
            self.halted = True
            if ins.flags & I.F_CHAIN:
                self.chain = (self.reg(ins.ra), self.reg(ins.rb))
            return
        if op in (I.BAR, I.GATHER):
            self.waiting = ins
            return
        if op == I.WAITW:
            if self.poll(ins):
                self.advance()
            else:
                self.polling = ins
                self.stalls += 1
            return
        if op == I.LOOP:
            count = (self.reg(ins.ra) + ins.w[1]) & 0xFFFFFFFF
            body = ins.w[0]
            if body < 1:
                raise SimError("LOOP with empty body")
            # whatever the count: one of 0 would jump past the enclosing body's end (and skip
            # its back edge)
            end = self.pc + body
            if any(e[1] == end for e in self.stack):
                raise SimError("nested loop bodies end on the same instruction")
            if count == 0:
                self.pc += 1 + body
                return
            if len(self.stack) >= 4:
                raise SimError("loop stack overflow")
            self.stack.append([self.pc + 1, end, count])
            self.pc += 1
            return
        self.execute(ins)
        self.advance()

    def holds(self, ins: I.Instr) -> bool:
        """Whether WAITW ins's condition holds on its DRAM word now (no effect: poll takes it)."""
        a = (self.reg(ins.ra) + ins.w[0]) & 0xFFFFFFFF
        v = int(self.m32[self._widx(np.int64(a))])
        return I.waitw_holds(v, self.reg(ins.rc) + ins.w[2], ins.flags & 3, ins.w[3])

    def poll(self, ins: I.Instr) -> bool:
        """WAITW's DRAM read: if its condition holds, T[R[rb] + w2] = the word's bits and True."""
        a = (self.reg(ins.ra) + ins.w[0]) & 0xFFFFFFFF
        v = int(self.m32[self._widx(np.int64(a))])
        if not I.waitw_holds(v, self.reg(ins.rc) + ins.w[2], ins.flags & 3, ins.w[3]):
            return False
        self.tmem[self._tidx(np.int64((self.reg(ins.rb) + ins.w[1]) & 0xFFFFFFFF))] = v
        return True

    def advance(self) -> None:
        pc = self.pc
        if self.stack and self.stack[-1][1] == pc:
            top = self.stack[-1]
            if top[2] > 1:
                top[2] -= 1
                self.pc = top[0]
                return
            self.stack.pop()
        self.pc = pc + 1

    def execute(self, ins: I.Instr) -> None:
        op, w = ins.op, ins.w
        if op == I.NOP:
            return
        if op == I.LI:
            if ins.rd:
                self.R[ins.rd] = w[0]
            return
        if op == I.ADDI:
            if ins.rd:
                self.R[ins.rd] = (self.reg(ins.ra) + w[0]) & 0xFFFFFFFF
            return
        if op == I.RLD:
            v = int(self.tmem[self._tidx(np.int64((self.reg(ins.ra) + w[0]) & 0xFFFFFFFF))])
            v = v if ins.flags & I.F_RAW else I.f2i(v)
            if ins.flags & I.F_MUL:
                v = (v * ((self.reg(ins.rb) + w[1]) & 0xFFFFFFFF)) & 0xFFFFFFFF
            if ins.flags & I.F_BOUND and not w[2] <= v <= w[3]:
                raise SimError(f"RLD at pc {self.pc}: {v} outside its bound [{w[2]}, {w[3]}] "
                               f"({ins.comment})")
            if ins.rd:
                self.R[ins.rd] = v
            return
        if op == I.LD:
            d = (self.reg(ins.ra) + w[0]) & 0xFFFFFFFF
            t = (self.reg(ins.rb) + w[1]) & 0xFFFFFFFF
            n = w[2]
            wi = self._widx(d + 4 * np.arange(n))
            self.tmem[self._tidx(t + np.arange(n))] = self.m32[wi]
            return
        if op == I.ST:
            d = (self.reg(ins.ra) + w[0]) & 0xFFFFFFFF
            t = (self.reg(ins.rb) + w[1]) & 0xFFFFFFFF
            n = w[2]
            wi = self._widx(d + 4 * np.arange(n))
            self.m32[wi] = self.tmem[self._tidx(t + np.arange(n))]
            return
        if op == I.DSTEP:
            return self._dstep(ins)
        if op == I.STREAM:
            return self._stream(ins)
        if op == I.MM:
            return self._mm(ins)
        if op == I.QACT:
            return self._qact(ins)
        if op == I.QST:
            return self._qst(ins)
        if op == I.VOP:
            return self._vop(ins)
        raise SimError(f"slice {self.sid}: bad opcode {op:#x} at pc {self.pc}")

    def _dstep(self, ins: I.Instr) -> None:
        """DSTEP: every input (q, k, v, e, beta and each state row) is read before the row's
        results are written; o is written last."""
        w = ins.w
        d = (self.reg(ins.ra) + w[0]) & 0xFFFFFFFF
        qk = (self.reg(ins.rb) + w[1]) & 0xFFFFFFFF
        v = (self.reg(ins.rc) + w[2]) & 0xFFFFFFFF
        rows, cols = w[3] & 0xFFFF, w[3] >> 16
        g, o, gs = w[4], w[5], w[6]
        if not (0 < rows <= I.DSTEP_MAX_ROWS) or cols % 64 or not (0 < cols <= 256):
            raise SimError("DSTEP: rows must be 1..256, cols 64, 128, 192 or 256")
        if d % self.cfg.D:
            raise SimError("DSTEP: the state must be DRAM-chunk aligned")
        q = self.tget(qk + np.arange(cols))[None, :]
        k = self.tget(qk + cols + np.arange(cols))[None, :]
        vv = self.tget(v + np.arange(rows))
        e = self.tget(np.array([g]))
        beta = self.tget(np.array([g + gs]))
        wi = self._widx(d + 4 * np.arange(rows * cols))
        if ins.flags & I.F_DZERO:
            S = np.zeros((rows, cols), np.float32)
        else:
            S = self.m32[wi].view(np.float32).reshape(rows, cols)
        kv = F.rdot(S, k)
        dd = F.mul(F.sub(vv, F.mul(kv, e)), beta)
        S = F.outer(S, e[None, :], dd[:, None], k)
        oo = F.rdot(S, q)
        self.m32[wi] = F.f32(S).reshape(-1).view(np.uint32)
        self.tput(o + np.arange(rows), oo)

    def _stream(self, ins: I.Instr) -> None:
        """STREAM (docs/stream.md, 3): the descriptor, the column slots, the row scalars and the
        constants are read first; row r of the stream is written after row r is read (a later
        row reads what an earlier row wrote); O and the saved registers are written last."""
        w, fl, D = ins.w, ins.flags, self.cfg.D
        at, ks = w[0] & 0xFFFF, w[0] >> 16
        n = min(I.STREAM_DESC_FIXED + I.STREAM_MAX_OPS, self.cfg.TMEM_WORDS - at)
        try:
            d = I.StreamDesc.decode(self.tmem[self._tidx(at + np.arange(max(n, 0)))])
        except (ValueError, IndexError) as e:
            raise SimError(f"STREAM: {e}") from None
        src = (self.reg(ins.ra) + w[1]) & 0xFFFFFFFF
        dst = (self.reg(ins.ra) + w[2]) & 0xFFFFFFFF
        vec = (self.reg(ins.rb) + w[3]) & 0xFFFFFFFF
        xa = (self.reg(ins.rc) + w[4]) & 0xFFFFFFFF
        ka = (self.reg(ins.rd) + w[5]) & 0xFFFFFFFF
        out = w[6]
        rows, cols = d.rows, d.cols
        if not rows or not cols:
            raise SimError("STREAM: rows and cols must be nonzero")
        if d.q_en and d.o_reg_en:
            raise SimError("STREAM: O is either Q's dot or a register")
        if any(op > I.SC_EXP2SUB for op, _, _, _ in d.ops):
            raise SimError("STREAM: bad scalar op")
        uses_g = d.u_mode in (I.U_FMMA, I.U_MUL)
        uses_b = d.u_mode in (I.U_FMMA, I.U_ADD)
        unary = (I.SC_MOV, I.SC_RSQRT, I.SC_RECIP, I.SC_EXP2, I.SC_LOG2)
        opnds = [c for op, _, a, b in d.ops for c in ((a,) if op in unary else (a, b))]
        slots, consts = set(), {j for j in range(4) if d.rinit >> j & 1}
        consts |= {c - I.OP_K0 for c in opnds if I.OP_K0 <= c < I.OP_K0 + 4}
        for on, src_, idx, s_slot, s_const in (
                (d.a_en, d.a_op, d.a_idx, I.A_SLOT, I.A_CONST),
                (uses_g, d.g_src, d.g_idx, I.G_SLOT, I.G_CONST),
                (uses_b, d.b_src, d.b_idx, I.B_SLOT, I.B_CONST)):
            if on and src_ in (s_slot, s_const):
                if idx >= I.STREAM_SLOTS:
                    raise SimError("STREAM: slot or constant index out of range")
                (slots if src_ == s_slot else consts).add(idx)
        if (d.q_en and not d.q_self) or d.out_p2:
            slots.add(d.q_idx)
        # ---- the inputs, before anything is written
        C = {i: self.tget(vec + i * cols + np.arange(cols))[None, :] for i in sorted(slots)}
        K = {j: self.tget(np.array([ka + j * ks])) for j in sorted(consts)}
        X = self.tget(xa + np.arange(rows)) if I.OP_X in opnds else None
        in_t, out_t = bool(fl & I.F_SRC_T), bool(fl & I.F_DST_T)
        zero, nodst = bool(fl & I.F_SZERO), bool(fl & I.F_NODST)
        r, c = np.arange(rows)[:, None], np.arange(cols)[None, :]
        sidx = src + r * (d.srs or cols) + c if in_t else src + 4 * (r * cols + c)
        didx = dst + r * (d.drs or cols) + c if out_t else dst + 4 * (r * cols + c)
        if (not in_t and not zero and src % D) or (not out_t and not nodst and dst % D):
            raise SimError("STREAM: a DRAM stream must be DRAM-chunk aligned")
        if not in_t and not zero:
            sidx = self._widx(sidx)
        if not out_t and not nodst:
            didx = self._widx(didx)
        # rows that read what an earlier row wrote run one at a time
        same = in_t == out_t and not zero and not nodst
        seq = same and not np.array_equal(sidx, didx) and \
            np.intersect1d(sidx, didx).size > 0
        regs = [np.zeros(1, np.float32)] * 8
        for j in range(4):
            if d.rinit >> j & 1:
                regs[4 + j] = K[j]
        written, carried = set(), False
        for op, dst_, a, b in d.ops:
            carried |= any(x < 8 and x not in written and x in {o[1] for o in d.ops}
                           for x in ((a,) if op in unary else (a, b)))
            written.add(dst_)
        one = np.ones(1, np.float32)

        def value(code, A, Xr):
            return (regs[code] if code < 8 else A if code == I.OP_A else Xr if code == I.OP_X
                    else K[code - I.OP_K0] if code < I.OP_ZERO
                    else np.zeros(1, np.float32) if code == I.OP_ZERO else one)

        def scalar(A, Xr):
            for op, dst_, a, b in d.ops:
                x = value(a, A, Xr)
                y = x if op in unary else value(b, A, Xr)     # a unary op has no b
                regs[dst_] = {
                    I.SC_ADD: F.add, I.SC_SUB: F.sub, I.SC_MUL: F.mul, I.SC_MAX: F.fmax,
                    I.SC_MIN: F.fmin, I.SC_MOV: lambda p, q: F.ftz(p),
                    I.SC_RSQRT: lambda p, q: F.rsqrt(p), I.SC_RECIP: lambda p, q: F.recip(p),
                    I.SC_EXP2: lambda p, q: F.exp2(p), I.SC_LOG2: lambda p, q: F.log2(p),
                    I.SC_EXP2SUB: lambda p, q: F.exp2(F.sub(p, q))}[op](x, y)
            return [regs[d.d_reg], regs[d.g_idx & 7], regs[d.b_idx & 7], regs[d.o_reg]]

        def block(S, lo, hi):
            n = hi - lo
            if not d.a_en:
                A = np.zeros(n, np.float32)
            elif d.a_op == I.A_MAX:
                A = F.chain_max(S)
            else:
                opA = {I.A_SLOT: lambda: C.get(d.a_idx), I.A_SELF: lambda: S,
                       I.A_CONST: lambda: K.get(d.a_idx, one)[None, :]}[d.a_op]()
                A = F.rdot(S, opA)
            Xb = X[lo:hi] if X is not None else None
            if carried:
                per = [scalar(A[i:i + 1], Xb[i:i + 1] if Xb is not None else None)
                       for i in range(n)]
                Dv, Gr, Br, Or = (np.concatenate([p[k] for p in per]) for k in range(4))
            else:
                Dv, Gr, Br, Or = (np.broadcast_to(v, (n,)).astype(np.float32)
                                  for v in scalar(A, Xb))
            G = {I.G_REG: lambda: Gr[:, None], I.G_SLOT: lambda: C.get(d.g_idx),
                 I.G_CONST: lambda: K.get(d.g_idx, one)[None, :],
                 I.G_ONE: lambda: one[None, :]}[d.g_src]() if uses_g else None
            B = {I.B_SLOT: lambda: C.get(d.b_idx), I.B_CONST: lambda: K.get(d.b_idx, one)[None, :],
                 I.B_REG: lambda: Br[:, None]}.get(d.b_src, lambda: None)() if uses_b else None
            if uses_b and B is None:
                raise SimError("STREAM: bad B source")
            Y = {I.U_PASS: lambda: F.ftz(S), I.U_FMMA: lambda: F.outer(S, G, Dv[:, None], B),
                 I.U_MUL: lambda: F.mul(S, G),
                 I.U_ADD: lambda: F.add(S, F.mul(Dv[:, None], B))}[d.u_mode]()
            O = (F.rdot(Y, Y if d.q_self else C[d.q_idx]) if d.q_en
                 else Or if d.o_reg_en else None)
            return (F.mul(Y, C[d.q_idx]) if d.out_p2 else Y), O

        def load(lo, hi):
            if zero:
                return np.zeros((hi - lo, cols), np.float32)
            if in_t:
                return self.tget(sidx[lo:hi])
            return self.m32[sidx[lo:hi]].view(np.float32)

        def store(lo, hi, Y):
            if nodst:
                return
            if out_t:
                self.tput(didx[lo:hi], Y)
            else:
                self.m32[didx[lo:hi]] = F.f32(Y).view(np.uint32)

        Os = []
        for lo, hi in ([(i, i + 1) for i in range(rows)] if seq else [(0, rows)]):
            Y, O = block(load(lo, hi), lo, hi)
            store(lo, hi, Y)
            Os.append(O)
        if d.q_en or d.o_reg_en:
            self.tput(out + np.arange(rows), np.concatenate(Os))
        for j in range(4):
            if d.rsave >> j & 1:
                self.tput(np.array([ka + j * ks]), regs[4 + j][-1:])

    # ---------------------------------------------------------------- MXU
    def _mx_scales(self, wf, ssa, srs, N, KB, k0, unit, rsc):
        """The weights' scale rows (docs/isa.md "Weight formats"): Sw [N] fp32, and per (row,
        block, group) the offset dw and the multiplier m [N, KB, G] (G = 8 groups of D/8 for
        NVFP4, else the 4 sub-blocks of D/4)."""
        G = 8 if wf == I.WNV else Q.NSUB
        if unit:
            return (np.ones(N, np.float32), np.zeros((N, KB, G), np.int64),
                    np.ones((N, KB, G), np.int64))
        align = 16 if wf == I.WNV else 8 if wf in (I.W4I, I.W4F) and not rsc else 4
        if ssa % align or srs % align:
            raise SimError(f"MM: ssa and srs must be multiples of {align}")
        rows = ssa + np.arange(N) * srs
        sw = self.m32[self._widx(rows)].view(np.float32)
        if rsc:
            return sw, np.zeros((N, KB, G), np.int64), np.ones((N, KB, G), np.int64)
        kk = k0 + np.arange(KB)
        if wf == I.W8:                    # one dw byte per block after Sw
            ba = rows[:, None] + 4 + kk[None, :]
            if ba.max() >= self.cfg.DRAM_BYTES:
                raise SimError("MM: scale rows out of range")
            dw = np.repeat(self.dram[ba].astype(np.int64)[:, :, None], G, axis=2)
            return sw, dw, np.ones((N, KB, G), np.int64)
        if wf in (I.W4I, I.W4F):          # a word per block after Sw and a reserved word
            word = self.m32[self._widx(rows[:, None] + 8 + 4 * kk[None, :])].astype(np.int64)
            dw = np.repeat((word & 0xFF)[:, :, None], G, axis=2)
            m = np.stack([(word >> (8 + 6 * b)) & 63 for b in range(G)], -1)
            return sw, dw, m
        # NVFP4: eight E4M3 bytes per block after Sw and three reserved words
        ba = rows[:, None, None] + 16 + 8 * kk[None, :, None] + np.arange(8)[None, None, :]
        if ba.max() >= self.cfg.DRAM_BYTES:
            raise SimError("MM: scale rows out of range")
        e4 = self.dram[ba].astype(np.int64)
        if np.any(e4 & 0x80):
            raise SimError("MM: an NVFP4 scale with the sign bit set")
        E, Mt = (e4 >> 3) & 15, e4 & 7
        return sw, 15 - np.maximum(E, 1), np.where(E > 0, 8 + Mt, Mt)

    MM_CHUNK = 1 << 22                    # (row, output, block, group) terms per numpy pass

    def _mm(self, ins: I.Instr) -> None:
        cfg, w = self.cfg, ins.w
        D = cfg.D
        sa = (self.reg(ins.ra) + w[0]) & 0xFFFFFFFF
        ssa = (self.reg(ins.rb) + w[1]) & 0xFFFFFFFF
        out = (self.reg(ins.rc) + w[2]) & 0xFFFFFFFF
        N, KB, k0 = w[3] & 0xFFFF, (w[3] >> 16) & 0xFF, (w[3] >> 24) & 0xFF
        rs = w[4]
        ors, M, ab = w[5] & 0xFFFF, (w[5] >> 16) & 0xFF, w[5] >> 24
        srs = w[6]
        unit, accf = bool(ins.flags & I.F_UNIT), bool(ins.flags & I.F_ACC)
        pair, rsc = bool(ins.flags & I.F_PAIR), bool(ins.flags & I.F_RSC)
        R = 2 * M if pair else M                          # ACT rows read
        if not N or not KB:
            raise SimError("MM: N and KB must be at least 1")
        if not (0 < R <= cfg.act_rows) or ab + KB > cfg.ACT_BLOCKS:
            raise SimError("MM: M or ACT RAM range out of bounds")
        if M > cfg.MCOLS and ins.flags & (I.F_RMAX | I.F_ASCALE):
            raise SimError("MM: RMAX and ASCALE need M <= MCOLS")
        if pair and R > cfg.MCOLS:
            raise SimError("MM: PAIR needs 2*M <= MCOLS")
        wf = (ins.flags >> I.WF_SHIFT) & 3
        if pair and wf == I.W8:
            raise SimError("MM: PAIR needs 4-bit weights")
        if pair and k0 % 2:
            raise SimError("MM: PAIR needs an even k0")
        if rsc and wf == I.WNV:
            raise SimError("MM: RSC does not take NVFP4")
        if ins.flags & I.F_ASCALE and not (unit and accf):
            raise SimError("MM: ASCALE needs UNIT and ACC")
        bpb = D if wf == I.W8 else D // 2                 # streamed bytes per K-block
        if sa % D or rs % D or sa + (N - 1) * rs + -(-KB * bpb // D) * D > cfg.DRAM_BYTES:
            raise SimError("MM: streamed rows must be D-byte aligned and in range")
        wv = np.lib.stride_tricks.as_strided(self.dram[sa:], (N, KB, bpb),
                                             (rs, bpb, 1))               # [N, KB, bpb], no copy
        if wf == I.W8:
            wel = wv.view(np.int8)
        else:
            wel = Q.DEC["int4" if wf == I.W4I else "fp4"][Q.unpack4(wv)]
        sw, dw, mw = self._mx_scales(wf, ssa, srs, N, KB, k0, unit, rsc)
        G = dw.shape[2]
        # the ACT row of each (output row, block): PAIR takes the odd blocks from row j + M
        kk = np.arange(KB)
        rsel = np.arange(M)[:, None] + np.where(pair & (kk % 2 == 1), M, 0)[None, :]   # [M, KB]
        sa_rows = self.ascale[:R, ab:ab + KB]
        if np.any(sa_rows.view(np.uint32) != sa_rows[np.arange(R) % M][:, :1].view(np.uint32)):
            raise SimError("MM: the ACT rows' blocks hold different Sa (more than one QACT)")
        act = self.act[:R, ab * D:(ab + KB) * D].reshape(R, KB, D)
        act = act[rsel, kk[None, :]].astype(np.float64)                 # [M, KB, D]
        da = self.adoff[:R, ab:ab + KB][rsel, kk[None, :]].astype(np.int64)   # [M, KB, 4]
        da = np.repeat(da, G // Q.NSUB, axis=2)                          # [M, KB, G]
        W = I.MX_W[wf]
        acc = np.zeros((M, N), np.int64)
        step = max(1, self.MM_CHUNK // max(1, M * KB * G))
        for n0 in range(0, N, step):
            n1 = min(N, n0 + step)
            # exact group sums (|c| < 2^19, float64 BLAS), B = m << sh (sh < 0: the group drops)
            c = np.einsum("jkgi,nkgi->jnkg", act.reshape(M, KB, G, D // G),
                          wel[n0:n1].reshape(n1 - n0, KB, G, D // G).astype(np.float64),
                          optimize=True).astype(np.int64)                  # [M, n, KB, G]
            sh = W - dw[None, n0:n1] - da[:, None]                             # [M, n, KB, G]
            B = np.where(sh >= 0, mw[None, n0:n1] << np.maximum(sh, 0), 0)
            acc[:, n0:n1] = (B * c).sum(axis=(2, 3))
        y = F.mul(F.mul(F.i2f(acc), sw[None, :]),
                  F.mul(self.ascale[:M, ab][:, None], np.float32(2.0 ** -W)))
        idx = out + np.arange(M)[:, None] * ors + np.arange(N)[None, :]
        if ins.flags & I.F_ASCALE:                 # y = old * alpha[j] + y
            alpha = self.tget(ssa + np.arange(M))[:, None]
            y = F.add(F.mul(self.tget(idx), alpha), y)
        elif accf:
            y = F.add(self.tget(idx), y)
        self.tput(idx, y)
        if ins.flags & I.F_RMAX:                   # row max of the written values, in n order
            mx = F.chain_max(y)
            self.tput(out + M * ors + np.arange(M), mx)

    # ---------------------------------------------------------------- quantizer
    def _quant_rows(self, src, rows, KB, srs, g, row_mode, cscale=None, rscale=None):
        """docs/isa.md "Quantization" of rows rows x KB*D at src (groups of g elements)."""
        D = self.cfg.D
        idx = src + np.arange(rows)[:, None] * srs + np.arange(KB * D)[None, :]
        x = self.tget(idx)                                                  # [rows, KB*D]
        if rscale is not None:                     # QACT RSCALE: x * T[rscale + r]
            x = F.mul(x, self.tget(rscale + np.arange(rows))[:, None])
        if cscale is not None:                     # QACT CSCALE: x * T[cscale + c]
            x = F.mul(x, self.tget(cscale + np.arange(KB * D))[None, :])
        return F.quantize_mx(x, g, row_mode)

    def _qact(self, ins: I.Instr) -> None:
        cfg, w = self.cfg, ins.w
        src = (self.reg(ins.ra) + w[0]) & 0xFFFFFFFF
        rows, ab, KB = w[1] & 0xFF, (w[1] >> 8) & 0xFF, w[1] >> 16
        srs = w[2]
        dup = bool(ins.flags & I.F_DUP)
        if (2 * rows > cfg.MCOLS if dup else rows > cfg.act_rows) or ab + KB > cfg.ACT_BLOCKS:
            raise SimError("QACT out of ACT RAM bounds")
        cs = (w[3] & 0xFFFFFFFF) if ins.flags & I.F_CSCALE else None
        rsc = (w[4] & 0xFFFFFFFF) if ins.flags & I.F_RSCALE else None
        q, s, d = self._quant_rows(src, rows, KB, srs, cfg.D // Q.NSUB,
                                   bool(ins.flags & I.F_ROW), cs, rsc)
        for r0 in ((0, rows) if dup else (0,)):     # DUP: rows r and r + rows, same bytes
            self.act[r0:r0 + rows, ab * cfg.D:(ab + KB) * cfg.D] = q
            self.ascale[r0:r0 + rows, ab:ab + KB] = s[:, None]
            self.adoff[r0:r0 + rows, ab:ab + KB] = d.reshape(rows, KB, Q.NSUB)

    def _qst(self, ins: I.Instr) -> None:
        cfg, w = self.cfg, ins.w
        src = (self.reg(ins.ra) + w[0]) & 0xFFFFFFFF
        dst = (self.reg(ins.rb) + w[1]) & 0xFFFFFFFF
        sdst = (self.reg(ins.rc) + w[2]) & 0xFFFFFFFF
        rows, KB = w[3] & 0xFFFF, w[3] >> 16
        srs, drs, es = w[4], w[5], w[6]
        row_mode = bool(ins.flags & I.F_ROW)
        half = bool(ins.flags & I.F_HALF)
        if half and not row_mode:
            raise SimError("QST: HALF needs ROW mode")
        q, s, d = self._quant_rows(src, rows, KB, srs, cfg.D, row_mode)
        ne = KB * cfg.D // 2 if half else KB * cfg.D   # HALF: the row's first half only
        baddr = dst + np.arange(rows)[:, None] * drs + np.arange(ne)[None, :] * es
        if np.any(baddr < 0) or np.any(baddr >= cfg.DRAM_BYTES):
            raise SimError("QST: byte address out of range")
        if row_mode:                               # the RSC scale row: S
            sbytes = np.zeros((rows, 4), np.uint8)
            sbytes[:, :4] = s[:, None].view(np.uint8)
        else:                                      # the int8 scale row: S, then the bytes d_k
            sbytes = np.zeros((rows, 4 + 4 * -(-KB // 4)), np.uint8)
            sbytes[:, :4] = s[:, None].view(np.uint8)
            sbytes[:, 4:4 + KB] = d
        sa = sdst + np.arange(rows)[:, None] * sbytes.shape[1] + np.arange(sbytes.shape[1])
        if sdst % 4 or np.any(sa >= cfg.DRAM_BYTES):
            raise SimError("QST: bad scale address")
        if _overlap(baddr, sa.reshape(-1)):
            raise SimError("QST: the data and scale ranges overlap")
        self.dram[baddr] = q[:, :ne].view(np.uint8)
        self.dram[sa] = sbytes

    # ---------------------------------------------------------------- VPU
    def _vop(self, ins: I.Instr) -> None:
        w = ins.w
        dst = (self.reg(ins.ra) + w[0]) & 0xFFFFFFFF
        a = (self.reg(ins.rb) + w[1]) & 0xFFFFFFFF
        b = (self.reg(ins.rc) + w[2]) & 0xFFFFFFFF
        rows, cols = w[3] & 0xFFFF, w[3] >> 16
        drs, ars = w[4] & 0xFFFF, w[4] >> 16
        brs, func, bmode = w[5] & 0xFFFF, (w[5] >> 16) & 0xFF, (w[5] >> 24) & 3
        w7 = (self.reg(ins.rd) + w[6]) & 0xFFFFFFFF
        imm = np.array([w7], dtype=np.uint32).view(np.float32)[0]
        r = np.arange(rows)[:, None]
        c = np.arange(cols)[None, :]
        if func == I.V_OUTER:
            return self._outer(ins, dst, a, b, w7, rows, cols, drs, brs, bmode)
        aidx = a + r * ars + c
        A = self.tget(aidx) if func != I.V_FILL else None
        bidx = None
        if func in I.READS_B:
            if bmode == I.B_FULL:
                bidx = b + r * brs + c
            elif bmode == I.B_ROW:
                bidx = np.broadcast_to(b + r * brs, (rows, cols))
            elif bmode == I.B_COL:
                bidx = np.broadcast_to(b + c, (rows, cols))
            B = self.tget(bidx) if bidx is not None else np.full((rows, cols), imm, np.float32)
        if func == I.V_ARGMAX:
            # per row the maximum and the index of its first column (+ the integer base w7)
            if rows > 1 and drs < 2:
                raise SimError("VOP ARGMAX: rows > 1 needs drs >= 2 (a pair per row)")
            didx = (dst + np.arange(rows)[:, None] * drs + np.arange(2)[None, :]).reshape(-1)
            ends = np.repeat((np.arange(rows) + 1) * cols - 1, 2)   # after the row's reads
            self._check_hazard(didx, [aidx.reshape(-1)], wpos=ends)
            c = np.argmax(F._key(A), axis=1)
            base = w7 - (1 << 32) if w7 >> 31 else w7
            ci = ((c + base) & 0xFFFFFFFF).astype(np.uint32).view(np.int32)   # int32, as i2f's
            self.tput(didx, np.stack([F.chain_max(A), F.i2f(ci)], axis=1).reshape(-1))
            return
        if func in I.REDUCE:
            didx = dst + np.arange(rows) * drs
            reads = [aidx.reshape(-1)] + ([bidx.reshape(-1)] if bidx is not None else [])
            self._check_hazard(np.repeat(didx, cols), reads, reduce_cols=cols)
            if func == I.V_RSUM:
                acc = F.interleaved_sum(A, F.RED_PARTIALS)
            elif func == I.V_RSSQ:
                acc = F.rdot(A, A)
            elif func == I.V_RDOT:
                acc = F.rdot(A, B)
            else:
                acc = F.chain_max(A)
            self.tput(didx, acc)
            return
        didx = dst + r * drs + c
        reads = ([aidx.reshape(-1)] if func != I.V_FILL else []) + \
            ([bidx.reshape(-1)] if bidx is not None else [])
        self._check_hazard(didx.reshape(-1), reads)
        ops = {I.V_ADD: lambda: F.add(A, B), I.V_SUB: lambda: F.sub(A, B),
               I.V_RSUB: lambda: F.sub(B, A), I.V_MUL: lambda: F.mul(A, B),
               I.V_MAX: lambda: F.fmax(A, B), I.V_MIN: lambda: F.fmin(A, B),
               I.V_COPY: lambda: F.ftz(A), I.V_EXP2: lambda: F.exp2(A),
               I.V_RECIP: lambda: F.recip(A), I.V_RSQRT: lambda: F.rsqrt(A),
               I.V_ABS: lambda: F.fabs(A), I.V_FILL: lambda: F.ftz(B),
               I.V_EXP2SUB: lambda: F.exp2(F.sub(A, B)), I.V_LOG2: lambda: F.log2(A)}
        if func not in ops:
            raise SimError(f"VOP: bad func {func}")
        self.tput(didx, ops[func]())

    def _outer(self, ins, dst, d, b, cv, rows, cols, drs, brs, bmode) -> None:
        """dst = dst * Dv + B(r) * Cv(c). Cv and Dv are read before anything is written (the
        RTL buffers them), so they may overlap dst; B(r) is read with every element."""
        if bmode != I.B_ROW or cols > I.OUTER_MAX_COLS:
            raise SimError("VOP OUTER: bmode must be ROW and cols <= 256")
        r = np.arange(rows)[:, None]
        c = np.arange(cols)[None, :]
        C = self.tget(cv + c)
        if ins.flags & I.F_DONE:
            Dv = np.ones((1, cols), np.float32)
        else:
            Dv = self.tget(np.broadcast_to(d if ins.flags & I.F_DSCALAR else d + c, (1, cols)))
        didx = dst + r * drs + c
        bidx = np.broadcast_to(b + r * brs, (rows, cols))
        self._check_hazard(didx.reshape(-1), [didx.reshape(-1), bidx.reshape(-1)])
        self.tput(didx, F.outer(self.tget(didx), Dv, self.tget(bidx), C))

    def _check_hazard(self, writes: np.ndarray, reads: list, reduce_cols: int = 0,
                      wpos=None) -> None:
        """The RTL processes elements in order; a later element must not read an earlier write.
        wpos: each write's position in the read order (default: the element's own)."""
        n = len(writes)
        pos = np.arange(n) if wpos is None else np.asarray(wpos, np.int64)
        if reduce_cols:     # a reduction writes its row after reading the whole row
            pos = (pos // reduce_cols + 1) * reduce_cols - 1
        writes = np.asarray(writes, np.int64)
        order = np.argsort(writes, kind="stable")
        uw, first = np.unique(writes[order], return_index=True)
        first_pos = pos[order][first]                  # earliest write position per address
        for rd in reads:
            rd = np.asarray(rd, np.int64)
            loc = np.minimum(np.searchsorted(uw, rd), len(uw) - 1)
            hit = uw[loc] == rd
            late = hit & (first_pos[loc] < np.arange(len(rd)))
            if late.any():
                v = int(rd[np.argmax(late)])
                raise SimError(f"slice {self.sid}: VOP read-after-write hazard at TMEM {v}")


def _overlap(a, b) -> bool:
    """Whether two sets of addresses meet (their spans first: most never do)."""
    a, b = np.asarray(a, np.int64).reshape(-1), np.asarray(b, np.int64).reshape(-1)
    if a.max() < b.min() or b.max() < a.min():
        return False
    return np.intersect1d(a, b).size > 0


ARG0 = 8                    # the run's arguments are R8..R15 at the start (docs/isa.md)


def _regs(args) -> list[int]:
    args = list(args or [])
    if len(args) > 8:
        raise ValueError("at most 8 run arguments")
    R = [0] * 16
    for k, v in enumerate(args):
        R[ARG0 + k] = int(v) & 0xFFFFFFFF
    return R


def _fit_imem(cfg: Config, programs) -> None:
    """The board's loader takes at most IMEM's instructions (IMEM_WORDS / 8): a longer program
    cannot run on a device of this configuration."""
    for sid, p in enumerate(programs):
        if len(p) > cfg.IMEM_WORDS // 8:
            raise SimError(f"slice {sid}: a program of {len(p)} instructions, IMEM holds "
                           f"{cfg.IMEM_WORDS // 8} (IMEM_WORDS {cfg.IMEM_WORDS})")


class Machine:
    """args: the run's arguments (up to 8 words): R8..R15 start with them (0 without)."""

    def __init__(self, cfg: Config, programs: list[list[I.Instr]], drams: list[np.ndarray | None],
                 args=None):
        assert len(programs) == cfg.S and len(drams) == cfg.S
        _fit_imem(cfg, programs)
        self.cfg = cfg
        self.slices = [Slice(cfg, s, programs[s], drams[s]) for s in range(cfg.S)]
        self.args = args
        self.chains = 0                  # HALT CHAIN restarts so far
        self.host = None                 # WAITW's host: host(machine) when every slice waits
        for s in self.slices:
            s.R = _regs(args)

    def load(self, programs: list[list[I.Instr]], args=None) -> "Machine":
        """Start new programs on the same machine: DRAM, TMEM and ACT RAM are kept (as on the
        board, where the host writes a new program image between launches)."""
        assert len(programs) == self.cfg.S
        _fit_imem(self.cfg, programs)
        self.args = args
        for s, p in zip(self.slices, programs):
            s.prog, s.R, s.pc, s.stack = p, _regs(args), 0, []
            s.halted, s.waiting, s.icount, s.chain = False, None, 0, None
            s.polling, s.stalls = None, 0
        return self

    def _chain(self, s: Slice) -> None:
        """HALT CHAIN (docs/isa.md): the board loads the next program from the slice's DRAM
        into IMEM and starts it with the run's arguments; TMEM, ACT RAM and DRAM are kept."""
        addr, n = s.chain
        if addr % self.cfg.D or not 0 < n <= self.cfg.IMEM_WORDS // 8:
            raise SimError(f"slice {s.sid}: HALT CHAIN to {addr:#x}, {n} instructions")
        words = s.m32[s._widx(addr + 4 * np.arange(8 * n))]
        s.prog = [I.Instr.decode(words[8 * k:8 * k + 8]) for k in range(n)]
        s.R, s.pc, s.stack, s.halted, s.waiting = _regs(self.args), 0, [], False, None
        s.chain, s.polling = None, None
        self.chains += 1

    def run(self, max_steps: int = 10_000_000) -> "Machine":
        steps = 0
        # OTPU_WAITS_CHECK=1: each program's wait counts (opentpu.waits, otpu_seq WAITC) checked
        # against this run (no effect on the result: the counts only order the units)
        chk = {} if os.environ.get("OTPU_WAITS_CHECK") else None
        while not all(s.halted for s in self.slices):
            progressed = False
            for s in self.slices:
                while not s.halted and s.waiting is None and s.polling is None:
                    if chk is not None:
                        self._waits_issue(chk, s)
                    s.step()
                    steps += 1
                    progressed = True
                    if steps > max_steps:
                        raise SimError("step limit exceeded")
                    if s.halted and s.chain is not None:
                        self._chain(s)
                        if chk is not None:
                            chk.pop(s.sid, None)
            live = [s for s in self.slices if not s.halted]
            if live and all(s.waiting is not None for s in live):
                if len(live) != len(self.slices):
                    raise SimError("collective with a halted slice")
                ops = {s.waiting.op for s in live}
                if len(ops) != 1:
                    raise SimError("slices disagree on the collective instruction")
                if ops == {I.GATHER}:
                    self._gather()
                for s in live:
                    s.waiting = None
                    s.advance()
                progressed = True
            polling = [s for s in self.slices if s.polling is not None]
            if polling and not progressed:
                # every slice that can run is waiting: the host (its WAITW hook) acts now, as
                # it would while the card polls; nothing to act on is the WAITW timeout
                if self.host is not None:
                    self.host(self)
                for s in polling:
                    if s.poll(s.polling):
                        s.polling = None
                        s.advance()
                        progressed = True
                if not progressed:
                    ins = polling[0].polling
                    raise SimError(f"slice {polling[0].sid}: WAITW at pc {polling[0].pc} "
                                   f"never holds ({ins}; host {self.host!r}): the timeout")
            if not progressed:
                raise SimError("deadlock")
        return self

    def _waits_issue(self, chk: dict, s: Slice) -> None:
        from . import waits as W
        c = chk.get(s.sid)
        if c is None or c.prog is not s.prog:
            c = chk[s.sid] = W.Checker(s.prog, W.wait_counts(s.prog, self.cfg.D, self.cfg.S),
                                       self.cfg.D, self.cfg.S)
        if 0 <= s.pc < len(s.prog) and s.prog[s.pc].op in W.UNIT:
            c.issue(s.pc, [s.reg(r) for r in range(16)])

    def _gather(self) -> None:
        sl = self.slices
        key = []                 # dst resolved: the RTL writes every slice at slice 0's
        for s in sl:
            w = s.waiting.w
            key.append(((s.reg(s.waiting.rb) + w[1]) & 0xFFFFFFFF, w[2], w[4], w[5]))
        if any(k != key[0] for k in key):
            raise SimError("GATHER: slices disagree on dst/rows/cols/drs/seg")
        vals = []
        for s in sl:
            w = s.waiting.w
            src = (s.reg(s.waiting.ra) + w[0]) & 0xFFFFFFFF
            dst = (s.reg(s.waiting.rb) + w[1]) & 0xFFFFFFFF
            rows, cols, srs, drs, seg = w[2] & 0xFFFF, w[2] >> 16, w[3], w[4], w[5]
            idx = src + np.arange(rows)[:, None] * srs + np.arange(cols)[None, :]
            didx = dst + np.arange(len(sl))[:, None, None] * seg + \
                np.arange(rows)[None, :, None] * drs + np.arange(cols)[None, None, :]
            if _overlap(idx, didx):
                raise SimError(f"slice {s.sid}: GATHER: the source and destination overlap")
            vals.append(s.tmem[s._tidx(idx)].copy())
        for s in sl:
            w = s.waiting.w
            dst = (s.reg(s.waiting.rb) + w[1]) & 0xFFFFFFFF
            rows, cols, drs, seg = w[2] & 0xFFFF, w[2] >> 16, w[4], w[5]
            for k, v in enumerate(vals):
                idx = dst + k * seg + np.arange(rows)[:, None] * drs + np.arange(cols)[None, :]
                s.tmem[s._tidx(idx)] = v
