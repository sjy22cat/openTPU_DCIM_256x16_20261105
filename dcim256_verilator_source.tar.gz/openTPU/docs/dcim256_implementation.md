# DCIM 256×16 实施记录

依据：`DCIM/adjust/DCIM_256x16_详细分析与改造方案.md`（2026-11-04）。

工程：`openTPU_256x16/openTPU`。日期：2026-11-05。

已实现独立的 D=256、MCOLS=16 系统及配套软件配置。新系统顶层为
[`otpu_dcim256_sys`](../rtl/top/otpu_dcim256_sys.sv)，配置入口为
[`dcim256.toml`](../targets/dcim256.toml)。原有 target 继续保留，使用新系统时须显式选择 `dcim256`。

## 1. 实现配置

| 部分 | 配置与实现 |
| --- | --- |
| MXU | 16列，每列256个INT8乘积；INT48累加，16路FP32后处理 |
| DCIM映射 | 32个PEX2、64个PE，共4096项乘法/有效推进拍；两个dot16合并为dot32，再接原有8组累加路径 |
| 列时序 | 同拍向16列广播权重；列号延迟与输出deskew置零，16列同步进入Result FIFO |
| chunk FIFO | 2048 bit × 1024；发读时预留，返回不受计算暂停影响 |
| Result FIFO | 1312 bit × 64，包含16个INT48、16个FP32激活scale和一个FP32权重scale |
| ACT | 16行 × 128 block × 256 B = 512 KiB；另有16 KiB scale |
| VPU | 一个逻辑VPU，4组完整16 lane，组内CL=16；四组处理连续行，单条指令按序汇合完成 |
| TMEM | 262144个FP32 word，即1 MiB；两池各512 KiB，每池64 bank × 2048 word |
| QUANT | 64 lane、16个在途行槽位；1024个64-FP32段的行缓冲，即256 KiB |
| QACT | 每拍最多64个INT8写ACT，一个256 B block需4拍 |
| QST | 每拍最多64个带真实地址的INT8；256个256 B写合并槽，64个数据bank，支持转置、byte mask和flush |
| DMA | 每拍64个FP32；256 B chunk、128个预留槽；LD/ST保留首尾掩码及WAITW |
| MC | 单2048 bit native端口；权重、DMA、scale、QST独立请求队列，独立读返回出口及写排空确认 |
| IMEM | 65536个32 bit word = 8192条指令 |

ACT原模块已支持该参数组合，通过顶层参数和64 lane写接口扩展，无需重写其RAM主体。
DMA的LD返回与ST返回复用单个缓冲写端口，避免将互斥的数据来源描述成多写RAM；
128槽数据缓冲采用异步读分布式RAM结构，容量32 KiB。
TMEM使用独立的 `otpu_tmem_wide.sv`，每个读端一份一致副本，所有写同步广播。
八份副本约需8 MiB物理数据存储，另计RAM粒度、元数据、ACT与各单元缓冲。
逻辑容量仍为1 MiB。

QST写合并器使用直接映射的256槽缓存，数据共64 KiB，以64个32 bit宽的单写同步读RAM保存，
byte使能记录另计8 KiB。先将256 B行号按每6 bit折叠异或，再以低8 bit选择槽位，
数据bank为`slot[5:0] XOR byte_offset[5:0]`。64 B对齐的连续输入、256 B跨步以及受测的
4096/16384 B跨步转置可每拍写64个字节。其他跨步、跨行bank冲突及缓存槽冲突由已接受向量的待写掩码
逐拍重放；槽冲突先按byte mask排出旧行，再接收新行数据，保持最后一次写入的语义。

## 2. 数据流与充分利用阵列的条件

MM的计算为 `[M,256×KB] × [256×KB,N]`。M=16时，一组256 B权重供给全部16列；
每列读取自身ACT行的256 B激活。每个推进拍执行16×256项乘法，稳态每KB个推进拍形成16个点积。
例如M=16、N=256、KB=1，矩阵为 `[16,256]×[256,256]`，有256个有效推进拍，输出 `[16,256]`。
KB=10时，相同N需2560个有效推进拍。流水填充、排出、指令依赖和外存停顿另计。

编译器针对N为64倍数的M=16/8/4，分别使用N+4/N+8/N+16行步长。
MXU排出路数按实际64 bank映射计算，最多16路；四组VPU分别携带真实16项地址。
尾块、切片、广播和其他形状通过bank冲突收集分拍完成，保持ISA结果。
每个TMEM分配64 word对齐，且不跨越512 KiB池边界。两池均可由所有执行单元访问，
没有固定的“MXU专用池”或“VPU专用池”；地址和生命周期决定使用者。

TMEM按bank轮转仲裁写请求，并记录已接受lane，避免暂停时重复写入。
同池同bank同拍只有一次写服务，VPU、MXU和DMA的三个写端不保证持续同时满速。
读端保留已收集的数据，并在整组接受后保持同步返回值；下一请求收集期间不会覆盖上组结果。
SEQ继续按真实读写依赖发射和完成，TMEM不按N自动推送VPU。

MC在权重FIFO低于128项时进入补充状态，达到384项退出；提示跨两级同步到内存时钟。
补充状态最多优先服务3次权重读，再为其他符合credit条件的来源提供一次轮转服务。
其他来源的轮转游标独立保留，避免连续权重授权重启游标导致QST或scale饥饿。
水位为当前默认值，应按新板的最坏服务间隔、返回延迟和KB行长度重新核算。

## 3. 系统接口及Vivado入口

`otpu_dcim256_sys`包含单slice、loader、sequencer、64 lane collective和异步MC适配器；
BAR执行同步，单slice GATHER仍执行TMEM视图间的数据搬运，最后一次写接受后才确认完成。
顶层不包含DDR/HBM控制器IP、PCIe及板级引脚。

| 信号 | 时钟域 | 约定 |
| --- | --- | --- |
| clk / mem_clk | 各自 | 核心与外存服务时钟，可异步 |
| sys_rst / mem_rst | 各自 | 高有效；同时复位两域，分别同步释放；运行中不得单独清除一端FIFO |
| run_rst | clk | 运行保持复位；先排空旧事务，再装载新程序 |
| ld_start / ld_addr / ld_n | clk | loader启动、DRAM byte地址、指令数；地址256 B对齐 |
| rinit[8] | clk | 运行参数R8…R15 |
| ld_busy / halted / error / icount | clk | 装载、停止、错误、指令计数 |
| n_valid / n_ready | mem_clk | 两者同拍有效时接受一笔native事务；反压期间请求保持 |
| n_write | mem_clk | 1为写、0为读 |
| n_line[23:0] | mem_clk | 256 B行地址，实际byte地址为n_line×256；总地址范围4 GiB |
| n_wdata[2047:0] | mem_clk | 256 B数据，最低字节对应最低地址 |
| n_byte_en[255:0] | mem_clk | 高有效byte写使能；对接采用低有效mask的IP时须取反 |
| n_rvalid / n_rdata[2047:0] | mem_clk | 所有已接受读按请求顺序返回，一拍最多一笔；无返回反压，适配器提前预留credit |
| n_wr_idle | mem_clk | 所有此前接受的写已对后续读可见；不能只表示控制器输入队列有空位 |

从本工程目录运行：

```powershell
$env:OTPU_TARGET='dcim256'
python -m opentpu.target show dcim256
vivado -mode batch -source tools/vivado_dcim256.tcl -tclargs <FPGA_PART> build/vivado_dcim256 project
```

最后参数使用 `rtl` 执行RTL展开，使用 `synth` 执行综合并输出checkpoint、资源、时序及CDC报告。
单模块可运行 `vivado -mode batch -source tools/vivado_dcim256_units.tcl -tclargs <FPGA_PART> <UNIT>`，
其中UNIT为mxu、vpu、quant、dma或qst，均使用本系统的参数规模。末尾追加`synth`执行单模块
独立综合，资源报告与checkpoint写入`build/vivado_units/<UNIT>/`。
`constraints/dcim256_core.xdc`默认核心133.333 MHz、native约300 MHz，含Gray指针时延/偏斜约束。
板级封装需给出真实时钟、同步复位、I/O约束及控制器接口；此处时钟是设计目标。
旧Kintex-7工程不会自动变成新板工程，不应直接沿用旧双通道控制器连接新系统。

133.333 MHz下，权重满速需34.13 GB/s；加QST为42.67 GB/s；再加DMA峰值为76.8 GB/s，
还未计scale及协议损耗。2048 bit位宽本身不保证上述持续带宽，native时钟及后端存储必须共同满足需求。

## 4. 验证与复现

Linux服务器的Verilator入口、传输包和运行顺序见
[服务器功能验证](dcim256_verilator.md)。该入口已准备，尚未取得Verilator实际运行结果。
下表保留生产RTL此前的回归结果。本次为服务器移植修改了两个测试平台的FP32参考转换及
数值测试的向量路径，相关测试平台已通过语法编译，参考转换的37232项对照检查通过；
修改后的完整系统测试仍需重跑，生产RTL未因服务器移植而改变。

使用本机Vivado/XSim 2019.2。`tools/check_dcim256.py`在build中生成兼容仿真副本，
将原有initial初始化与always_ff混用改为普通always；源RTL保持不变。
通用RAM的STYLE使用无类型字符串参数，兼容Vivado 2019.2的综合前端。
每个测试必须输出 `DCIM256_TEST_PASS`，避免仅依赖XSim进程退出码。
每次构建生成 `build/<测试顶层>/sources.json`，记录RTL与测试平台的SHA256。
`--run-only`仅复用源码指纹仍匹配的仿真快照；缺少记录或源码已变更时要求重新构建。

```powershell
python -X utf8 tools/check_dcim256.py --top tb_dcim256_sys
python -X utf8 tools/gen_dcim256_vectors.py
python -X utf8 tools/check_dcim256.py --top tb_dcim256_vectors
python -X utf8 tools/check_dcim256.py --top tb_dcim256_control
python -X utf8 tools/check_dcim256.py --top tb_tmem_wide
python -X utf8 tools/check_dcim256.py --top tb_dma_wide
python -X utf8 tools/check_dcim256.py --top tb_mc2048
python -X utf8 tools/check_dcim256.py --top tb_qst_collect
python -X utf8 tools/check_dcim256_model.py
python -X utf8 tools/audit_dcim256_qwen3.py
```

| 验证 | 已取得的结果与覆盖 |
| --- | --- |
| 完整系统MM | 通过，共16554拍；KB=1/2/10/16、M16、N256，分别逐元素检查4096 FP32与4096 INT8；包含loader、DMA、QACT、ACT、MXU、VPU、TMEM、QST和异步MC |
| 数值综合 | 通过，共24289拍；393条ISA指令、4 MiB DRAM逐word匹配参考模拟器；含全部VPU函数、四类广播、7行尾块、归约、OUTER、不同组数指令在途、MM ACC/RMAX/ASCALE、QACT预缩放、QST ROW/HALF/transpose |
| 控制指令 | 通过，共261拍；跨池GATHER及尾段、BAR、RLD数值转换与RAW×MUL、HALT CHAIN重装载，验证数据搬运及指令完成计数 |
| TMEM | 双池、读冲突收集、写公平性、连续请求与返回保持、副本一致性 |
| DMA | 非对齐首尾mask、队列回绕、跨池、返回与TMEM反压解耦、WAITW条件/轮询/超时 |
| MC | 异步400事务，权重/DMA/scale/QST并发，返回路由、scale subline、写排空、反压保持、低水位有界公平服务 |
| QST collector | 连续及转置分散地址、非对齐、byte mask、bank及槽冲突重放、重复字节写、commit暂停与flush；222笔外存事务通过，4096/16384 B跨步连续16拍接收64 B/拍 |
| 软件回归 | compiler与量化scale依赖测试共34项通过 |
| 小型模型 | 随机Qwen3结构，16 token prefill后decode；head128物理补齐256，logits与FP32参考余弦相似度0.99968815；属于ISA执行 |
| QST RTL展开 | Vivado 2019.2通过，未发现RTL错误或多驱动；检查器件为xc7k325tffg900-2，仅用于RTL工具检查 |
| DMA RTL展开 | 修复数据缓冲的多写描述后通过，未发现RTL错误或多驱动；DMA专项仿真复测通过 |
| VPU及QUANT RTL展开 | 4×16 lane完整VPU、64 lane/NB16 QUANT均通过，未发现RTL错误或多驱动 |
| MXU RTL展开 | D256/M16、16路后处理、1024项权重FIFO通过，未发现RTL错误或多驱动 |
| DMA独立综合 | Vivado 2019.2通过；25952 LUT、816寄存器，其中5636 LUT用于分布式RAM；未做布局布线 |
| QST独立综合 | 未完成；串行检查完成前端处理后，器件映射持续约十分钟仍未结束，已保留日志；不据此认定资源映射通过 |
| 完整系统RTL展开 | 未完成；并行运行时Windows报告虚拟内存不足，已停止该检查，不能替代全系统综合结论 |

完整系统中观察到KB=1/2/10/16分别连续推进256/512/2560/4096拍，最大相邻推进间隔均为1。
这说明受测供数条件下计算阶段没有气泡；不代表完整模型、真实外存和所有依赖阶段都达到100%利用率。
XSim日志位于 `build/<测试顶层>/xsim.log`。Vivado综合/布局布线与真实板运行结果单独记录。
本次验证汇总保存在 `build/dcim256_validation.json`，包含测试结论、日志校验值和数值向量校验值；
`build/dcim256_source_manifest.json`记录本次RTL及测试平台的源码校验值。
QST模块展开日志为 `build/check_qst_rtl.log`；DMA综合报告为`build/dma_synth_utilization.rpt`。
RTL展开不验证块RAM实际映射、资源是否能容纳或目标频率；
这些结论须由选定器件的综合及布局布线报告给出。
本机并行执行系统展开、QST综合与XSim重新编译时触发Windows事件2004，造成两个工具任务中断。
较大的Vivado检查应串行执行，并预留足够物理内存及提交空间；这项主机限制与目标FPGA资源是两回事。

## 5. Qwen3-4B容量与吞吐核算

`tools/audit_dcim256_qwen3.py`使用实际target、编译器、N+4等布局和双池分配规则，
核算hidden2560、FFN9728、32个Q head、8个KV head、head128的单层16 token块。
attention块256、流水深度3；不加载checkpoint，不执行该4B层的RTL仿真。

| pos | attention暂存 | TMEM活跃峰值 | 两池各自峰值 | ACT block峰值/行 | 静态指令 |
| ---: | --- | ---: | --- | ---: | ---: |
| 256 | DRAM scratch | 424.9375 KiB | 406 / 256 KiB | 48 | 2224 |
| 4096、16384 | DRAM scratch | 488.1875 KiB | 464.3125 / 318.125 KiB | 48 | 4498 |
| 4096、16384 | TMEM | 712.1875 KiB | 453.75 / 493.5 KiB | 48 | 4369 |

每个分配不跨池，全部配置均在8192条指令内。各池峰值可能发生在不同时间，不能简单相加。
KB≤16是模型分块选择；ACT每行物理128 block，不应将16写成统一硬件上限。
完整attention score逐上下文块处理，因此上下文增长不直接增加TMEM峰值。

pos4096、DRAM scratch路径的理想工作量为595264个MXU推进拍、102334个VPU发射拍，
QACT首次扫描41600个64项段，DMA LD/ST分别3188/1024个256 B chunk。
VPU总发射量低于MXU推进量，但归约尾部、函数流水及数据依赖仍产生局部等待。
已实现的握手和分配避免因覆盖/溢出导致错误，无法据此宣称完整Qwen3-4B无性能阻塞。

完整36层模型还受4 GiB外存地址范围限制，不能由TMEM扩容解决：

| embedding | KV cap | 完整image | 4 GiB范围 |
| --- | ---: | ---: | --- |
| FP32 | 256 | 5405.36 MiB | 超出 |
| FP32 | 4096 | 5970.72 MiB | 超出 |
| INT8，共享tied head | 256 | 3927.66 MiB | 可容纳image，额外运行区还需另核算 |
| INT8，共享tied head | 4096 | 4493.02 MiB | 超出 |

上述仅为布局测量，未分配完整数组。长上下文全模型需另行采用分层装载、更多slice分片，
或统一扩展ISA及全部外存地址路径；当前未把32 bit地址静默扩为8 GiB。
小批decode的M=1与QK中128项补零仍有固有空闲，不能算作4096项有效MAC全占用。

## 6. 主要文件

| 文件 | 职责 |
| --- | --- |
| rtl/dcim/、rtl/mxu/otpu_mxu.sv | PE映射、同步后处理、FIFO与64 bank排出 |
| rtl/top/otpu_slice.sv、otpu_dcim256_sys.sv | 单元配置、真实地址路由、loader及独立MC连接 |
| rtl/vpu/otpu_vpu_grouped.sv | 4×16完整VPU、分行、在途完成汇合 |
| rtl/mem/otpu_tmem_wide.sv | 双池、读副本、冲突分拍、写授权和读返回保持 |
| rtl/vpu/otpu_quant.sv、rtl/mem/otpu_qst_collect.sv | 64 lane量化、16行槽、宽QST合并 |
| rtl/dma/otpu_dma_wide.sv、rtl/mem/otpu_mc2048.sv | 256 B DMA、异步请求返回、credit与公平仲裁 |
| opentpu/compiler.py、language.py、llm/qwen3.py | bank布局、双池分配、head补齐及KV描述符 |
| targets/dcim256.toml、tools/vivado_dcim256.tcl | 软件配置与通用Vivado工程 |

新板的控制器IP、引脚、主机装载/状态寄存器封装、综合资源与时序收敛、完整checkpoint推理和板级持续带宽尚未验证。
原八lane STREAM/DSTEP专用运行模式在该target关闭，普通MM/VOP/QACT/QST/LD/ST保持既有指令调度方式。
