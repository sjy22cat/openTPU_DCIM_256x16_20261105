"""Package current working files, including uncommitted DCIM additions, for Linux.

python tools/package_dcim256.py
Build products, checkpoints, model weights, and Git metadata are excluded.
"""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import io
import json
import tarfile

ROOT = Path(__file__).resolve().parents[1]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=ROOT / "build/dcim256_verilator_source.tar.gz")
    args = parser.parse_args()
    files = set()
    for directory in ("rtl", "opentpu", "targets", "constraints", "sim/dcim256"):
        for p in (ROOT / directory).rglob("*"):
            if p.is_file() and not p.is_symlink() and "__pycache__" not in p.parts and p.suffix != ".pyc":
                files.add(p)
    for name in ("LICENSE", "README.md", "pyproject.toml", "docs/dcim256_implementation.md",
                 "docs/dcim256_verilator.md", "tests/test_compiler.py", "tests/test_waits.py",
                 "tools/check_dcim256_verilator.py", "tools/check_dcim256.py",
                 "tools/gen_dcim256_vectors.py", "tools/check_dcim256_model.py",
                 "tools/audit_dcim256_qwen3.py", "tools/package_dcim256.py",
                 "tools/vivado_dcim256.tcl", "tools/vivado_dcim256_units.tcl"):
        p = ROOT / name
        if not p.is_file():
            raise SystemExit(f"Missing required source: {p}")
        files.add(p)
    content = {p.relative_to(ROOT).as_posix(): p.read_bytes() for p in sorted(files)}
    fingerprint = {name: hashlib.sha256(data).hexdigest() for name, data in content.items()}
    manifest = json.dumps(dict(generated=datetime.now(timezone.utc).isoformat(),
                               source_sha256=fingerprint, verilator_run="not run locally"),
                          indent=2).encode("utf-8") + b"\n"
    content["SOURCE_MANIFEST.json"] = manifest
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with tarfile.open(args.output, "w:gz") as archive:
        for name, data in content.items():
            info = tarfile.TarInfo("openTPU/" + name)
            info.size = len(data)
            info.mode = 0o644
            archive.addfile(info, io.BytesIO(data))
    with tarfile.open(args.output, "r:gz") as archive:
        for name, digest in fingerprint.items():
            assert hashlib.sha256(archive.extractfile("openTPU/" + name).read()).hexdigest() == digest, name
    digest = hashlib.sha256(args.output.read_bytes()).hexdigest()
    args.output.with_name(args.output.name + ".sha256").write_text(
        f"{digest}  {args.output.name}\n", encoding="utf-8")
    print(f"Package: {args.output}\nFiles: {len(content)}\nBytes: {args.output.stat().st_size}\nSHA256: {digest}")


if __name__ == "__main__":
    main()
