"""Deterministic ISA oracle for the complete asynchronous DCIM256 system test."""
from pathlib import Path
import sys
import argparse
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from opentpu import isa as I, quant as Q
from opentpu.isasim import Machine
from opentpu.target import config


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--case',choices=('all','max','rdot'),default='all')
    args=parser.parse_args()
    (ROOT/'build/dcim256_vectors').mkdir(parents=True,exist_ok=True)
    cfg=config('dcim256',DRAM_BYTES=4<<20)
    dram=np.zeros(cfg.DRAM_BYTES,np.uint8)
    rng=np.random.default_rng(25616)
    prog=[]
    cursor=0x1000
    def put(a):
        nonlocal cursor
        a=np.ascontiguousarray(a);at=cursor
        data=a.view(np.uint8).reshape(-1);dram[at:at+len(data)]=data
        cursor=(at+len(data)+255)&~255
        return at
    def ld(a,at):
        prog.append(I.ld(put(a),at,np.asarray(a).size))
    def store_rows(at,rows,cols,rs):
        nonlocal cursor
        for r in range(rows):
            dest=cursor;cursor=(cursor+4*cols+255)&~255
            prog.append(I.st(dest,at+r*rs,cols))
    # VPU all arithmetic functions, all broadcasts, four-group tails and reductions.
    rows,cols,rs=7,19,23
    a=rng.uniform(.25,2,(rows,rs)).astype(np.float32)
    b=rng.uniform(.5,1.5,(rows,rs)).astype(np.float32)
    ld(a,0);ld(b,4096)
    for mode in (I.B_FULL,I.B_ROW,I.B_COL,I.B_SCALAR):
        for func in (I.V_ADD,I.V_MUL,I.V_EXP2SUB):
            prog.append(I.vop(func,8192,0,4096,rows,cols,rs,rs,rs,mode,imm=.75))
            store_rows(8192,rows,cols,rs)
    for func in (I.V_SUB,I.V_RSUB,I.V_MAX,I.V_MIN,I.V_COPY,I.V_EXP2,I.V_RECIP,I.V_RSQRT,I.V_ABS,I.V_FILL,I.V_LOG2):
        prog.append(I.vop(func,8192,0,4096,rows,cols,rs,rs,rs))
        store_rows(8192,rows,cols,rs)
    for func in (I.V_RSUM,I.V_RMAX,I.V_RSSQ,I.V_RDOT,I.V_ARGMAX):
        prog.append(I.vop(func,8192,0,4096,rows,cols,2,rs,rs))
        store_rows(8192,rows,2 if func==I.V_ARGMAX else 1,2)
    ld(np.ones((7,23),np.float32),8192)
    for mode in ('one','scalar','column'):
        prog.append(I.outer(8192,4096,0,4096+rs,rows,cols,rs,rs,mode))
        store_rows(8192,rows,cols,rs)
    # Short independent VOPs remain in flight together and retire in command order.
    for j,rr in enumerate((16,1,7,4,8,3,16)):
        prog.append(I.vop(I.V_EXP2,12000+j*2048,0,0,rr,8,8,0,0))
    for j,rr in enumerate((16,1,7,4,8,3,16)):
        store_rows(12000+j*2048,rr,8,8)
    # Dense RDOT row-buffer flush and sparse active groups retain the ISA mode.
    for rr in (1,4,8,16):
        prog.append(I.vop(I.V_RDOT,28000,0,4096,rr,19,1,0,0))
        store_rows(28000,rr,1,1)
    # D256 MM with actual packed scales, varying activation subgroup magnitudes.
    M,N,KB=16,64,2
    x=(rng.standard_normal((M,KB*256))*np.exp(rng.uniform(-3,3,(M,8,1))).repeat(64,axis=2).reshape(M,KB*256)).astype(np.float32)
    w=rng.integers(-128,128,(N,KB*256),dtype=np.int16).astype(np.float32)
    ld(x,0)
    # Use the same supported public packer as the runtime weight builder.
    data= w.astype(np.int8).view(np.uint8)
    wa=put(data)
    sr=np.zeros((N,8),np.uint8)
    sr[:,:4]=np.full((N,1),.75,np.float32).view(np.uint8)
    sr[:,4:6]=rng.integers(0,5,(N,2),dtype=np.uint8)
    sa=put(sr)
    alpha=rng.uniform(.25,1.5,M).astype(np.float32);ld(alpha,60000)
    prog.append(I.qact(0,M,0,KB,KB*256))
    mm=dict(sa=wa,ssa=sa,n=N,kb=KB,rs=KB*256,ors=68,m=M,srs=8,ab=0)
    prog.append(I.mm(out=65536,rmax=True,**mm))
    prog.append(I.mm(out=65536,acc=True,rmax=True,**mm))
    prog.append(I.mm(out=65536,acc=True,unit=True,ascale=60000,**mm))
    store_rows(65536,M,N,68);store_rows(65536+M*68,1,M,M)
    # QACT prescale and QST ROW/HALF, per-block offsets and transpose.
    cs=rng.uniform(.5,1.5,512).astype(np.float32);rr=rng.uniform(.5,1.5,16).astype(np.float32)
    ld(cs,61000);ld(rr,62000)
    prog.append(I.qact(0,16,4,2,512,cscale=61000,rscale=62000))
    prog.append(I.mm(out=70000,unit=True,**dict(mm,ab=4)))
    store_rows(70000,16,64,68)
    for row,half,step in ((False,False,1),(True,True,1),(True,False,256)):
        dest=0x180003 if step==1 else 0x1c0003
        drs=515 if step==1 else 1
        prog.append(I.qst(0,dest,0x230000,16,2,512,drs,step,row=row,half=half))
    prog.append(I.halt())
    if args.case=='max':
        prog=prog[:2]+[I.vop(I.V_MAX,8192,0,4096,rows,cols,rs,rs,rs)]
        store_rows(8192,rows,cols,rs)
        prog.append(I.halt())
    if args.case=='rdot':
        prog=prog[:2]
        for rr in (1,4,8,16):
            prog.append(I.vop(I.V_RDOT,28000,0,4096,rr,19,1,0,0))
            store_rows(28000,rr,1,1)
        prog.append(I.halt())
    words=I.assemble(prog)
    (ROOT/'build/dcim256_vectors/program.txt').write_text('\n'.join(f'{i}: {ins}' for i,ins in enumerate(prog)))
    dram[0x300000:0x300000+words.nbytes]=words.view(np.uint8)
    expected=Machine(cfg,[prog],[dram.copy()]).run().slices[0].dram
    out=ROOT/'build/dcim256_vectors';out.mkdir(parents=True,exist_ok=True)
    for name,mem in (('input',dram),('expected',expected)):
        np.savetxt(out/(name+'.hex'),mem.view(np.uint32),fmt='%08x')
    (out/'params.hex').write_text(f'{len(prog):08x}\n00000000\n')
    print(f'Generated {len(prog)} instructions, {cursor} data bytes; ISA reference complete.')

if __name__=='__main__':main()
