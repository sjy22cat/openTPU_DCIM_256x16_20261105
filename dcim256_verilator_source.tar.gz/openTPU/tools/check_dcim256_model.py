"""Small deterministic Qwen3-shaped ISA run with real 128 -> physical 256 KV.

No checkpoint, network, torch or FPGA is required. This checks compiler/image
integration and head padding; it is separate from the XSim hardware regressions.
"""
import os
os.environ.setdefault('OTPU_QUANT_WORKERS','1')
from pathlib import Path
import sys
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from opentpu.target import config
from opentpu.llm.qwen3 import Engine,Spec,reference_logits


def main():
    spec=Spec(256,1,4,2,128,512,256)
    rng=np.random.default_rng(25616)
    weights={}
    def put(name,shape,norm=False):
        weights[name]=(1+.03*rng.standard_normal(shape) if norm else
                       .02*rng.standard_normal(shape)).astype(np.float32)
    put('model.embed_tokens.weight',(256,256))
    put('model.norm.weight',(256,),True)
    p='model.layers.0.'
    for name in ('input_layernorm.weight','post_attention_layernorm.weight'):
        put(p+name,(256,),True)
    for name in ('q_norm.weight','k_norm.weight'):
        put(p+'self_attn.'+name,(128,),True)
    for name,shape in (('q_proj',(512,256)),('k_proj',(256,256)),
                       ('v_proj',(256,256)),('o_proj',(256,512))):
        put(p+'self_attn.'+name+'.weight',shape)
    for name,shape in (('gate_proj',(512,256)),('up_proj',(512,256)),('down_proj',(256,512))):
        put(p+'mlp.'+name+'.weight',shape)
    cfg=config('dcim256',DRAM_BYTES=32<<20)
    engine=Engine(spec,weights,cap=256,cfg=cfg,rows=16,prog_cache=False)
    tokens=[3,7,11,2,19,5,21,9,13,4,20,8,15,6,17,1]
    result=engine.prefill(tokens,chunk=16)
    actual=engine.step(23)
    expected=reference_logits(spec,weights,tokens+[23])[-1]
    cosine=float(np.dot(actual,expected)/(np.linalg.norm(actual)*np.linalg.norm(expected)))
    assert np.isfinite(result).all() and np.isfinite(actual).all()
    assert cosine>.995,cosine
    kv=engine.image.descriptors(0).layer(0).kv
    assert kv.d==256 and kv.dv==128,(kv.d,kv.dv)
    print(f'DCIM256_MODEL_PASS 16-token prefill + decode; logits cosine={cosine:.8f}')


if __name__=='__main__':main()
