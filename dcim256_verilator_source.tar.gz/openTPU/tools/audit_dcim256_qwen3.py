"""Qwen3-4B / D256 M16 design sizing, using the repository's existing tiled kernels.

This is an allocation and instruction-work audit, not an RTL timing simulation.
No model checkpoint is loaded. Padded KV descriptors model the required D256 port.
Uses the target compiler and allocator without replacing their placement policy.

Run from any directory:
  python -X utf8 tools/audit_dcim256_qwen3.py
"""
from __future__ import annotations

import argparse
from collections import Counter
from dataclasses import replace
import gc
import json
from pathlib import Path
import sys
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from opentpu import isa as I, language as ol
from opentpu.compiler import Builder, CompileError, KVDesc, QTensor, Tensor
from opentpu.isasim import Config
from opentpu.kernels.mlp import _chunk
from opentpu.llm.qwen3 import Spec
from opentpu.llm.tiled import Res, _attention_tile, _mlp_tile, mlp_parts, mlp_sub

SPEC = Spec(hidden=2560, layers=1, n_q=32, n_kv=8, head_dim=128,
            ffn=9728, vocab=151936)
D, T, H, F = 256, 16, 2560, 9728
CHUNK = _chunk(F, D)


def layer_descriptors(cap):
    """Distinct synthetic DRAM addresses; no host arrays or checkpoint allocation."""
    lw = SimpleNamespace(
        g_in=Tensor(0x1000, (H,), (1,)), g_post=Tensor(0x4000, (H,), (1,)),
        qn=Tensor(0x7000, (128,), (1,)), kn=Tensor(0x8000, (128,), (1,)),
    )
    shapes = [('wq', 4096, H), ('wk', 1024, H), ('wv', 1024, H),
              ('wo', H, 4096), ('wg', F, H), ('wu', F, H)]
    for i, (name, n, k) in enumerate(shapes):
        setattr(lw, name, QTensor.weight(
            0x1000000 + i * 0x3000000, 0x20000000 + i * 0x100000,
            n, k, 'int8', D))
    parts = tuple(QTensor.weight(
        0x30000000 + i * 0x200000, 0x40000000 + i * 0x10000, H, CHUNK, 'int8', D)
        for i in range(F // CHUNK))
    lw.wd = QTensor(parts[0].data, parts[0].scale, (H, F),
                    parts[0].rs, parts[0].srs, D, parts=parts, pw=CHUNK, wf=I.W8)
    heads = {}
    for j in range(8):
        a = 0x50000000 + j * 0x1000000
        heads[j] = dict(k=a, ks=a + 0x800000, vt=a + 0x900000, vs=a + 0xf00000)
    lw.kvs = [KVDesc(heads, cap, D, D, 1, 0, dv=128)]
    return lw


@ol.jit
def layer_probe(pos, cap, external_oscr=True):
    lw = layer_descriptors(cap)
    x = ol.empty([T, H])
    res = Res(x)
    del x
    parts = mlp_parts(H, D, T, ol.tmem_words())
    sub = mlp_sub(CHUNK, D, T, ol.tmem_words())
    c, s = ol.empty([T, 64]), ol.empty([T, 64])
    _attention_tile(
        res, lw, c, s, pos, T, SPEC, 256, parts, depth=3, whole=True,
        oscr=Tensor(0x70000000, (T, 4096), (4096, 1)) if external_oscr else None,
    )
    del c, s
    _mlp_tile(res.x, lw, SPEC, parts, sub)


def phase(ins):
    names = {fn for _, _, fn in ins.src}
    if '_mlp_tile' in names:
        return 'mlp'
    if any(fn == 'part' and Path(path).name == 'tiled.py'
           for path, _, fn in ins.src):
        return 'qkv_projection'
    if names & {'scores', 'finish', 'prime', '_attend_heads'}:
        return 'attention_core'
    return 'attention_projection'


def dynamic_instructions(prog, lo=0, hi=None, multiplier=1):
    """Count constant hardware loops without materializing the full dynamic program."""
    i, hi = lo, len(prog) if hi is None else hi
    while i < hi:
        ins = prog[i]
        if ins.op == I.LOOP:
            if ins.ra:
                raise ValueError('This audit needs constant loop trip counts.')
            end = i + 1 + ins.w[0]
            if end > hi:
                raise ValueError('Invalid loop body.')
            yield from dynamic_instructions(prog, i + 1, end, multiplier * ins.w[1])
            i = end
        else:
            yield ins, multiplier
            i += 1


def grouped_issue_cycles(rows, cols, reduction=False):
    # Four identical 16-lane groups; each row belongs to one group.
    # Reductions preserve the ISA's 64 partials and padding.
    if reduction:
        cols = (cols + 63) // 64 * 64
    return (rows + 3) // 4 * ((cols + 15) // 16)


def bank_examples():
    out = []
    for n in (128, 256, 512, 1280):
        for stride in (n, n + 1, n + 4):
            banks = [(r * stride) % 64 for r in range(16)]
            vpu = [((g * 4) * stride + l) % 64 for g in range(4) for l in range(16)]
            out.append(dict(cols=n, row_stride=stride,
                            mxu_distinct_banks=len(set(banks)),
                            vpu_distinct_banks=len(set(vpu))))
    return out


def grouped_layout_examples():
    """Address-level check of four equal row groups, not an RTL port simulation."""
    out = []
    for rows in (4, 8, 16):
        per_group = rows // 4
        padding = 16 // per_group
        for cols in (128, 256, 512, 1280):
            stride = cols + padding
            # Check every common phase of the four groups; bases and column starts rotate banks.
            vpu = min(len({((g * per_group + q) * stride + l) % 64
                           for g in range(4) for l in range(16)})
                      for q in range(per_group))
            mxu = len({r * stride % 64 for r in range(rows)})
            assert vpu == 64 and mxu == rows, (rows, cols, stride, mxu, vpu)
            out.append(dict(rows=rows, cols=cols, rows_per_group=per_group,
                            row_stride=stride, mxu_distinct_banks=mxu,
                            vpu_distinct_banks=vpu))
    return out


def work(prog):
    phases, histogram = {}, Counter()
    for ins, count in dynamic_instructions(prog):
        if ins.op in (I.LI, I.ADDI, I.NOP, I.HALT):
            continue
        p = phases.setdefault(phase(ins), Counter())
        p['dynamic_instructions'] += count
        w = ins.w
        if ins.op == I.MM:
            n, kb, m = w[3] & 65535, (w[3] >> 16) & 255, (w[5] >> 16) & 255
            p['mxu_advance_cycles'] += count * n * kb * ((m + 15) // 16)
            p['mxu_port_b_chunks'] += count * n * kb
            histogram[(phase(ins), m, n, kb)] += count
        elif ins.op == I.VOP:
            rows, cols, func = w[3] & 65535, w[3] >> 16, (w[5] >> 16) & 255
            p['vpu_issue_cycles_4x16'] += count * grouped_issue_cycles(
                rows, cols, func in I.REDUCE and func != I.V_RMAX and func != I.V_ARGMAX)
            if func in I.REDUCE:
                p['vpu_reduction_instructions'] += count
            p['vpu_instructions'] += count
        elif ins.op == I.QACT:
            rows, kb = w[1] & 255, w[1] >> 16
            p['qact_pass0_read_chunks64'] += count * rows * kb * D // 64
            p['qact_pass1_chunks64'] += count * rows * kb * D // 64
            p['qact_instructions'] += count
        elif ins.op == I.QST:
            rows, kb = w[3] & 65535, w[3] >> 16
            elements = rows * kb * D
            written = elements // 2 if ins.flags & I.F_HALF else elements
            step, drs = w[6], w[5]
            contiguous = step == 1 and (w[1] & 3) == 0 and drs % 4 == 0
            p['qst_old_data_write_cycles'] += count * written // (4 if contiguous else 1)
            p['qst_payload_bytes'] += count * written
        elif ins.op in (I.LD, I.ST):
            n = w[2]
            # Current descriptors and loop steps preserve the chunk-offset low bits.
            chunks = ((w[0] // 4) % 64 + n + 63) // 64
            key = 'dma_ld' if ins.op == I.LD else 'dma_st'
            p[key + '_payload_bytes'] += count * n * 4
            p[key + '_port_b_chunks'] += count * chunks
            p[key + '_instructions'] += count
    return dict(
        phases={k: dict(v) for k, v in phases.items()},
        mm_histogram=[dict(phase=k[0], m=k[1], n=k[2], kb=k[3], count=v)
                      for k, v in sorted(histogram.items())],
    )


def main():
    from opentpu.target import config
    cfg=config('dcim256')
    SPEC.check(cfg)
    original_alloc, original_act = Builder.alloc, Builder.act_alloc
    def track_alloc(self,*a,**kw):
        tile=original_alloc(self,*a,**kw)
        half=cfg.TMEM_WORDS//2
        sums=[sum(hi-lo for lo,hi,ref in self.tmem_regions if ref() is not None and lo//half==p) for p in (0,1)]
        self.audit_pool_peaks=[max(a,b) for a,b in zip(getattr(self,'audit_pool_peaks',[0,0]),sums)]
        assert all(lo//half==(hi-1)//half for lo,hi,ref in self.tmem_regions if ref() is not None)
        assert tile.base%64==0
        return tile
    def track_act(self,kb):
        live=sum(ref is not None and ref() is not None for ref in self.act_live)
        result=original_act(self,kb)
        self.audit_act_peak=max(getattr(self,'audit_act_peak',0),live+kb)
        return result
    Builder.alloc,Builder.act_alloc=track_alloc,track_act
    result=dict(kind='actual_compiler_allocation_and_ideal_work',target='dcim256',runs=[],grouped_layout_examples=grouped_layout_examples())
    try:
        for pos in (256,4096,16384):
            for external in (True,False):
                rec=dict(pos=pos,external_oscr=external)
                try:
                    b=layer_probe.trace(cfg,0,dict(pos=pos,cap=((pos+T+255)//256)*256,external_oscr=external))
                    prog=b.finish()
                    rec.update(peak_live_kib=b.tmem_peak/256,pool_peak_live_kib=[x/256 for x in b.audit_pool_peaks],
                        peak_act_blocks=b.audit_act_peak,static_instructions=len(prog),instruction_capacity=cfg.IMEM_WORDS//8,**work(prog))
                    assert len(prog)<=cfg.IMEM_WORDS//8
                except Exception as exc:
                    rec['error']=f'{type(exc).__name__}: {exc}'
                result['runs'].append(rec)
    finally:
        Builder.alloc,Builder.act_alloc=original_alloc,original_act
    # Size the full 36-layer image without allocating the DRAM array. Probe
    # wider software addresses solely to measure the overflow beyond RTL 4 GiB.
    result['full_model_images']=[]
    for embed in ('f32','int8'):
        for cap in (256,4096):
            full=replace(SPEC,layers=36,embed=embed)
            image=full.image(replace(cfg,DRAM_BYTES=1<<40),cap,rows=16,lookup=True)
            result['full_model_images'].append(dict(layers=36,embed=embed,cap=cap,
                image_mib=image.nbytes/2**20,fits_rtl_4gib=image.nbytes<=cfg.DRAM_BYTES))
    out=ROOT/'build/dcim256_qwen3_4b_audit.json'
    out.parent.mkdir(parents=True,exist_ok=True)
    out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps([{k:v for k,v in r.items() if k not in ('phases','mm_histogram')} for r in result['runs']],ensure_ascii=False,indent=2))
    print(json.dumps(result['full_model_images'],indent=2))
    if any('error' in r for r in result['runs']):raise SystemExit(1)

if __name__=='__main__':main()
