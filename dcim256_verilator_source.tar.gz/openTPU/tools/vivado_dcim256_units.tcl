# Check one production-sized unit without expanding the entire system.
# vivado -mode batch -source tools/vivado_dcim256_units.tcl -tclargs PART UNIT ?rtl|synth?
set root [file normalize [file join [file dirname [info script]] ..]]
if {[llength $argv]<2 || [llength $argv]>3} {error "Usage: vivado_dcim256_units.tcl PART mxu|vpu|quant|dma|qst ?rtl|synth?"}
set part [lindex $argv 0]
set unit [lindex $argv 1]
set mode [expr {[llength $argv]>2 ? [lindex $argv 2] : "rtl"}]
if {$unit ni {mxu vpu quant dma qst}} {error "Unknown unit: $unit"}
if {$mode ni {rtl synth}} {error "Unknown mode: $mode"}
set python [expr {[info exists ::env(OTPU_PYTHON)] ? $::env(OTPU_PYTHON) : "python"}]
cd $root
set listing [exec $python -E -m opentpu.target files dcim256]
foreach relative [split $listing "\n"] {
  set relative [string trim $relative]
  if {$relative ne ""} {read_verilog -sv [file join $root $relative]}
}
set options [list -part $part]
if {$mode eq "rtl"} {lappend options -rtl} else {lappend options -mode out_of_context}
switch $unit {
  mxu {
    lappend options -top otpu_mxu \
      -generic D=256 -generic MCOLS=16 -generic ROWS=16 -generic DEPTH=1024 \
      -generic LANES=16 -generic TLANES=64 -generic IMPL=4 -generic E=16
  }
  vpu {lappend options -top otpu_vpu_grouped}
  quant {
    lappend options -top otpu_quant -generic D=256 \
      -generic LANES=64 -generic TLANES=64 -generic NB=16 -generic WIDE_QST=1
  }
  dma {lappend options -top otpu_dma_wide}
  qst {lappend options -top otpu_qst_collect}
}
synth_design {*}$options
if {$mode eq "synth"} {
  set out [file join $root build vivado_units $unit]
  file mkdir $out
  report_utilization -file [file join $out utilization.rpt]
  write_checkpoint -force [file join $out synthesized.dcp]
}
puts "DCIM256_UNIT_PASS $unit $mode $part"
