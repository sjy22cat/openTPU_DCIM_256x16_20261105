"""Local Vivado/XSim regression, no remote host or board required.

Run: python -X utf8 tools/check_dcim256.py [--top tb_dcim256]
XSim 2019 needs always_ff->always in generated simulation copies because existing
RTL also initializes RAM/registers. Functional source remains unchanged.
"""
from pathlib import Path
import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from opentpu.target import sources


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--top', default='tb_dcim256')
    mode=parser.add_mutually_exclusive_group()
    mode.add_argument('--compile-only',action='store_true')
    mode.add_argument('--run-only',action='store_true')
    parser.add_argument('--vivado-bin',default=os.environ.get('VIVADO_BIN',
        'D:/vivado2019.2/vivado2019/Vivado/2019.2/bin'))
    args=parser.parse_args()
    out=ROOT/'build'/args.top
    out.mkdir(parents=True,exist_ok=True)
    prj=out/'files.prj'
    if not args.run_only:
        paths=[]
        fingerprints={}
        # Invalidate the old snapshot before changing any simulation inputs.
        # A compile-only or failed build must not certify an older executable.
        (out/'sources.json').unlink(missing_ok=True)
        for name in ('xvlog','xelab','xsim'):
            for suffix in ('_console.log','.log'):
                (out/(name+suffix)).unlink(missing_ok=True)
        for f in sources('dcim256')+['mem/otpu_dram.sv','top/otpu_top.sv']:
            p=out/f.replace('/','_')
            source=ROOT/'rtl'/f
            fingerprints[source.relative_to(ROOT).as_posix()]=hashlib.sha256(source.read_bytes()).hexdigest()
            p.write_text(source.read_text().replace('always_ff','always'),encoding='utf-8')
            paths.append(p)
        reference=ROOT/'sim/dcim256/dcim256_tb_ref.sv'
        paths.append(reference)
        fingerprints[reference.relative_to(ROOT).as_posix()]=hashlib.sha256(reference.read_bytes()).hexdigest()
        tb=ROOT/'sim/dcim256'/f'{args.top}.sv'
        if tb.exists():
            paths.append(tb)
            fingerprints[tb.relative_to(ROOT).as_posix()]=hashlib.sha256(tb.read_bytes()).hexdigest()
        prj.write_text(''.join(f'sv work "{p.as_posix()}"\n' for p in paths),encoding='utf-8')
    else:
        manifest=out/'sources.json'
        if not manifest.exists():
            raise SystemExit('Missing build source manifest; run without --run-only first')
        fingerprints=json.loads(manifest.read_text(encoding='utf-8'))
        changed=[name for name,digest in fingerprints.items()
                 if not (ROOT/name).is_file() or
                 hashlib.sha256((ROOT/name).read_bytes()).hexdigest()!=digest]
        if changed:
            raise SystemExit('Simulation snapshot is stale; rebuild before --run-only:\n'+
                             '\n'.join(changed))
    def run(tool,arguments):
        exe=shutil.which(tool) or str(Path(args.vivado_bin)/(tool+'.bat'))
        result=subprocess.run([exe,*arguments],cwd=out,capture_output=True,text=True,errors='replace')
        (out/f'{tool}_console.log').write_text(result.stdout+result.stderr,encoding='utf-8')
        print((result.stdout+result.stderr)[-1500:],flush=True)
        if result.returncode: raise SystemExit(result.returncode)
    if not args.run_only:
        run('xvlog',['-prj',str(prj)])
        if args.compile_only:return
        run('xelab',[f'work.{args.top}','-s',args.top,'--relax','--mt','8'])
        (out/'sources.json').write_text(json.dumps(fingerprints,indent=2),encoding='utf-8')
    run('xsim',[args.top,'-runall'])
    log=(out/'xsim_console.log').read_text(encoding='utf-8')
    if 'DCIM256_TEST_PASS' not in log:raise SystemExit('Simulation did not report PASS')


if __name__=='__main__':main()
