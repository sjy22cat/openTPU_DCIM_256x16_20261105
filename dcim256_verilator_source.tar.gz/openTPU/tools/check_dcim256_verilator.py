"""Linux Verilator entry point for the dedicated DCIM256 hardware regressions.

python3 tools/check_dcim256_verilator.py --top all --jobs 4
No FPGA, vendor primitives, checkpoint or Vivado license is needed.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shlex
import shutil
import signal
import subprocess
import sys
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from opentpu.target import sources

TOPS = ("tb_tmem_wide", "tb_dma_wide", "tb_mc2048", "tb_qst_collect",
        "tb_dcim256", "tb_dcim256_vectors", "tb_dcim256_sys", "tb_dcim256_control")


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def inputs(top):
    rtl = [ROOT / "rtl" / f for f in sources("dcim256")]
    rtl += [ROOT / "rtl/mem/otpu_dram.sv", ROOT / "rtl/top/otpu_top.sv"]
    return list(dict.fromkeys(rtl)) + [ROOT / "sim/dcim256/dcim256_tb_ref.sv",
                                     ROOT / "sim/dcim256" / (top + ".sv")]


def command(top, args):
    out = ROOT / "build/verilator_dcim256" / top
    flags = ["--timing", "--assert", "-Wno-fatal", "--top-module", top,
             "--unroll-count", "1024", "--unroll-stmts", "100000"]
    if args.lint_only:
        flags += ["--lint-only"]
    else:
        flags += ["--binary", "-j", str(args.jobs), "--output-split", "20000",
                  "--output-split-cfuncs", "500", "-Mdir", str(out / "obj")]
    return [args.verilator, *flags, *map(str, inputs(top))]


def run_logged(cmd, path, timeout=None):
    """Keep the full diagnostics and terminate our process group on interruption."""
    print(shlex.join(map(str, cmd)), flush=True)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as log:
        p = subprocess.Popen(list(map(str, cmd)), cwd=ROOT, stdout=log,
                             stderr=subprocess.STDOUT, start_new_session=os.name == "posix")
        try:
            code = p.wait(timeout=timeout)
        except BaseException:
            if os.name == "posix":
                try:
                    os.killpg(p.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
            else:
                p.kill()
            p.wait()
            raise
    if code:
        print("\n".join(path.read_text(errors="replace").splitlines()[-35:]), file=sys.stderr)
        raise RuntimeError(f"Exit {code}: full log {path}")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--top", nargs="+", choices=("all", *TOPS), default=["all"])
    parser.add_argument("--jobs", type=int, default=4, help="C++ build jobs; tests run sequentially")
    parser.add_argument("--verilator", default="verilator")
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--lint-only", action="store_true")
    mode.add_argument("--compile-only", action="store_true")
    mode.add_argument("--run-only", action="store_true")
    parser.add_argument("--dry-run", action="store_true", help="Print commands without building or running")
    parser.add_argument("--check-env", action="store_true", help="Check server dependencies only")
    parser.add_argument("--timeout", type=int, default=3600, help="Wall time limit per simulation in seconds")
    args = parser.parse_args()
    if args.jobs < 1 or args.timeout < 1:
        parser.error("jobs and timeout must be positive")
    selected = TOPS if "all" in args.top else tuple(dict.fromkeys(args.top))
    if args.dry_run:
        for top in selected:
            print(shlex.join(command(top, args)))
        return
    if os.name != "posix":
        raise SystemExit("Run this entry point on a Linux server; Windows uses tools/check_dcim256.py")
    for tool in (args.verilator, "make", os.environ.get("CXX", "g++")):
        if shutil.which(tool) is None:
            raise SystemExit(f"Missing tool: {tool}")
    version = subprocess.check_output([args.verilator, "--version"], text=True).strip()
    match = re.search(r"Verilator\s+(\d+)\.(\d+)", version)
    if match is None or int(match[1]) < 5:
        raise SystemExit(f"Verilator 5.x with --timing and a C++20 compiler is required: {version}")
    print(f"Python {sys.version.split()[0]}; {version}", flush=True)
    if args.check_env:
        return
    summary = dict(generated=datetime.now(timezone.utc).isoformat(), version=version,
                   target="dcim256", mode="lint" if args.lint_only else "simulation", tests={})
    base = ROOT / "build/verilator_dcim256"
    base.mkdir(parents=True, exist_ok=True)
    summary_path = base / "results.json"
    try:
        for top in selected:
            out = base / top
            out.mkdir(parents=True, exist_ok=True)
            current = {p.relative_to(ROOT).as_posix(): sha(p) for p in inputs(top)}
            manifest = out / "sources.json"
            cmd = command(top, args)
            exe = out / "obj" / ("V" + top)
            entry = summary["tests"][top] = dict(status="running", source_sha256=current)
            if args.run_only:
                if not manifest.is_file() or not exe.is_file():
                    raise RuntimeError(f"Missing build for {top}; run without --run-only")
                previous = json.loads(manifest.read_text())
                if previous["sources"] != current or previous["version"] != version:
                    raise RuntimeError(f"Stale build for {top}; rebuild current sources/tool version")
            else:
                manifest.unlink(missing_ok=True)
                # A failed rebuild must never certify a previous executable.
                if not args.lint_only:
                    exe.unlink(missing_ok=True)
                run_logged(cmd, out / "build.log")
                if args.lint_only:
                    entry["status"] = "LINT_PASS"
                    continue
                if not exe.is_file():
                    raise RuntimeError(f"Build did not produce {exe}")
                if any(sha(ROOT / name) != digest for name, digest in current.items()):
                    raise RuntimeError("Sources changed while compiling; rebuild before running")
                manifest.write_text(json.dumps(dict(sources=current, version=version, command=cmd),
                                               indent=2) + "\n", encoding="utf-8")
            if args.compile_only:
                entry["status"] = "BUILD_PASS"
                continue
            vectors = ROOT / "build/dcim256_vectors"
            if top == "tb_dcim256_vectors":
                run_logged([sys.executable, "-X", "utf8", ROOT / "tools/gen_dcim256_vectors.py"],
                           out / "vectors.log")
                entry["vectors_sha256"] = {f.name: sha(f) for f in vectors.glob("*.hex")}
            simulation = [str(exe), "+vectors=" + vectors.as_posix()]
            run_logged(simulation, out / "run.log", args.timeout)
            log = (out / "run.log").read_text(errors="replace")
            markers = [s for s in log.splitlines() if s.startswith("DCIM256_TEST_PASS")]
            if not markers:
                raise RuntimeError(f"{top} did not report DCIM256_TEST_PASS; see {out / 'run.log'}")
            entry.update(status="PASS", result=markers, log_sha256=sha(out / "run.log"))
            print("\n".join(markers), flush=True)
    except BaseException as exc:
        summary["error"] = f"{type(exc).__name__}: {exc}"
        if "entry" in locals():
            entry["status"] = "FAILED"
        raise
    finally:
        summary_path.write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
        print(f"Results: {summary_path}", flush=True)


if __name__ == "__main__":
    main()
