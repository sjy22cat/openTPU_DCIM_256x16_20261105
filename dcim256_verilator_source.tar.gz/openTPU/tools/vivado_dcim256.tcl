# Device-independent RTL project. The part must be supplied explicitly.
# vivado -mode batch -source tools/vivado_dcim256.tcl -tclargs PART [OUT] [project|rtl|synth]
set root [file normalize [file join [file dirname [info script]] ..]]
if {[llength $argv]<1} {error "Usage: vivado_dcim256.tcl PART ?OUT? ?project|rtl|synth?"}
set part [lindex $argv 0]
set out [expr {[llength $argv]>1 ? [file normalize [lindex $argv 1]] : "$root/build/vivado_dcim256"}]
set mode [expr {[llength $argv]>2 ? [lindex $argv 2] : "project"}]
if {$mode ni {project rtl synth}} {error "Unknown mode: $mode"}
set python [expr {[info exists ::env(OTPU_PYTHON)] ? $::env(OTPU_PYTHON) : "python"}]
cd $root
set listing [exec $python -E -m opentpu.target files dcim256]
create_project -force dcim256 $out -part $part
set_property target_language Verilog [current_project]
foreach relative [split $listing "\n"] {
  set relative [string trim $relative]
  if {$relative ne ""} {read_verilog -sv [file join $root $relative]}
}
set_property top otpu_dcim256_sys [current_fileset]
read_xdc [file join $root constraints dcim256_core.xdc]
update_compile_order -fileset sources_1
if {$mode eq "rtl"} {
  synth_design -rtl -top otpu_dcim256_sys -part $part
  report_clocks -file $out/clocks.rpt
} elseif {$mode eq "synth"} {
  synth_design -top otpu_dcim256_sys -part $part -flatten_hierarchy rebuilt
  write_checkpoint -force $out/dcim256_synth.dcp
  report_utilization -file $out/utilization.rpt
  report_timing_summary -file $out/timing_synth.rpt
  report_cdc -file $out/cdc.rpt
}
puts "DCIM256_VIVADO_PASS $mode $part"
