# Core interface constraints; board wrapper must add pins, I/O delays and reset synchronization.
create_clock -name core_clk -period 7.500 [get_ports clk]
# 256 B * 300 MHz = 76.8 GB/s theoretical native service bandwidth.
# Set this to the actual controller clock in the board integration.
create_clock -name native_clk -period 3.333 [get_ports mem_clk]
# Only Gray-coded FIFO pointers cross between these asynchronous domains.
# Constrain both skew and delay; ASYNC_REG attributes identify synchronizers.
# Do not replace these paths with blanket asynchronous false paths.
set core_gray [get_cells -hier -filter {NAME =~ *u_mc* && (NAME =~ *wgray_reg* || NAME =~ *rgray_reg*)}]
set first_sync [get_cells -hier -filter {NAME =~ *u_mc* && (NAME =~ *rgray_w1_reg* || NAME =~ *wgray_r1_reg*)}]
if {[llength $core_gray] && [llength $first_sync]} {
  set_max_delay -datapath_only 3.333 -from $core_gray -to $first_sync
  set_bus_skew 3.333 -from $core_gray -to $first_sync
}
# A one-bit hysteretic service hint uses its own two-flop synchronizer.
set hint_sync [get_cells -hier -filter {NAME =~ *u_mc*low_m1_reg*}]
if {[llength $hint_sync]} {set_false_path -to [get_pins -of_objects $hint_sync -filter {REF_PIN_NAME == D}]}
